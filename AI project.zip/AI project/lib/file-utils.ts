/**
 * Checks if a file exists by making a HEAD request
 * @param url The URL of the file to check
 * @returns A promise that resolves to a boolean indicating if the file exists
 */
export async function fileExists(url: string): Promise<boolean> {
  try {
    const response = await fetch(url, { method: "HEAD" })
    return response.ok
  } catch (error) {
    console.error(`Error checking if file exists: ${url}`, error)
    return false
  }
}

/**
 * Gets a fallback URL if the original URL doesn't exist
 * @param url The original URL
 * @param fallbackUrl The fallback URL
 * @returns A promise that resolves to the original URL if it exists, or the fallback URL
 */
export async function getFileUrlWithFallback(url: string, fallbackUrl: string): Promise<string> {
  const exists = await fileExists(url)
  return exists ? url : fallbackUrl
}
