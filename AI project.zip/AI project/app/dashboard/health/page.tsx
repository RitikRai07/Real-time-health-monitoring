"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { VideoTutorial } from "@/components/video-tutorial"
import { AdvancedHealthDashboard } from "@/components/advanced-health-dashboard"
import { Heart, Info, Settings, Upload } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function HealthPage() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Heart className="h-6 w-6 text-red-500" />
            Health Monitoring
          </h1>
          <p className="text-muted-foreground">Comprehensive health metrics and analysis</p>
        </div>

        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-border">
                <Info className="h-4 w-4 mr-2" />
                How It Works
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle>How Health Monitoring Works</DialogTitle>
                <DialogDescription>Learn how to use the advanced health monitoring features.</DialogDescription>
              </DialogHeader>
              <div className="mt-4 space-y-4">
                <VideoTutorial
                  src="/videos/health-tutorial.mp4"
                  poster="/images/health-tutorial-poster.jpg"
                  title="Health Monitoring Tutorial"
                />
                <p className="text-sm text-muted-foreground">
                  This video explains how to interpret health metrics, set up alerts, and use the AI-powered health
                  insights.
                </p>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" className="border-border">
            <Settings className="h-4 w-4 mr-2" />
            Health Settings
          </Button>

          <Button className="bg-primary hover:bg-primary/90">
            <Upload className="h-4 w-4 mr-2" />
            Import Health Data
          </Button>
        </div>
      </div>

      <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-card border border-border p-1">
          <TabsTrigger
            value="dashboard"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Health Dashboard
          </TabsTrigger>
          <TabsTrigger
            value="reports"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Health Reports
          </TabsTrigger>
          <TabsTrigger
            value="history"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Health History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Health Dashboard</CardTitle>
              <CardDescription>Comprehensive health monitoring and analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <AdvancedHealthDashboard />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Health Reports</CardTitle>
              <CardDescription>Generate and view detailed health reports</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Health reports content will go here.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Health History</CardTitle>
              <CardDescription>View historical health data and trends</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Health history content will go here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
