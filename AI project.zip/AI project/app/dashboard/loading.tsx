import { Shield } from "lucide-react"

export default function DashboardLoading() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh]">
      <Shield className="h-16 w-16 text-primary animate-pulse mb-4" />
      <h2 className="text-2xl font-bold mb-2">Loading Dashboard</h2>
      <p className="text-muted-foreground">Please wait while we prepare your dashboard...</p>
      <div className="mt-6 w-48 h-2 bg-muted rounded-full overflow-hidden">
        <div className="h-full bg-primary rounded-full animate-progress"></div>
      </div>
    </div>
  )
}
