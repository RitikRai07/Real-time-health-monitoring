"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  Bell,
  User,
  Search,
  Settings,
  LogOut,
  ChevronDown,
  Filter,
  RefreshCw,
  X,
  Upload,
  Menu,
  FileText,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { NotificationCenter } from "@/components/notification-center"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { CustomSidebar } from "@/components/custom-sidebar"

export default function DashboardLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const [showNotifications, setShowNotifications] = useState(false)
  const [notificationCount, setNotificationCount] = useState(7)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [searchQuery, setSearchQuery] = useState("")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showUploadDialog, setShowUploadDialog] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const router = useRouter()

  // Check if user is authenticated
  useEffect(() => {
    if (!user && typeof window !== "undefined") {
      router.push("/login")
    }
  }, [user, router])

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly decide if we should add a notification
      if (Math.random() > 0.8) {
        setNotificationCount((prev) => prev + 1)

        // Show toast for new notification
        toast({
          title: "New Alert",
          description: "A team member has triggered a health alert.",
          variant: "destructive",
        })
      }
    }, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [toast])

  const refreshData = () => {
    setIsRefreshing(true)

    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false)
      setLastUpdated(new Date())

      toast({
        title: "Data Refreshed",
        description: "All monitoring data has been updated.",
      })
    }, 2000)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchResults(true)
      toast({
        title: "Search Results",
        description: `Showing results for "${searchQuery}"`,
      })
    }
  }

  const handleLogout = () => {
    logout()
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    })
    router.push("/login")
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files)
      setUploadedFiles((prev) => [...prev, ...newFiles])
    }
  }

  const simulateUpload = () => {
    if (uploadedFiles.length === 0) return

    setIsUploading(true)
    setUploadProgress(0)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)

          toast({
            title: "Upload Complete",
            description: `Successfully uploaded ${uploadedFiles.length} file(s)`,
          })

          return 100
        }
        return prev + 10
      })
    }, 300)
  }

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  // If user is not authenticated, don't render the dashboard
  if (typeof window !== "undefined" && !user) {
    return null
  }

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Custom Sidebar Component */}
      <CustomSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} notificationCount={notificationCount} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="border-b border-border p-4 backdrop-blur-sm bg-card/80 sticky top-0 z-30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleSidebar}>
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="text-xl font-bold hidden sm:block">Command Dashboard</h1>
              <Badge variant="outline" className="ml-2 bg-primary/10 text-primary border-primary/20">
                Mission Active
              </Badge>
            </div>

            <div className="flex items-center gap-2 sm:gap-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground hidden md:flex">
                <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={refreshData} disabled={isRefreshing}>
                  <RefreshCw className={`h-3 w-3 ${isRefreshing ? "animate-spin" : ""}`} />
                </Button>
              </div>

              <form onSubmit={handleSearch} className="relative hidden sm:block">
                <Input
                  type="search"
                  placeholder="Search..."
                  className="w-40 md:w-64 bg-card border-border focus-visible:ring-primary"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" variant="ghost" size="icon" className="absolute right-0 top-0 h-full">
                  <Search className="h-4 w-4 text-muted-foreground" />
                </Button>
              </form>

              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="border-border gap-2 hidden md:flex">
                    <Filter className="h-4 w-4" />
                    <span>Filter</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-border">
                  <DialogHeader>
                    <DialogTitle>Filter Dashboard</DialogTitle>
                    <DialogDescription>Customize which data is displayed on your dashboard.</DialogDescription>
                  </DialogHeader>
                  {/* Filter content here */}
                </DialogContent>
              </Dialog>

              <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon" className="border-border">
                    <Upload className="h-5 w-5" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-border">
                  <DialogHeader>
                    <DialogTitle>Upload Files</DialogTitle>
                    <DialogDescription>Upload images, documents, or other files to the system.</DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4 py-4">
                    <div
                      className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => document.getElementById("file-upload")?.click()}
                    >
                      <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm font-medium">Click to upload or drag and drop</p>
                      <p className="text-xs text-muted-foreground mt-1">PNG, JPG, PDF, DOCX up to 10MB</p>
                      <input id="file-upload" type="file" multiple className="hidden" onChange={handleFileUpload} />
                    </div>

                    {uploadedFiles.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Files to upload ({uploadedFiles.length})</p>
                        <div className="max-h-40 overflow-auto space-y-2 pr-2 custom-scrollbar">
                          {uploadedFiles.map((file, index) => (
                            <div key={index} className="flex items-center justify-between bg-background p-2 rounded-md">
                              <div className="flex items-center gap-2 overflow-hidden">
                                <FileText className="h-4 w-4 flex-shrink-0" />
                                <span className="text-sm truncate">{file.name}</span>
                              </div>
                              <span className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(0)} KB</span>
                            </div>
                          ))}
                        </div>

                        {isUploading && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>Uploading...</span>
                              <span>{uploadProgress}%</span>
                            </div>
                            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full bg-primary rounded-full transition-all duration-300"
                                style={{ width: `${uploadProgress}%` }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <DialogFooter>
                    <Button variant="outline" onClick={() => setUploadedFiles([])}>
                      Clear All
                    </Button>
                    <Button
                      onClick={simulateUpload}
                      disabled={uploadedFiles.length === 0 || isUploading}
                      className="bg-primary hover:bg-primary/90"
                    >
                      {isUploading ? "Uploading..." : "Upload Files"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Button
                variant="outline"
                size="icon"
                className="relative border-border"
                onClick={() => setShowNotifications(!showNotifications)}
              >
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-red-500 text-[10px] flex items-center justify-center text-white">
                    {notificationCount}
                  </span>
                )}
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt={user?.name} />
                      <AvatarFallback>
                        {user?.name
                          ?.split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-start text-sm hidden md:flex">
                      <span>{user?.name}</span>
                      <span className="text-xs text-muted-foreground">{user?.role}</span>
                    </div>
                    <ChevronDown className="h-4 w-4 text-muted-foreground hidden md:block" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-card border-border">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-border" />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-border" />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {showNotifications && (
          <div className="absolute top-16 right-4 z-40 w-96 shadow-xl">
            <NotificationCenter onClose={() => setShowNotifications(false)} />
          </div>
        )}

        {showSearchResults && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 w-[600px] max-w-[90vw] bg-card border border-border rounded-lg shadow-xl p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Search Results for "{searchQuery}"</h3>
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setShowSearchResults(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-4 max-h-[400px] overflow-auto custom-scrollbar">
              {/* Search results content */}
              <div className="text-center py-8 text-muted-foreground">
                <Search className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No results found for "{searchQuery}"</p>
                <p className="text-sm mt-2">Try using different keywords or filters</p>
              </div>
            </div>
          </div>
        )}

        <main className="flex-1 overflow-auto p-4 md:p-6 custom-scrollbar">{children}</main>
      </div>
    </div>
  )
}
