"use client"

import { useState, Suspense } from "react"
import { AlertTriangle, Bell, CheckCircle, Filter, Info, Search, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { VideoTutorial } from "@/components/video-tutorial"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type AlertType = "critical" | "warning" | "info" | "success"
type AlertStatus = "active" | "acknowledged" | "resolved"

interface Alert {
  id: string
  type: AlertType
  title: string
  description: string
  timestamp: Date
  status: AlertStatus
  teamMember?: string
  location?: string
}

export default function AlertsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<AlertStatus | "all">("all")
  const [typeFilter, setTypeFilter] = useState<AlertType | "all">("all")

  // Sample alerts data
  const alerts: Alert[] = [
    {
      id: "alert-1",
      type: "critical",
      title: "Heart Rate Anomaly",
      description: "Team member John Doe has an abnormal heart rate of 160 BPM.",
      timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      status: "active",
      teamMember: "John Doe",
      location: "Sector A-3",
    },
    {
      id: "alert-2",
      type: "warning",
      title: "Oxygen Level Warning",
      description: "Team member Jane Smith's oxygen saturation is at 92%.",
      timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      status: "acknowledged",
      teamMember: "Jane Smith",
      location: "Sector B-2",
    },
    {
      id: "alert-3",
      type: "info",
      title: "New Team Member Connected",
      description: "Team member Mike Johnson has connected to the monitoring system.",
      timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
      status: "resolved",
      teamMember: "Mike Johnson",
      location: "Sector C-1",
    },
    {
      id: "alert-4",
      type: "critical",
      title: "Temperature Spike",
      description: "Team member Sarah Williams has a temperature of 102.5°F.",
      timestamp: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
      status: "active",
      teamMember: "Sarah Williams",
      location: "Sector A-1",
    },
    {
      id: "alert-5",
      type: "warning",
      title: "Low Battery",
      description: "Team member David Brown's monitoring device has 15% battery remaining.",
      timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
      status: "acknowledged",
      teamMember: "David Brown",
      location: "Sector D-4",
    },
    {
      id: "alert-6",
      type: "success",
      title: "Health Check Passed",
      description: "Team member Emily Davis has completed her health check successfully.",
      timestamp: new Date(Date.now() - 1000 * 60 * 90), // 1.5 hours ago
      status: "resolved",
      teamMember: "Emily Davis",
      location: "Sector B-3",
    },
    {
      id: "alert-7",
      type: "critical",
      title: "Fall Detected",
      description: "Team member Robert Wilson has experienced a fall.",
      timestamp: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
      status: "active",
      teamMember: "Robert Wilson",
      location: "Sector E-2",
    },
  ]

  const filteredAlerts = alerts.filter((alert) => {
    // Apply search filter
    const matchesSearch =
      alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alert.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (alert.teamMember && alert.teamMember.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (alert.location && alert.location.toLowerCase().includes(searchQuery.toLowerCase()))

    // Apply status filter
    const matchesStatus = statusFilter === "all" || alert.status === statusFilter

    // Apply type filter
    const matchesType = typeFilter === "all" || alert.type === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  const getAlertIcon = (type: AlertType) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-5 w-5 text-destructive" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-orange-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
    }
  }

  const getStatusBadge = (status: AlertStatus) => {
    switch (status) {
      case "active":
        return <Badge variant="destructive">Active</Badge>
      case "acknowledged":
        return (
          <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-200">
            Acknowledged
          </Badge>
        )
      case "resolved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Resolved
          </Badge>
        )
    }
  }

  const formatTime = (date: Date) => {
    return new Intl.RelativeTimeFormat("en", { numeric: "auto" }).format(
      Math.round((date.getTime() - Date.now()) / (1000 * 60)),
      "minute",
    )
  }

  const videoExists = async (url: string) => {
    try {
      const response = await fetch(url, { method: "HEAD" })
      return response.ok
    } catch (error) {
      return false
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Alerts</h1>
          <p className="text-muted-foreground">Monitor and manage health and safety alerts for your team.</p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <Bell className="h-4 w-4" />
            <span>Configure Alerts</span>
          </Button>
          <Button className="gap-2">
            <AlertTriangle className="h-4 w-4" />
            <span>Create Alert</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle>Alert Timeline</CardTitle>
                <CardDescription>{filteredAlerts.length} alerts found</CardDescription>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search alerts..."
                    className="pl-8 w-full sm:w-[200px]"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  {searchQuery && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-9 w-9"
                      onClick={() => setSearchQuery("")}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="flex gap-2">
                  <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as AlertStatus | "all")}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="acknowledged">Acknowledged</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={typeFilter} onValueChange={(value) => setTypeFilter(value as AlertType | "all")}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="success">Success</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button variant="outline" size="icon" className="shrink-0">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="critical">Critical</TabsTrigger>
                <TabsTrigger value="warning">Warning</TabsTrigger>
                <TabsTrigger value="info">Info</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="m-0">
                <div className="space-y-4">
                  {filteredAlerts.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <Bell className="h-12 w-12 text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium">No alerts found</h3>
                      <p className="text-sm text-muted-foreground mt-1">Try adjusting your search or filter criteria</p>
                    </div>
                  ) : (
                    filteredAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`alert-item ${alert.type} p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors`}
                      >
                        <div className="flex items-start gap-4">
                          <div className="mt-0.5">{getAlertIcon(alert.type)}</div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium">{alert.title}</h4>
                              {getStatusBadge(alert.status)}
                            </div>
                            <p className="text-sm text-muted-foreground">{alert.description}</p>
                            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                              <span>{formatTime(alert.timestamp)}</span>
                              {alert.teamMember && <span>Team Member: {alert.teamMember}</span>}
                              {alert.location && <span>Location: {alert.location}</span>}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            {alert.status === "active" && (
                              <Button variant="outline" size="sm">
                                Acknowledge
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              <TabsContent value="critical" className="m-0">
                <div className="space-y-4">
                  {filteredAlerts
                    .filter((a) => a.type === "critical")
                    .map((alert) => (
                      <div
                        key={alert.id}
                        className={`alert-item ${alert.type} p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors`}
                      >
                        {/* Same content as above */}
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="warning" className="m-0">
                <div className="space-y-4">
                  {filteredAlerts
                    .filter((a) => a.type === "warning")
                    .map((alert) => (
                      <div
                        key={alert.id}
                        className={`alert-item ${alert.type} p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors`}
                      >
                        {/* Same content as above */}
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="info" className="m-0">
                <div className="space-y-4">
                  {filteredAlerts
                    .filter((a) => a.type === "info" || a.type === "success")
                    .map((alert) => (
                      <div
                        key={alert.id}
                        className={`alert-item ${alert.type} p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors`}
                      >
                        {/* Same content as above */}
                      </div>
                    ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alert Statistics</CardTitle>
              <CardDescription>Overview of current alert status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Critical Alerts</span>
                  <span className="text-destructive font-bold">
                    {alerts.filter((a) => a.type === "critical" && a.status === "active").length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Warning Alerts</span>
                  <span className="text-orange-500 font-bold">
                    {alerts.filter((a) => a.type === "warning" && a.status === "active").length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Info Alerts</span>
                  <span className="text-blue-500 font-bold">
                    {alerts.filter((a) => a.type === "info" && a.status === "active").length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Resolved Today</span>
                  <span className="text-green-500 font-bold">
                    {alerts.filter((a) => a.status === "resolved").length}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Video Tutorial Section */}
          <div className="col-span-12 lg:col-span-4">
            <h2 className="text-xl font-semibold mb-4">Tutorial</h2>
            <Suspense fallback={<div className="h-[300px] bg-muted rounded-lg animate-pulse" />}>
              <VideoTutorial
                src="/videos/alert-tutorial.mp4"
                poster="/images/alert-tutorial-poster.jpg"
                title="How to Respond to Alerts"
                description="Learn how to effectively respond to different types of alerts and manage your team's safety."
                fallbackImageSrc="/images/alert-tutorial-poster.jpg"
              />
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  )
}
