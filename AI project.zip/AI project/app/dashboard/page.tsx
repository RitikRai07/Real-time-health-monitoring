"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  MapPin,
  Heart,
  Activity,
  Thermometer,
  Droplet,
  Brain,
  AlertTriangle,
  Users,
  Clock,
  Wind,
  Radio,
  Maximize2,
  X,
  CheckCircle2,
  Building2,
  Settings2,
  Zap,
  UserPlus,
  FileText,
  MessageSquare,
  CalendarClock,
  HelpCircle,
  TrendingUp,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"
import { TeamMap } from "@/components/team-map"
import { HealthMetricsChart } from "@/components/health-metrics-chart"
import { AlertsTimeline } from "@/components/alerts-timeline"
import { TeamVitals } from "@/components/team-vitals"
import { EnvironmentalData } from "@/components/environmental-data"
import { NotificationCenter } from "@/components/notification-center"
import { LiveFeed } from "@/components/live-feed"
import { MissionPlanner } from "@/components/mission-planner"
import { EquipmentStatus } from "@/components/equipment-status"
import { MedicalAlerts } from "@/components/medical-alerts"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [showNotifications, setShowNotifications] = useState(false)
  const [notificationCount, setNotificationCount] = useState(3)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [searchQuery, setSearchQuery] = useState("")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const router = useRouter()

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly decide if we should add a notification
      if (Math.random() > 0.8) {
        setNotificationCount((prev) => prev + 1)

        // Show toast for new notification
        toast({
          title: "New Alert",
          description: "A team member has triggered a health alert.",
          variant: "destructive",
        })
      }
    }, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [toast])

  const refreshData = () => {
    setIsRefreshing(true)

    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false)
      setLastUpdated(new Date())

      toast({
        title: "Data Refreshed",
        description: "All monitoring data has been updated.",
      })
    }, 2000)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setShowSearchResults(true)
      toast({
        title: "Search Results",
        description: `Showing results for "${searchQuery}"`,
      })
    }
  }

  const handleLogout = () => {
    logout()
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    })
    router.push("/")
  }

  return (
    <div className="w-full">
      {showNotifications && (
        <div className="absolute top-16 right-4 z-40 w-96 shadow-xl">
          <NotificationCenter onClose={() => setShowNotifications(false)} />
        </div>
      )}

      {showSearchResults && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 w-[600px] bg-card border border-border rounded-lg shadow-xl p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Search Results for "{searchQuery}"</h3>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setShowSearchResults(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-4 max-h-[400px] overflow-auto custom-scrollbar">
            <div className="border-b border-border pb-2">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Team Members</h4>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>SM</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">Sarah Miller</div>
                    <div className="text-xs text-muted-foreground">Alpha-2</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>MK</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">Michael Keller</div>
                    <div className="text-xs text-muted-foreground">Bravo-1</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-b border-border pb-2">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Alerts</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <div className="p-2 rounded-full bg-amber-500/20">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">High Body Temperature</div>
                    <div className="text-xs text-muted-foreground">Alpha-2 • 10 minutes ago</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <div className="p-2 rounded-full bg-amber-500/20">
                    <AlertTriangle className="h-4 w-4 text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">Low Hydration Level</div>
                    <div className="text-xs text-muted-foreground">Bravo-1 • 23 minutes ago</div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Locations</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <div className="p-2 rounded-full bg-primary/20">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">Sector 7, Northern Region</div>
                    <div className="text-xs text-muted-foreground">Current mission location</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted/50 cursor-pointer">
                  <div className="p-2 rounded-full bg-primary/20">
                    <Building2 className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">Central Medical Center</div>
                    <div className="text-xs text-muted-foreground">3.2 km away</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 p-1">
          <TabsTrigger
            value="overview"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger
            value="team"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Team
          </TabsTrigger>
          <TabsTrigger
            value="map"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Map
          </TabsTrigger>
          <TabsTrigger
            value="health"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Health
          </TabsTrigger>
          <TabsTrigger
            value="medical"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Medical
          </TabsTrigger>
          <TabsTrigger
            value="alerts"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Alerts
            {notificationCount > 0 && <Badge className="ml-2 bg-red-500 text-white">{notificationCount}</Badge>}
          </TabsTrigger>
          <TabsTrigger
            value="environment"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Environment
          </TabsTrigger>
          <TabsTrigger
            value="comms"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Comms
          </TabsTrigger>
          <TabsTrigger
            value="missions"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Missions
          </TabsTrigger>
          <TabsTrigger
            value="equipment"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Equipment
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Actions */}
          <div className="bg-zinc-900/70 backdrop-blur-sm border border-zinc-800/70 rounded-xl p-4 shadow-lg animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium flex items-center gap-2">
                <Zap className="h-5 w-5 text-emerald-500" />
                Quick Actions
              </h3>
              <Button variant="ghost" size="sm" className="text-zinc-400 hover:text-white">
                Customize
                <Settings2 className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <AlertCircle className="h-6 w-6 mb-2 text-emerald-500" />
                <span>New Alert</span>
              </Button>

              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <UserPlus className="h-6 w-6 mb-2 text-emerald-500" />
                <span>Add Member</span>
              </Button>

              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <FileText className="h-6 w-6 mb-2 text-emerald-500" />
                <span>New Report</span>
              </Button>

              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <MessageSquare className="h-6 w-6 mb-2 text-emerald-500" />
                <span>Team Chat</span>
              </Button>

              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <CalendarClock className="h-6 w-6 mb-2 text-emerald-500" />
                <span>Schedule</span>
              </Button>

              <Button
                variant="outline"
                className="flex flex-col h-auto py-4 border-zinc-800 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
              >
                <HelpCircle className="h-6 w-6 mb-2 text-emerald-500" />
                <span>Help</span>
              </Button>
            </div>
          </div>
          {/* Mission Status Card */}
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Current Mission: Operation Sentinel</CardTitle>
                  <CardDescription>Started: 08:00 Today • Duration: 6h 45m</CardDescription>
                </div>
                <Badge className="bg-primary text-primary-foreground">ACTIVE</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-6">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Mission Commander</div>
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback>JD</AvatarFallback>
                    </Avatar>
                    <span>Col. James Davidson</span>
                  </div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Location</div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-primary" />
                    <span>Sector 7, Northern Region</span>
                  </div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Teams Deployed</div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-primary" />
                    <span>3 Teams (12 Personnel)</span>
                  </div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Mission Status</div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>On Schedule</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          {/* Health Insights */}
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg animate-fade-in">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-emerald-500" />
                    Health Insights
                  </CardTitle>
                  <CardDescription>AI-powered analysis of team health data</CardDescription>
                </div>
                <Badge className="bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500/30">New</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-zinc-800/50 rounded-lg p-4 border border-zinc-700/50 hover:border-emerald-500/30 transition-all duration-300">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-full bg-amber-500/20 mt-1">
                      <Thermometer className="h-5 w-5 text-amber-500" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Heat Stress Risk Increasing</h4>
                      <p className="text-sm text-zinc-400 mb-2">
                        Team members in Sector 7 are showing early signs of heat stress. Current temperature is 32°C
                        with 78% humidity.
                      </p>
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <Clock className="h-3 w-3" /> Updated 5 minutes ago
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-800/50 rounded-lg p-4 border border-zinc-700/50 hover:border-emerald-500/30 transition-all duration-300">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-full bg-emerald-500/20 mt-1">
                      <TrendingUp className="h-5 w-5 text-emerald-500" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Team Recovery Improving</h4>
                      <p className="text-sm text-zinc-400 mb-2">
                        Rest periods are showing improved recovery metrics across all teams. Heart rate variability has
                        increased by 12%.
                      </p>
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <Clock className="h-3 w-3" /> Updated 20 minutes ago
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-800/50 rounded-lg p-4 border border-zinc-700/50 hover:border-emerald-500/30 transition-all duration-300">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-full bg-blue-500/20 mt-1">
                      <Droplet className="h-5 w-5 text-blue-500" />
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">Hydration Reminder</h4>
                      <p className="text-sm text-zinc-400 mb-2">
                        Alpha-2 and Bravo-1 teams should increase fluid intake. Current hydration levels are below
                        optimal range.
                      </p>
                      <div className="flex items-center gap-2 text-xs text-zinc-500">
                        <Clock className="h-3 w-3" /> Updated 15 minutes ago
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Team Status
                </CardTitle>
                <CardDescription>6 team members deployed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Healthy</span>
                    <span className="text-sm font-medium">4</span>
                  </div>
                  <Progress value={67} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Warning</span>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <Progress value={33} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Critical</span>
                    <span className="text-sm font-medium">0</span>
                  </div>
                  <Progress value={0} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  Active Alerts
                </CardTitle>
                <CardDescription>3 alerts in the last hour</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-2 rounded-md bg-amber-500/10 border border-amber-500/20">
                    <Thermometer className="h-5 w-5 text-amber-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">High Body Temperature</p>
                      <p className="text-xs text-muted-foreground">Alpha-2 • 10 mins ago</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-2 rounded-md bg-amber-500/10 border border-amber-500/20">
                    <Droplet className="h-5 w-5 text-amber-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">Low Hydration</p>
                      <p className="text-xs text-muted-foreground">Bravo-1 • 23 mins ago</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-2 rounded-md bg-amber-500/10 border border-amber-500/20">
                    <MapPin className="h-5 w-5 text-amber-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">Geo-fence Breach</p>
                      <p className="text-xs text-muted-foreground">Charlie-3 • 42 mins ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wind className="h-5 w-5 text-blue-500" />
                  Environmental
                </CardTitle>
                <CardDescription>Current field conditions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Thermometer className="h-4 w-4" /> Temperature
                    </span>
                    <span className="text-sm font-medium">32°C</span>
                  </div>
                  <Progress value={65} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Droplet className="h-4 w-4" /> Humidity
                    </span>
                    <span className="text-sm font-medium">78%</span>
                  </div>
                  <Progress value={78} className="h-2 bg-muted" indicatorClassName="bg-blue-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Wind className="h-4 w-4" /> Air Quality
                    </span>
                    <span className="text-sm font-medium">Good</span>
                  </div>
                  <Progress value={85} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    Team Location
                  </CardTitle>
                  <CardDescription>Real-time positioning of all team members</CardDescription>
                </div>
                <Button variant="outline" size="icon" className="h-8 w-8 border-zinc-800/70">
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[400px] relative rounded-md overflow-hidden">
                  <TeamMap />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Health Metrics
                </CardTitle>
                <CardDescription>Team average over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[350px]">
                  <HealthMetricsChart />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Recent Alerts
                </CardTitle>
                <CardDescription>Timeline of incidents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] overflow-auto pr-2 custom-scrollbar">
                  <AlertsTimeline />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  Team Vitals
                </CardTitle>
                <CardDescription>Current health status of all team members</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] overflow-auto pr-2 custom-scrollbar">
                  <TeamVitals />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Radio className="h-5 w-5 text-primary" />
                Live Feed
              </CardTitle>
              <CardDescription>Real-time updates from the field</CardDescription>
            </CardHeader>
            <CardContent>
              <LiveFeed />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Team Management</CardTitle>
              <CardDescription>View and manage your team members</CardDescription>
            </CardHeader>
            <CardContent>
              <TeamVitals showDetails={true} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="map">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Mission Map</CardTitle>
              <CardDescription>Real-time location tracking and geo-fencing</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[600px] relative rounded-md overflow-hidden">
                <TeamMap fullscreen={true} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Health Monitoring</CardTitle>
              <CardDescription>Advanced biometric data analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="h-[350px]">
                    <HealthMetricsChart />
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Health Risk Assessment</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm flex items-center gap-2">
                          <Thermometer className="h-4 w-4 text-red-500" /> Heat Exhaustion Risk
                        </span>
                        <span className="text-sm font-medium">Medium</span>
                      </div>
                      <Progress value={60} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />

                      <div className="flex justify-between items-center">
                        <span className="text-sm flex items-center gap-2">
                          <Droplet className="h-4 w-4 text-blue-500" /> Dehydration Risk
                        </span>
                        <span className="text-sm font-medium">Low</span>
                      </div>
                      <Progress value={25} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />

                      <div className="flex justify-between items-center">
                        <span className="text-sm flex items-center gap-2">
                          <Brain className="h-4 w-4 text-purple-500" /> Stress Level
                        </span>
                        <span className="text-sm font-medium">Elevated</span>
                      </div>
                      <Progress value={45} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Individual Health Metrics</h3>
                  <TeamVitals showDetails={true} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="medical">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Medical Management</CardTitle>
              <CardDescription>Monitor health alerts and manage medical resources</CardDescription>
            </CardHeader>
            <CardContent>
              <MedicalAlerts />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Alert Management</CardTitle>
              <CardDescription>Monitor and respond to critical alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] overflow-auto pr-2 custom-scrollbar">
                <AlertsTimeline extended={true} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="environment">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Environmental Monitoring</CardTitle>
              <CardDescription>Field conditions and hazard detection</CardDescription>
            </CardHeader>
            <CardContent>
              <EnvironmentalData />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="missions">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Mission Planning</CardTitle>
              <CardDescription>Plan and manage mission operations</CardDescription>
            </CardHeader>
            <CardContent>
              <MissionPlanner />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="equipment">
          <Card className="bg-zinc-900/70 backdrop-blur-sm border-zinc-800/70 shadow-lg hover:shadow-emerald-500/5 transition-all duration-300 animate-fade-in">
            <CardHeader>
              <CardTitle>Equipment Status</CardTitle>
              <CardDescription>Monitor and manage team equipment</CardDescription>
            </CardHeader>
            <CardContent>
              <EquipmentStatus />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
