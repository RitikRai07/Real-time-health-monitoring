import { NextResponse } from "next/server"

export async function GET() {
  // Return a simple response indicating the video is not available
  return new NextResponse(
    JSON.stringify({
      error: "Video not available",
      message: "The requested video is not available. Please check back later.",
    }),
    {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    },
  )
}
