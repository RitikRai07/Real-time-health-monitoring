"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Shield, Eye, EyeOff, ArrowRight, CheckCircle2, Lock, Mail, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [loginSuccess, setLoginSuccess] = useState(false)
  const { login } = useAuth()
  const { toast } = useToast()
  const router = useRouter()

  // Add animation effect
  useEffect(() => {
    const elements = document.querySelectorAll(".animate-in")
    elements.forEach((element, index) => {
      setTimeout(() => {
        element.classList.add("show")
      }, 100 * index)
    })
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Validate inputs
      if (!email) {
        throw new Error("Please enter your email address")
      }
      if (!password) {
        throw new Error("Please enter your password")
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Show success state before redirecting
      setLoginSuccess(true)

      setTimeout(() => {
        // In a real app, you would validate credentials with your backend
        login({
          email,
          name: "John Medic",
          role: "Medical Officer",
        })

        toast({
          title: "Login Successful",
          description: "Welcome back to HealthGuardian!",
        })
      }, 1000)

      // Router.push is handled in the login function of AuthProvider
    } catch (error: any) {
      setError(error.message || "Invalid credentials")
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive",
      })
      setLoginSuccess(false)
    } finally {
      if (!loginSuccess) {
        setIsLoading(false)
      }
    }
  }

  const handleGuestLogin = () => {
    setIsLoading(true)
    setLoginSuccess(true)

    // Simulate API call
    setTimeout(() => {
      login({
        email: "guest@example.com",
        name: "Guest User",
        role: "Observer",
      })

      toast({
        title: "Guest Access Granted",
        description: "You are now viewing the demo dashboard.",
      })

      // Router.push is handled in the login function of AuthProvider
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-10 bg-gradient-to-b from-zinc-950 to-zinc-900">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center animate-in">
            <Link href="/" className="inline-block">
              <div className="flex justify-center">
                <Shield className="h-12 w-12 text-emerald-500" />
              </div>
              <h1 className="mt-4 text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-emerald-600">
                HealthGuardian
              </h1>
              <p className="mt-2 text-zinc-400">Real-time health monitoring for mission-critical operations</p>
            </Link>
          </div>

          <Card className="border-zinc-800/50 bg-zinc-900/50 backdrop-blur-sm shadow-xl animate-in">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center">Sign in</CardTitle>
              <CardDescription className="text-center">Enter your credentials to access your account</CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4 animate-in">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {loginSuccess && (
                <Alert className="mb-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 animate-in">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>Login successful! Redirecting to dashboard...</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2 animate-in">
                  <Label htmlFor="email" className="flex items-center gap-2 text-zinc-300">
                    <Mail className="h-4 w-4 text-emerald-500" />
                    Email
                  </Label>
                  <div className="relative">
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-zinc-800/50 border-zinc-700/50 focus:border-emerald-500/50 focus:ring-emerald-500/20 pl-10"
                      autoComplete="email"
                      disabled={isLoading || loginSuccess}
                    />
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                  </div>
                </div>

                <div className="space-y-2 animate-in">
                  <Label htmlFor="password" className="flex items-center gap-2 text-zinc-300">
                    <Lock className="h-4 w-4 text-emerald-500" />
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-zinc-800/50 border-zinc-700/50 focus:border-emerald-500/50 focus:ring-emerald-500/20 pl-10 pr-10"
                      autoComplete="current-password"
                      disabled={isLoading || loginSuccess}
                    />
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors"
                      onClick={() => setShowPassword(!showPassword)}
                      disabled={isLoading || loginSuccess}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between animate-in">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remember-me"
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                      disabled={isLoading || loginSuccess}
                      className="data-[state=checked]:bg-emerald-500 data-[state=checked]:border-emerald-500"
                    />
                    <Label htmlFor="remember-me" className="text-sm text-zinc-400">
                      Remember me
                    </Label>
                  </div>
                  <Link
                    href="/forgot-password"
                    className="text-sm text-emerald-500 hover:text-emerald-400 transition-colors"
                  >
                    Forgot password?
                  </Link>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-white transition-all duration-300 animate-in"
                  disabled={isLoading || loginSuccess}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <svg
                        className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      {loginSuccess ? "Redirecting..." : "Signing in..."}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      Sign in
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  )}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <div className="relative w-full animate-in">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-zinc-800"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-zinc-900 px-2 text-zinc-500">Or</span>
                </div>
              </div>

              <Button
                type="button"
                variant="outline"
                className="w-full border-zinc-800 hover:bg-zinc-800/50 hover:text-emerald-500 transition-all duration-300 animate-in"
                onClick={handleGuestLogin}
                disabled={isLoading || loginSuccess}
              >
                Continue as Guest
              </Button>

              <div className="text-center text-sm text-zinc-500 animate-in">
                Don&apos;t have an account?{" "}
                <Link href="/signup" className="text-emerald-500 hover:text-emerald-400 transition-colors">
                  Sign up
                </Link>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* Right side - Image */}
      <div
        className="hidden md:block md:flex-1 bg-cover bg-center relative"
        style={{ backgroundImage: "url('/images/login-bg.jpg')" }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>

        <div className="absolute bottom-0 left-0 right-0 p-10 space-y-4">
          <div className="bg-zinc-900/70 backdrop-blur-md border border-zinc-800/50 rounded-xl p-6 transform hover:scale-105 transition-all duration-300 animate-in">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-emerald-500/20 rounded-full">
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              </div>
              <h3 className="text-lg font-medium">Real-time Monitoring</h3>
            </div>
            <p className="text-zinc-400">
              Advanced health monitoring system for real-time tracking of vital signs and environmental conditions.
            </p>
          </div>

          <div className="flex gap-4">
            <div className="flex-1 bg-zinc-900/70 backdrop-blur-md border border-zinc-800/50 rounded-xl p-4 transform hover:scale-105 transition-all duration-300 animate-in">
              <h4 className="font-medium flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-emerald-500" /> Military-Grade Security
              </h4>
              <p className="text-xs text-zinc-400">End-to-end encryption and secure authentication protocols.</p>
            </div>

            <div className="flex-1 bg-zinc-900/70 backdrop-blur-md border border-zinc-800/50 rounded-xl p-4 transform hover:scale-105 transition-all duration-300 animate-in">
              <h4 className="font-medium flex items-center gap-2 mb-2">
                <ArrowRight className="h-4 w-4 text-emerald-500" /> Instant Alerts
              </h4>
              <p className="text-xs text-zinc-400">Receive immediate notifications for critical health events.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
