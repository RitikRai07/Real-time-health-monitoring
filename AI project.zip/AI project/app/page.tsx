import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  Shield,
  Heart,
  MapPin,
  AlertTriangle,
  Zap,
  Radio,
  Lock,
  BarChart,
  Cloud,
  Users,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  Play,
  Star,
  School,
  Brain,
  Cpu,
  Database,
  Network,
  Sparkles,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-950 text-white">
      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-slate-900/90 to-slate-950/90 z-10"></div>
          <div className="absolute top-0 left-0 w-full h-full bg-[url('/images/hero-bg.jpg')] bg-cover bg-center"></div>

          {/* Enhanced animated grid overlay */}
          <div className="absolute top-0 left-0 w-full h-full bg-[linear-gradient(to_right,rgba(16,185,129,0.07)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.07)_1px,transparent_1px)] bg-[size:40px_40px] z-5"></div>

          {/* Enhanced animated gradient background */}
          <div className="absolute top-0 left-0 w-full h-full">
            <div
              className="absolute w-[500px] h-[500px] rounded-full bg-gradient-radial from-emerald-500/20 via-transparent to-transparent animate-pulse-slow"
              style={{ left: "30%", top: "40%" }}
            ></div>
            <div
              className="absolute w-[600px] h-[600px] rounded-full bg-gradient-radial from-blue-500/20 via-transparent to-transparent animate-pulse-slow animation-delay-1000"
              style={{ left: "70%", top: "60%" }}
            ></div>
            <div
              className="absolute w-[400px] h-[400px] rounded-full bg-gradient-radial from-purple-500/10 via-transparent to-transparent animate-pulse-slow animation-delay-2000"
              style={{ left: "20%", top: "70%" }}
            ></div>
          </div>
        </div>

        <nav className="absolute top-0 left-0 right-0 z-20 flex justify-between items-center p-6 backdrop-blur-sm bg-slate-900/20">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-emerald-500" />
            <span className="text-2xl font-bold">HealthGuardian</span>
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#features" className="hover:text-emerald-500 transition-colors">
              Features
            </a>
            <a href="#dashboard" className="hover:text-emerald-500 transition-colors">
              Dashboard
            </a>
            <a href="#team" className="hover:text-emerald-500 transition-colors">
              Our Team
            </a>
            <a href="#testimonials" className="hover:text-emerald-500 transition-colors">
              Testimonials
            </a>
            <a href="#pricing" className="hover:text-emerald-500 transition-colors">
              Pricing
            </a>
          </div>
          <div>
            <Button
              asChild
              variant="outline"
              className="mr-3 border-emerald-500 text-emerald-500 hover:bg-emerald-500/10"
            >
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild className="bg-emerald-500 hover:bg-emerald-600 text-white">
              <Link href="/signup">Sign Up</Link>
            </Button>
          </div>
        </nav>

        <div className="container mx-auto px-6 z-20 text-center">
          <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full animate-fade-in">
            Advanced Health Monitoring System
          </Badge>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 tracking-tight animate-fade-in animation-delay-300">
            Protect Your Team with{" "}
            <span className="text-gradient bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-emerald-600 inline-block relative">
              Real-Time
              <svg
                className="absolute -bottom-2 left-0 w-full"
                viewBox="0 0 300 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M1 5.5C32.3333 1.16667 132.8 -3.4 299 10.5"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  className="text-emerald-500"
                />
              </svg>
            </span>{" "}
            Monitoring
          </h1>
          <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto text-zinc-300 leading-relaxed animate-fade-in animation-delay-500">
            Advanced biometric monitoring, geo-tracking, and AI-powered risk prediction for mission-critical operations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in animation-delay-700">
            <Button
              asChild
              size="lg"
              className="bg-emerald-500 hover:bg-emerald-600 text-white text-lg h-14 px-8 rounded-full group"
            >
              <Link href="/signup">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/20 hover:bg-white/10 text-white text-lg h-14 px-8 rounded-full group"
            >
              <Link href="/dashboard" className="flex items-center">
                <Play className="mr-2 h-5 w-5" />
                Demo Dashboard
              </Link>
            </Button>
          </div>

          <div className="mt-16 flex flex-wrap justify-center gap-8 text-sm text-zinc-400 animate-fade-in animation-delay-1000">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              <span>Military-Grade Encryption</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              <span>Real-Time Monitoring</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              <span>AI-Powered Analytics</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              <span>24/7 Support</span>
            </div>
          </div>
        </div>

        <div className="absolute bottom-10 left-0 right-0 z-20 flex justify-center animate-bounce-slow">
          <a
            href="#features"
            className="flex flex-col items-center gap-2 text-zinc-400 hover:text-emerald-500 transition-colors"
          >
            <span className="text-sm">Discover More</span>
            <ChevronDown className="h-5 w-5" />
          </a>
        </div>
      </header>

      {/* Stats Section */}
      <section className="py-16 bg-slate-900 border-y border-slate-800">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-500 mb-2 animate-count">98%</div>
              <div className="text-zinc-400">Mission Success Rate</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-500 mb-2 animate-count">24/7</div>
              <div className="text-zinc-400">Real-Time Monitoring</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-500 mb-2 animate-count">500+</div>
              <div className="text-zinc-400">Active Teams</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-emerald-500 mb-2 animate-count">99.9%</div>
              <div className="text-zinc-400">Uptime Guarantee</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              Key Features
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Advanced Protection for Your Team</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              HealthGuardian combines cutting-edge technology with military-grade security to keep your team safe in any
              environment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={feature.title}
                className="bg-slate-800/50 backdrop-blur-sm border-slate-700 hover:border-emerald-500/50 transition-all duration-300 overflow-hidden group"
                data-aos="fade-up"
                data-aos-delay={100 * index}
              >
                <CardContent className="p-8">
                  <div className="bg-emerald-500/10 p-3 rounded-full w-fit mb-6 group-hover:bg-emerald-500/20 transition-colors">
                    <feature.icon className="h-7 w-7 text-emerald-500" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 group-hover:text-emerald-500 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-zinc-400 mb-4">{feature.description}</p>
                  <div className="flex items-center text-sm text-emerald-500 font-medium">
                    <span>Learn more</span>
                    <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              How It Works
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Comprehensive Health Monitoring</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              Our advanced system works seamlessly to monitor, alert, and protect your team in real-time.
            </p>
          </div>

          <div className="relative">
            {/* Timeline connector */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-emerald-500/20 -translate-x-1/2 hidden md:block"></div>

            {/* Steps */}
            <div className="space-y-12 md:space-y-24 relative">
              {/* Step 1 */}
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 md:pr-12 md:text-right mb-8 md:mb-0">
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105">
                    <h3 className="text-2xl font-bold mb-4 text-emerald-500">Data Collection</h3>
                    <p className="text-zinc-400">
                      Wearable sensors continuously monitor vital signs including heart rate, temperature, blood oxygen,
                      and stress levels.
                    </p>
                  </div>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-4 border-slate-900 flex items-center justify-center z-10 relative">
                      <Heart className="h-6 w-6 text-emerald-500" />
                    </div>
                    <div className="absolute -inset-4 bg-emerald-500/5 rounded-full animate-ping"></div>
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex flex-col md:flex-row-reverse items-center">
                <div className="md:w-1/2 md:pl-12 mb-8 md:mb-0">
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105">
                    <h3 className="text-2xl font-bold mb-4 text-emerald-500">AI Analysis</h3>
                    <p className="text-zinc-400">
                      Advanced algorithms process biometric data to identify patterns and predict potential health
                      issues before they become critical.
                    </p>
                  </div>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-4 border-slate-900 flex items-center justify-center z-10 relative">
                      <Brain className="h-6 w-6 text-emerald-500" />
                    </div>
                    <div className="absolute -inset-4 bg-emerald-500/5 rounded-full animate-ping"></div>
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 md:pr-12 md:text-right mb-8 md:mb-0">
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105">
                    <h3 className="text-2xl font-bold mb-4 text-emerald-500">Real-time Alerts</h3>
                    <p className="text-zinc-400">
                      Instant notifications are sent to team leaders and medical staff when vital signs exceed safe
                      thresholds.
                    </p>
                  </div>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-4 border-slate-900 flex items-center justify-center z-10 relative">
                      <AlertTriangle className="h-6 w-6 text-emerald-500" />
                    </div>
                    <div className="absolute -inset-4 bg-emerald-500/5 rounded-full animate-ping"></div>
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="flex flex-col md:flex-row-reverse items-center">
                <div className="md:w-1/2 md:pl-12 mb-8 md:mb-0">
                  <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105">
                    <h3 className="text-2xl font-bold mb-4 text-emerald-500">Response Coordination</h3>
                    <p className="text-zinc-400">
                      Coordinated response protocols ensure that medical assistance is deployed quickly and efficiently
                      when needed.
                    </p>
                  </div>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 border-4 border-slate-900 flex items-center justify-center z-10 relative">
                      <Users className="h-6 w-6 text-emerald-500" />
                    </div>
                    <div className="absolute -inset-4 bg-emerald-500/5 rounded-full animate-ping"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section id="dashboard" className="py-24 bg-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              Command Dashboard
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Mission Control at Your Fingertips</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              Monitor your team's vital signs, location, and environmental conditions in real-time with our intuitive
              dashboard.
            </p>
          </div>

          <div className="relative rounded-xl overflow-hidden border border-slate-800 shadow-2xl group">
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent z-10 pointer-events-none h-24 bottom-0 top-auto"></div>
            <img
              src="/images/dashboard-full.jpg"
              alt="HealthGuardian Dashboard Preview"
              className="w-full h-auto transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Button asChild size="lg" className="bg-emerald-500 hover:bg-emerald-600 z-20 h-14 px-8 rounded-full">
                <Link href="/dashboard">Explore Live Demo</Link>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-emerald-500/10 p-2 rounded-full">
                  <Heart className="h-5 w-5 text-emerald-500" />
                </div>
                <h3 className="text-lg font-medium">Health Monitoring</h3>
              </div>
              <p className="text-zinc-400">
                Real-time tracking of vital signs including heart rate, temperature, hydration, and stress levels.
              </p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-emerald-500/10 p-2 rounded-full">
                  <MapPin className="h-5 w-5 text-emerald-500" />
                </div>
                <h3 className="text-lg font-medium">Geo-Tracking</h3>
              </div>
              <p className="text-zinc-400">
                Advanced location tracking with geo-fencing capabilities to ensure team members stay within safe zones.
              </p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-colors">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-emerald-500/10 p-2 rounded-full">
                  <AlertTriangle className="h-5 w-5 text-emerald-500" />
                </div>
                <h3 className="text-lg font-medium">Alert System</h3>
              </div>
              <p className="text-zinc-400">
                Instant notifications for critical events with detailed information and recommended actions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section - LPU Students */}
      <section id="team" className="py-24 bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              Meet Our Team
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">The Brilliant Minds Behind HealthGuardian</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              Developed by talented students from Lovely Professional University (LPU) who are passionate about health
              technology and innovation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            {/* Student 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-6 group">
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-slate-800 group-hover:border-emerald-500/50 transition duration-300">
                  <img src="/images/ritik-rai.jpeg" alt="Ritik Rai" className="w-full h-full object-cover" />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-2">Ritik Rai</h3>
              <p className="text-emerald-500 font-medium mb-3">Lead Developer</p>
              <p className="text-zinc-400 mb-4">
                Computer Science student at LPU with expertise in health monitoring systems and AI algorithms.
              </p>
              <div className="flex gap-4 justify-center">
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>

            {/* Student 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-6 group">
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-slate-800 group-hover:border-emerald-500/50 transition duration-300">
                  <img src="/images/aditya.png" alt="Aditya" className="w-full h-full object-cover" />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-2">Aditya</h3>
              <p className="text-emerald-500 font-medium mb-3">UI/UX Designer</p>
              <p className="text-zinc-400 mb-4">
                Design student at LPU with a passion for creating intuitive and accessible user interfaces for
                healthcare applications.
              </p>
              <div className="flex gap-4 justify-center">
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>

            {/* Student 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-6 group">
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-slate-800 group-hover:border-emerald-500/50 transition duration-300">
                  <img src="/images/sikkendar.png" alt="Sikkendar" className="w-full h-full object-cover" />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-2">Sikkendar</h3>
              <p className="text-emerald-500 font-medium mb-3">Backend Developer</p>
              <p className="text-zinc-400 mb-4">
                Computer Engineering student at LPU specializing in database management and real-time data processing
                for health applications.
              </p>
              <div className="flex gap-4 justify-center">
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z"
                      clipRule="evenodd"
                    />
                  </svg>
                </a>
              </div>
            </div>
          </div>

          <div className="mt-20 text-center">
            <div className="inline-block p-6 bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl">
              <div className="flex items-center gap-3 mb-4 justify-center">
                <div className="bg-emerald-500/10 p-2 rounded-full">
                  <School className="h-6 w-6 text-emerald-500" />
                </div>
                <h3 className="text-xl font-medium">Lovely Professional University</h3>
              </div>
              <p className="text-zinc-400 max-w-2xl">
                This project was developed as part of the advanced computer science curriculum at Lovely Professional
                University. LPU is known for fostering innovation and encouraging students to develop real-world
                solutions to complex problems.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-slate-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              Testimonials
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Trusted by Leaders Worldwide</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              See what our clients have to say about how HealthGuardian has transformed their operations.
            </p>
          </div>

          <Tabs defaultValue="military" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-slate-800 border border-slate-700 p-1">
                <TabsTrigger
                  value="military"
                  className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
                >
                  Military
                </TabsTrigger>
                <TabsTrigger
                  value="emergency"
                  className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
                >
                  Emergency Services
                </TabsTrigger>
                <TabsTrigger
                  value="security"
                  className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
                >
                  Security
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="military" className="space-y-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.military.map((testimonial, index) => (
                  <div
                    key={index}
                    className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 hover:border-emerald-500/30 transition-colors"
                  >
                    <div className="flex items-center gap-4 mb-6">
                      <div className="h-12 w-12 rounded-full bg-slate-700 overflow-hidden">
                        <img src={`/placeholder.svg?height=48&width=48`} alt={testimonial.name} />
                      </div>
                      <div>
                        <h4 className="font-medium">{testimonial.name}</h4>
                        <p className="text-sm text-zinc-400">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-zinc-300 italic mb-4">"{testimonial.quote}"</p>
                    <div className="flex items-center text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="emergency" className="space-y-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.emergency.map((testimonial, index) => (
                  <div
                    key={index}
                    className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 hover:border-emerald-500/30 transition-colors"
                  >
                    <div className="flex items-center gap-4 mb-6">
                      <div className="h-12 w-12 rounded-full bg-slate-700 overflow-hidden">
                        <img src={`/placeholder.svg?height=48&width=48`} alt={testimonial.name} />
                      </div>
                      <div>
                        <h4 className="font-medium">{testimonial.name}</h4>
                        <p className="text-sm text-zinc-400">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-zinc-300 italic mb-4">"{testimonial.quote}"</p>
                    <div className="flex items-center text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="security" className="space-y-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.security.map((testimonial, index) => (
                  <div
                    key={index}
                    className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8 hover:border-emerald-500/30 transition-colors"
                  >
                    <div className="flex items-center gap-4 mb-6">
                      <div className="h-12 w-12 rounded-full bg-slate-700 overflow-hidden">
                        <img src={`/placeholder.svg?height=48&width=48`} alt={testimonial.name} />
                      </div>
                      <div>
                        <h4 className="font-medium">{testimonial.name}</h4>
                        <p className="text-sm text-zinc-400">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-zinc-300 italic mb-4">"{testimonial.quote}"</p>
                    <div className="flex items-center text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-24 bg-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <Badge className="mb-4 py-1.5 px-4 bg-emerald-500/10 text-emerald-500 border-emerald-500/20 rounded-full">
              Technology
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Powered by Advanced Technology</h2>
            <p className="text-xl text-zinc-400 max-w-3xl mx-auto">
              Our platform leverages cutting-edge technologies to deliver reliable and accurate health monitoring.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105 group">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-6 group-hover:bg-emerald-500/20 transition-colors">
                <Cpu className="h-8 w-8 text-emerald-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Edge Computing</h3>
              <p className="text-zinc-400">
                On-device processing ensures data analysis continues even in low-connectivity environments.
              </p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105 group">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-6 group-hover:bg-emerald-500/20 transition-colors">
                <Network className="h-8 w-8 text-emerald-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Mesh Network</h3>
              <p className="text-zinc-400">
                Team members' devices create a resilient mesh network for communication in remote areas.
              </p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105 group">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-6 group-hover:bg-emerald-500/20 transition-colors">
                <Database className="h-8 w-8 text-emerald-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Secure Database</h3>
              <p className="text-zinc-400">
                End-to-end encrypted storage with blockchain verification ensures data integrity.
              </p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-emerald-500/30 transition-all duration-300 transform hover:scale-105 group">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-6 group-hover:bg-emerald-500/20 transition-colors">
                <Sparkles className="h-8 w-8 text-emerald-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">AI Algorithms</h3>
              <p className="text-zinc-400">
                Machine learning models that continuously improve to detect patterns and anomalies.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-emerald-600">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">
            Ready to enhance your mission capabilities?
          </h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto text-white/80">
            Deploy HealthGuardian for your team and experience the next generation of health and location monitoring.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-slate-950 hover:bg-slate-900 text-white text-lg h-14 px-8 rounded-full"
            >
              <Link href="/signup">Get Started Now</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/20 bg-transparent hover:bg-white/10 text-white text-lg h-14 px-8 rounded-full"
            >
              <Link href="/contact">Contact Sales</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 py-16 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <Shield className="h-8 w-8 text-emerald-500" />
                <span className="text-2xl font-bold">HealthGuardian</span>
              </div>
              <p className="text-zinc-400 mb-6">
                Advanced health and location monitoring for mission-critical operations.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
                <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                    <rect x="2" y="9" width="4" height="12"></rect>
                    <circle cx="4" cy="4" r="2"></circle>
                  </svg>
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6">Product</h4>
              <ul className="space-y-4">
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Case Studies
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    API
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6">Company</h4>
              <ul className="space-y-4">
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Partners
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Press
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6">Resources</h4>
              <ul className="space-y-4">
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Webinars
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Training
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    Support
                  </a>
                </li>
                <li>
                  <a href="#" className="text-zinc-400 hover:text-emerald-500 transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-zinc-500 mb-4 md:mb-0">
              © {new Date().getFullYear()} HealthGuardian. All rights reserved. Developed by LPU Students.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-zinc-500 hover:text-emerald-500 transition-colors text-sm">
                Privacy Policy
              </a>
              <a href="#" className="text-zinc-500 hover:text-emerald-500 transition-colors text-sm">
                Terms of Service
              </a>
              <a href="#" className="text-zinc-500 hover:text-emerald-500 transition-colors text-sm">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

const features = [
  {
    icon: Heart,
    title: "Advanced Biometric Monitoring",
    description:
      "Real-time monitoring of heart rate, ECG, SpO₂, body temperature, hydration levels, and stress indicators with Edge AI for local processing.",
  },
  {
    icon: BarChart,
    title: "AI-Powered Health Risk Prediction",
    description:
      "Predicts dehydration, heatstroke, exhaustion, and hypoxia with live risk scoring with colored indicators. Machine learning model adapts to user-specific patterns.",
  },
  {
    icon: MapPin,
    title: "Geo-Tracking & Geo-Fencing",
    description:
      "Multi-satellite integration with smart geo-fencing, mission boundary alerts, location clustering for team coordination, and breadcrumb trail of user movement.",
  },
  {
    icon: AlertTriangle,
    title: "Emergency Detection & Response",
    description:
      "Auto-fall and unconsciousness detection with instant SOS alerts including vitals, live location, and recorded sensor data with push-to-command routing.",
  },
  {
    icon: Zap,
    title: "Self-Sustaining Energy System",
    description:
      "Kinetic motion, thermal, and solar cell harvesting with smart battery analytics and charge health status for extended field operations.",
  },
  {
    icon: Radio,
    title: "Multi-Mode Secure Communication",
    description:
      "Bluetooth Mesh, LoRaWAN, cellular, and satellite uplink with end-to-end encryption and anti-jamming technology for hostile environments.",
  },
  {
    icon: Lock,
    title: "Military-Grade Security",
    description:
      "Blockchain-authenticated data, tamper detection, role-based access control, and biometric login with 2FA for maximum protection.",
  },
  {
    icon: Cloud,
    title: "Edge + Cloud AI Analytics",
    description:
      "On-device predictions with cloud-based health history and pattern recognition for optimal performance even in low-connectivity environments.",
  },
  {
    icon: Users,
    title: "User Roles & Interfaces",
    description:
      "Customized interfaces for field personnel, medical staff, and commanders with role-specific features and minimal clicks for emergency actions.",
  },
]

const testimonials = {
  military: [
    {
      name: "Col. James Anderson",
      role: "Special Operations Command",
      quote:
        "HealthGuardian has revolutionized how we monitor and protect our teams in the field. The real-time health analytics have prevented numerous medical emergencies.",
    },
    {
      name: "Maj. Rebecca Torres",
      role: "Tactical Operations",
      quote:
        "The geo-fencing capabilities are exceptional. We've been able to maintain precise control over our team's movements in high-risk environments.",
    },
    {
      name: "Lt. Col. David Chen",
      role: "Medical Corps",
      quote:
        "As a medical officer, the predictive health analytics have been invaluable. We can now anticipate and prevent health issues before they become critical.",
    },
  ],
  emergency: [
    {
      name: "Dr. Sarah Mitchell",
      role: "Emergency Response Director",
      quote:
        "The predictive health algorithms are incredibly accurate. We've seen a 78% reduction in heat-related incidents since implementing HealthGuardian.",
    },
    {
      name: "John Ramirez",
      role: "Search and Rescue Team Lead",
      quote:
        "The real-time location tracking has dramatically improved our response times. We can now coordinate our teams with unprecedented precision.",
    },
    {
      name: "Dr. Emily Wong",
      role: "Disaster Medicine Specialist",
      quote:
        "HealthGuardian's health monitoring has been a game-changer for our disaster response teams working in extreme conditions.",
    },
  ],
  security: [
    {
      name: "Capt. Michael Reynolds",
      role: "Tactical Team Leader",
      quote:
        "The geo-fencing and location tracking features give us peace of mind when deploying teams in hazardous environments. It's become an essential part of our toolkit.",
    },
    {
      name: "Alexandra Petrov",
      role: "Security Operations Manager",
      quote:
        "The multi-mode communication capabilities ensure our teams stay connected even in the most challenging environments. Absolutely essential for our operations.",
    },
    {
      name: "Robert Jackson",
      role: "Private Security Contractor",
      quote:
        "HealthGuardian's comprehensive monitoring has improved our team's safety and operational effectiveness. The ROI has been substantial.",
    },
  ],
}

const pricingPlans = [
  {
    name: "Standard",
    description: "For small teams and basic operations",
    price: 499,
    popular: false,
    features: [
      "Up to 10 team members",
      "Basic health monitoring",
      "GPS tracking",
      "8-hour battery life",
      "Email support",
      "Basic reporting",
    ],
  },
  {
    name: "Professional",
    description: "For medium teams with advanced needs",
    price: 999,
    popular: true,
    features: [
      "Up to 50 team members",
      "Advanced health monitoring",
      "Real-time geo-fencing",
      "24-hour battery life",
      "Priority support",
      "Advanced analytics",
      "Emergency response system",
      "Environmental monitoring",
    ],
  },
  {
    name: "Enterprise",
    description: "For large organizations with complex requirements",
    price: 2499,
    popular: false,
    features: [
      "Unlimited team members",
      "Full biometric suite",
      "Custom geo-fencing",
      "72-hour battery life",
      "24/7 dedicated support",
      "Custom reporting",
      "Advanced AI predictions",
      "Multi-channel communications",
      "Custom integration options",
    ],
  },
]
