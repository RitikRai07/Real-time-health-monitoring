"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Shield, ArrowLeft, CheckCircle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()

  const validateEmail = (email: string) => {
    return email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) !== null
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Validate email
    if (!email) {
      setError("Please enter your email address")
      return
    }

    if (!validateEmail(email)) {
      setError("Please enter a valid email address")
      return
    }

    setIsLoading(true)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Success
      setIsSubmitted(true)
      toast({
        title: "Reset Link Sent",
        description: "If your email exists in our system, you'll receive a password reset link shortly.",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black z-10"></div>
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover bg-center opacity-30"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.05)_1px,transparent_1px)] bg-[size:40px_40px] z-5"></div>

        {/* Animated gradient background */}
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0 bg-gradient-radial from-emerald-500/20 via-transparent to-transparent animate-pulse-slow"
            style={{ transformOrigin: "center", left: "30%", top: "40%" }}
          ></div>
          <div
            className="absolute inset-0 bg-gradient-radial from-blue-500/20 via-transparent to-transparent animate-pulse-slow animation-delay-1000"
            style={{ transformOrigin: "center", left: "70%", top: "60%" }}
          ></div>
        </div>
      </div>

      <Link href="/" className="flex items-center gap-2 mb-8 z-10 group">
        <Shield className="h-8 w-8 text-emerald-500 group-hover:scale-110 transition-transform" />
        <span className="text-2xl font-bold text-white group-hover:text-emerald-500 transition-colors">
          MissionGuard
        </span>
      </Link>

      <Card className="w-full max-w-md bg-zinc-900/70 backdrop-blur-md border-zinc-800 z-10 animate-fade-in">
        <CardHeader>
          <CardTitle className="text-2xl text-center">Reset Password</CardTitle>
          <CardDescription className="text-center">
            Enter your email address and we'll send you a link to reset your password
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@organization.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    if (error) setError("")
                  }}
                  className={`bg-zinc-800 border-zinc-700 ${error ? "border-red-500 focus-visible:ring-red-500" : ""}`}
                  required
                />
                {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
              </div>

              <Button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <svg
                      className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Sending...
                  </div>
                ) : (
                  <div className="flex items-center justify-center">
                    Send Reset Link
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </div>
                )}
              </Button>
            </form>
          ) : (
            <div className="text-center py-6 animate-fade-in">
              <div className="mx-auto w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="h-6 w-6 text-emerald-500" />
              </div>
              <h3 className="text-xl font-medium mb-2">Check your email</h3>
              <p className="text-zinc-400 mb-6">
                We've sent a password reset link to <span className="font-medium text-white">{email}</span>
              </p>
              <p className="text-sm text-zinc-500">
                Didn't receive the email? Check your spam folder or{" "}
                <button className="text-emerald-500 hover:underline" onClick={() => setIsSubmitted(false)}>
                  try again
                </button>
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center border-t border-zinc-800 pt-6">
          <Link href="/login" className="text-sm text-emerald-500 hover:underline flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to login
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
