"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  Shield,
  User,
  Mail,
  Building,
  Briefcase,
  MapPin,
  Phone,
  Calendar,
  Save,
  ArrowLeft,
  Bell,
  Lock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"

export default function ProfilePage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: "",
    organization: "Special Operations Command",
    phone: "+1 (555) 123-4567",
    location: "Washington, DC",
    bio: "Team leader with 10+ years of experience in field operations and tactical command.",
    joinDate: "January 2020",
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailAlerts: true,
    smsAlerts: true,
    appNotifications: true,
    criticalAlerts: true,
    weeklyReports: true,
    teamUpdates: false,
    maintenanceAlerts: true,
  })

  useEffect(() => {
    if (!user) {
      router.push("/login")
    } else {
      setProfileData({
        firstName: user?.name?.split(" ")[0] || "",
        lastName: user?.name?.split(" ")[1] || "",
        email: user?.email || "",
        role: user?.role || "",
        organization: "Special Operations Command",
        phone: "+1 (555) 123-4567",
        location: "Washington, DC",
        bio: "Team leader with 10+ years of experience in field operations and tactical command.",
        joinDate: "January 2020",
      })
    }
  }, [user, router])

  // Redirect if not logged in
  if (!user) {
    return null
  }

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Profile Updated",
        description: "Your profile information has been updated successfully.",
      })
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "There was an error updating your profile. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleNotificationUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Notification Settings Updated",
        description: "Your notification preferences have been updated successfully.",
      })
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "There was an error updating your notification settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 to-zinc-900">
      <header className="bg-zinc-900/80 backdrop-blur-md border-b border-zinc-800/80 py-4 sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-emerald-500" />
            <span className="text-xl font-bold">MissionGuard</span>
          </Link>

          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="sm">
              <Link href="/dashboard">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>

            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                logout()
                router.push("/login")
              }}
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-8 p-6 bg-zinc-900/50 rounded-xl border border-zinc-800/50 shadow-lg animate-fade-in">
            <Avatar className="h-24 w-24 border-4 border-emerald-500/20 shadow-xl transition-all duration-300 hover:scale-105 hover:border-emerald-500/50">
              <AvatarImage src="/placeholder.svg?height=96&width=96" alt={user?.name} />
              <AvatarFallback className="text-3xl bg-emerald-500/10 text-emerald-500">
                {user?.name
                  ?.split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>

            <div className="text-center md:text-left">
              <div className="inline-block px-3 py-1 mb-2 text-xs font-medium text-emerald-500 bg-emerald-500/10 rounded-full">
                Active Status
              </div>
              <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">
                {user?.name}
              </h1>
              <p className="text-zinc-400 flex items-center justify-center md:justify-start gap-2 mt-1">
                <Briefcase className="h-4 w-4 text-emerald-500" /> {user?.role}
              </p>
            </div>
          </div>

          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="bg-zinc-900/70 border border-zinc-800/70 p-1 rounded-xl overflow-hidden shadow-lg">
              <TabsTrigger
                value="profile"
                className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black transition-all duration-300 rounded-lg"
              >
                <User className="h-4 w-4 mr-2" />
                Profile Information
              </TabsTrigger>
              <TabsTrigger
                value="notifications"
                className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black transition-all duration-300 rounded-lg"
              >
                <Bell className="h-4 w-4 mr-2" />
                Notification Settings
              </TabsTrigger>
              <TabsTrigger
                value="security"
                className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black transition-all duration-300 rounded-lg"
              >
                <Lock className="h-4 w-4 mr-2" />
                Security
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <Card className="bg-zinc-900/80 backdrop-blur-sm border-zinc-800/80 shadow-xl transition-all duration-300 hover:shadow-emerald-500/5 animate-fade-in">
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>Update your personal information and preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleProfileUpdate} className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Personal Information</h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName" className="flex items-center gap-2">
                            <User className="h-4 w-4 text-zinc-400" />
                            First Name
                          </Label>
                          <Input
                            id="firstName"
                            value={profileData.firstName}
                            onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="lastName" className="flex items-center gap-2">
                            <User className="h-4 w-4 text-zinc-400" />
                            Last Name
                          </Label>
                          <Input
                            id="lastName"
                            value={profileData.lastName}
                            onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-zinc-400" />
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                          className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="phone" className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-zinc-400" />
                            Phone
                          </Label>
                          <Input
                            id="phone"
                            value={profileData.phone}
                            onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="location" className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-zinc-400" />
                            Location
                          </Label>
                          <Input
                            id="location"
                            value={profileData.location}
                            onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>
                      </div>
                    </div>

                    <Separator className="bg-zinc-800" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Professional Information</h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="organization" className="flex items-center gap-2">
                            <Building className="h-4 w-4 text-zinc-400" />
                            Organization
                          </Label>
                          <Input
                            id="organization"
                            value={profileData.organization}
                            onChange={(e) => setProfileData({ ...profileData, organization: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="role" className="flex items-center gap-2">
                            <Briefcase className="h-4 w-4 text-zinc-400" />
                            Role
                          </Label>
                          <Input
                            id="role"
                            value={profileData.role}
                            onChange={(e) => setProfileData({ ...profileData, role: e.target.value })}
                            className="bg-zinc-800/80 border-zinc-700/80 focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bio" className="flex items-center gap-2">
                          Bio
                        </Label>
                        <textarea
                          id="bio"
                          rows={4}
                          value={profileData.bio}
                          onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                          className="w-full rounded-md bg-zinc-800/80 border-zinc-700/80 p-3 text-sm focus:border-emerald-500/50 focus:ring-emerald-500/20 transition-all duration-300"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="joinDate" className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-zinc-400" />
                          Join Date
                        </Label>
                        <Input
                          id="joinDate"
                          value={profileData.joinDate}
                          onChange={(e) => setProfileData({ ...profileData, joinDate: e.target.value })}
                          className="bg-zinc-800 border-zinc-700"
                          disabled
                        />
                        <p className="text-xs text-zinc-500">Join date cannot be modified</p>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button type="submit" className="bg-emerald-500 hover:bg-emerald-600" disabled={isLoading}>
                        {isLoading ? (
                          <div className="flex items-center">
                            <svg
                              className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Saving...
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Save className="mr-2 h-4 w-4" />
                            Save Changes
                          </div>
                        )}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications">
              <Card className="bg-zinc-900/80 backdrop-blur-sm border-zinc-800/80 shadow-xl transition-all duration-300 hover:shadow-emerald-500/5 animate-fade-in">
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>Manage how you receive alerts and notifications</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleNotificationUpdate} className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Communication Channels</h3>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="emailAlerts">Email Alerts</Label>
                            <p className="text-sm text-zinc-400">Receive notifications via email</p>
                          </div>
                          <Switch
                            id="emailAlerts"
                            checked={notificationSettings.emailAlerts}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, emailAlerts: checked })
                            }
                          />
                        </div>

                        <Separator className="bg-zinc-800" />

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="smsAlerts">SMS Alerts</Label>
                            <p className="text-sm text-zinc-400">Receive notifications via text message</p>
                          </div>
                          <Switch
                            id="smsAlerts"
                            checked={notificationSettings.smsAlerts}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, smsAlerts: checked })
                            }
                          />
                        </div>

                        <Separator className="bg-zinc-800" />

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="appNotifications">App Notifications</Label>
                            <p className="text-sm text-zinc-400">Receive in-app notifications</p>
                          </div>
                          <Switch
                            id="appNotifications"
                            checked={notificationSettings.appNotifications}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, appNotifications: checked })
                            }
                          />
                        </div>
                      </div>
                    </div>

                    <Separator className="bg-zinc-800" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Notification Types</h3>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="criticalAlerts">Critical Alerts</Label>
                            <p className="text-sm text-zinc-400">Emergency and high-priority notifications</p>
                          </div>
                          <Switch
                            id="criticalAlerts"
                            checked={notificationSettings.criticalAlerts}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, criticalAlerts: checked })
                            }
                          />
                        </div>

                        <Separator className="bg-zinc-800" />

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="weeklyReports">Weekly Reports</Label>
                            <p className="text-sm text-zinc-400">Weekly summary of team performance and metrics</p>
                          </div>
                          <Switch
                            id="weeklyReports"
                            checked={notificationSettings.weeklyReports}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, weeklyReports: checked })
                            }
                          />
                        </div>

                        <Separator className="bg-zinc-800" />

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="teamUpdates">Team Updates</Label>
                            <p className="text-sm text-zinc-400">Updates about team members and assignments</p>
                          </div>
                          <Switch
                            id="teamUpdates"
                            checked={notificationSettings.teamUpdates}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, teamUpdates: checked })
                            }
                          />
                        </div>

                        <Separator className="bg-zinc-800" />

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="maintenanceAlerts">Maintenance Alerts</Label>
                            <p className="text-sm text-zinc-400">System maintenance and update notifications</p>
                          </div>
                          <Switch
                            id="maintenanceAlerts"
                            checked={notificationSettings.maintenanceAlerts}
                            onCheckedChange={(checked) =>
                              setNotificationSettings({ ...notificationSettings, maintenanceAlerts: checked })
                            }
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end">
                      <Button type="submit" className="bg-emerald-500 hover:bg-emerald-600" disabled={isLoading}>
                        {isLoading ? (
                          <div className="flex items-center">
                            <svg
                              className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                              xmlns="http://www.w3.org/2000/svg"
                              fill="none"
                              viewBox="0 0 24 24"
                            >
                              <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                              ></circle>
                              <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                              ></path>
                            </svg>
                            Saving...
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Save className="mr-2 h-4 w-4" />
                            Save Changes
                          </div>
                        )}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="security">
              <Card className="bg-zinc-900/80 backdrop-blur-sm border-zinc-800/80 shadow-xl transition-all duration-300 hover:shadow-emerald-500/5 animate-fade-in">
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>Manage your account security and authentication methods</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Password</h3>

                      <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                        <div>
                          <h4 className="font-medium">Change Password</h4>
                          <p className="text-sm text-zinc-400">Update your account password</p>
                        </div>
                        <Button variant="outline" className="border-zinc-700">
                          Change
                        </Button>
                      </div>
                    </div>

                    <Separator className="bg-zinc-800" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Two-Factor Authentication</h3>

                      <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                        <div>
                          <h4 className="font-medium">Enable 2FA</h4>
                          <p className="text-sm text-zinc-400">Add an extra layer of security to your account</p>
                        </div>
                        <Button variant="outline" className="border-zinc-700">
                          Setup
                        </Button>
                      </div>
                    </div>

                    <Separator className="bg-zinc-800" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Sessions</h3>

                      <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                        <div>
                          <h4 className="font-medium">Active Sessions</h4>
                          <p className="text-sm text-zinc-400">Manage your active login sessions</p>
                        </div>
                        <Button variant="outline" className="border-zinc-700">
                          View
                        </Button>
                      </div>
                    </div>

                    <Separator className="bg-zinc-800" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Account</h3>

                      <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg border border-red-900/20">
                        <div>
                          <h4 className="font-medium text-red-500">Delete Account</h4>
                          <p className="text-sm text-zinc-400">Permanently delete your account and all data</p>
                        </div>
                        <Button variant="destructive">Delete</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
