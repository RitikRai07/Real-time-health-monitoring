"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, Clock, MapPin, Users, CheckCircle2, AlertTriangle, Plus, Trash2, Edit } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"

export function MissionPlanner() {
  const [activeTab, setActiveTab] = useState("active")
  const { toast } = useToast()

  return (
    <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
      <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
        <TabsTrigger value="active" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
          Active Missions
        </TabsTrigger>
        <TabsTrigger value="planned" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
          Planned Missions
        </TabsTrigger>
        <TabsTrigger value="completed" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
          Completed Missions
        </TabsTrigger>
        <TabsTrigger value="create" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
          Create Mission
        </TabsTrigger>
      </TabsList>

      <TabsContent value="active">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Active Missions</h3>
            <Button variant="outline" size="sm" className="border-zinc-800" onClick={() => setActiveTab("create")}>
              <Plus className="h-4 w-4 mr-2" />
              New Mission
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {activeMissions.map((mission) => (
              <MissionCard
                key={mission.id}
                mission={mission}
                onEdit={() => {
                  toast({
                    title: "Edit Mission",
                    description: `Editing mission: ${mission.name}`,
                  })
                }}
              />
            ))}
          </div>
        </div>
      </TabsContent>

      <TabsContent value="planned">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Planned Missions</h3>
            <Button variant="outline" size="sm" className="border-zinc-800" onClick={() => setActiveTab("create")}>
              <Plus className="h-4 w-4 mr-2" />
              New Mission
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {plannedMissions.map((mission) => (
              <MissionCard
                key={mission.id}
                mission={mission}
                onEdit={() => {
                  toast({
                    title: "Edit Mission",
                    description: `Editing mission: ${mission.name}`,
                  })
                }}
              />
            ))}
          </div>
        </div>
      </TabsContent>

      <TabsContent value="completed">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Completed Missions</h3>
            <Select defaultValue="recent">
              <SelectTrigger className="w-[180px] bg-zinc-900 border-zinc-800">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="successful">Successful</SelectItem>
                <SelectItem value="partial">Partially Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 gap-6">
            {completedMissions.map((mission) => (
              <MissionCard
                key={mission.id}
                mission={mission}
                onEdit={() => {
                  toast({
                    title: "View Mission Report",
                    description: `Viewing report for: ${mission.name}`,
                  })
                }}
                editLabel="View Report"
              />
            ))}
          </div>
        </div>
      </TabsContent>

      <TabsContent value="create">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader>
            <CardTitle>Create New Mission</CardTitle>
            <CardDescription>Plan and schedule a new mission for your team</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mission-name">Mission Name</Label>
                    <Input id="mission-name" placeholder="Operation Codename" className="bg-zinc-800 border-zinc-700" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mission-type">Mission Type</Label>
                    <Select>
                      <SelectTrigger id="mission-type" className="bg-zinc-800 border-zinc-700">
                        <SelectValue placeholder="Select mission type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="reconnaissance">Reconnaissance</SelectItem>
                        <SelectItem value="surveillance">Surveillance</SelectItem>
                        <SelectItem value="extraction">Extraction</SelectItem>
                        <SelectItem value="security">Security</SelectItem>
                        <SelectItem value="training">Training Exercise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mission-description">Mission Description</Label>
                  <textarea
                    id="mission-description"
                    rows={3}
                    placeholder="Describe the mission objectives and details"
                    className="w-full rounded-md bg-zinc-800 border-zinc-700 p-3 text-sm"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="mission-date">Start Date</Label>
                    <div className="flex">
                      <Input id="mission-date" type="date" className="bg-zinc-800 border-zinc-700" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mission-time">Start Time</Label>
                    <div className="flex">
                      <Input id="mission-time" type="time" className="bg-zinc-800 border-zinc-700" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mission-duration">Duration (hours)</Label>
                    <div className="flex">
                      <Input
                        id="mission-duration"
                        type="number"
                        min="1"
                        max="72"
                        placeholder="8"
                        className="bg-zinc-800 border-zinc-700"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mission-location">Location</Label>
                  <Input
                    id="mission-location"
                    placeholder="Mission location or coordinates"
                    className="bg-zinc-800 border-zinc-700"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Assign Teams</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-alpha" />
                        <label
                          htmlFor="team-alpha"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Alpha Team
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-bravo" />
                        <label
                          htmlFor="team-bravo"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Bravo Team
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-charlie" />
                        <label
                          htmlFor="team-charlie"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Charlie Team
                        </label>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-delta" />
                        <label
                          htmlFor="team-delta"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Delta Team
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-echo" />
                        <label
                          htmlFor="team-echo"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Echo Team
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="team-medical" />
                        <label
                          htmlFor="team-medical"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Medical Support
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" className="border-zinc-700" onClick={() => setActiveTab("planned")}>
              Cancel
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="border-zinc-700"
                onClick={() => {
                  toast({
                    title: "Mission Saved",
                    description: "Mission has been saved as a draft",
                  })
                  setActiveTab("planned")
                }}
              >
                Save as Draft
              </Button>
              <Button
                className="bg-emerald-500 hover:bg-emerald-600"
                onClick={() => {
                  toast({
                    title: "Mission Created",
                    description: "New mission has been created and scheduled",
                  })
                  setActiveTab("planned")
                }}
              >
                Create Mission
              </Button>
            </div>
          </CardFooter>
        </Card>
      </TabsContent>
    </Tabs>
  )
}

interface Mission {
  id: number
  name: string
  description: string
  status: "active" | "planned" | "completed" | "cancelled"
  startDate: string
  duration: string
  location: string
  teams: string[]
  commander: string
  commanderInitials: string
  objectives?: {
    total: number
    completed: number
  }
  result?: "success" | "partial" | "failed"
}

interface MissionCardProps {
  mission: Mission
  onEdit: () => void
  editLabel?: string
}

function MissionCard({ mission, onEdit, editLabel = "Edit" }: MissionCardProps) {
  return (
    <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-colors">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl">{mission.name}</CardTitle>
            <CardDescription>{mission.description}</CardDescription>
          </div>
          <Badge
            className={
              mission.status === "active"
                ? "bg-emerald-500 text-black"
                : mission.status === "planned"
                  ? "bg-blue-500 text-white"
                  : mission.status === "completed"
                    ? "bg-zinc-500"
                    : "bg-red-500"
            }
          >
            {mission.status.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="h-4 w-4 text-zinc-400" />
              <span>Start: {mission.startDate}</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-zinc-400" />
              <span>Duration: {mission.duration}</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <MapPin className="h-4 w-4 text-zinc-400" />
              <span>Location: {mission.location}</span>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm">
              <Users className="h-4 w-4 text-zinc-400" />
              <span>Teams: {mission.teams.join(", ")}</span>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <Avatar className="h-5 w-5">
                <AvatarFallback className="text-xs">{mission.commanderInitials}</AvatarFallback>
              </Avatar>
              <span>Commander: {mission.commander}</span>
            </div>

            {mission.objectives && (
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-zinc-400" />
                <span>
                  Objectives: {mission.objectives.completed}/{mission.objectives.total} completed
                </span>
              </div>
            )}

            {mission.result && (
              <div className="flex items-center gap-2 text-sm">
                <Badge
                  variant="outline"
                  className={
                    mission.result === "success"
                      ? "border-emerald-500/20 text-emerald-500"
                      : mission.result === "partial"
                        ? "border-amber-500/20 text-amber-500"
                        : "border-red-500/20 text-red-500"
                  }
                >
                  {mission.result === "success"
                    ? "Successful"
                    : mission.result === "partial"
                      ? "Partially Completed"
                      : "Failed"}
                </Badge>
              </div>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        {mission.status === "active" || mission.status === "planned" ? (
          <Button variant="outline" size="sm" className="text-red-500 border-red-500/20 hover:bg-red-500/10">
            <Trash2 className="h-4 w-4 mr-2" />
            Cancel Mission
          </Button>
        ) : (
          <Button variant="outline" size="sm" className="border-zinc-700">
            <AlertTriangle className="h-4 w-4 mr-2" />
            View Issues
          </Button>
        )}

        <Button variant="outline" size="sm" className="border-zinc-700" onClick={onEdit}>
          {mission.status === "completed" ? (
            <>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              {editLabel}
            </>
          ) : (
            <>
              <Edit className="h-4 w-4 mr-2" />
              {editLabel}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

const activeMissions: Mission[] = [
  {
    id: 1,
    name: "Operation Sentinel",
    description: "Surveillance and reconnaissance in Sector 7",
    status: "active",
    startDate: "Today, 08:00",
    duration: "12 hours",
    location: "Sector 7, Northern Region",
    teams: ["Alpha", "Bravo", "Charlie"],
    commander: "Col. James Davidson",
    commanderInitials: "JD",
    objectives: {
      total: 5,
      completed: 2,
    },
  },
]

const plannedMissions: Mission[] = [
  {
    id: 2,
    name: "Operation Nighthawk",
    description: "Night-time surveillance operation in urban environment",
    status: "planned",
    startDate: "Tomorrow, 22:00",
    duration: "8 hours",
    location: "Urban District, Eastern Sector",
    teams: ["Delta", "Echo"],
    commander: "Maj. Sarah Williams",
    commanderInitials: "SW",
  },
  {
    id: 3,
    name: "Operation Bluewater",
    description: "Coastal security and monitoring mission",
    status: "planned",
    startDate: "Jul 15, 06:00",
    duration: "24 hours",
    location: "Southern Coastline",
    teams: ["Alpha", "Charlie"],
    commander: "Capt. Michael Reynolds",
    commanderInitials: "MR",
  },
]

const completedMissions: Mission[] = [
  {
    id: 4,
    name: "Operation Sandstorm",
    description: "Desert terrain reconnaissance and mapping",
    status: "completed",
    startDate: "Jul 5, 05:30",
    duration: "36 hours",
    location: "Western Desert Region",
    teams: ["Bravo", "Delta"],
    commander: "Lt. Col. Robert Chen",
    commanderInitials: "RC",
    objectives: {
      total: 8,
      completed: 8,
    },
    result: "success",
  },
  {
    id: 5,
    name: "Operation Frostbite",
    description: "Cold weather equipment testing and training",
    status: "completed",
    startDate: "Jun 28, 07:00",
    duration: "48 hours",
    location: "Northern Mountains",
    teams: ["Alpha", "Echo", "Medical"],
    commander: "Maj. Emily Parker",
    commanderInitials: "EP",
    objectives: {
      total: 6,
      completed: 4,
    },
    result: "partial",
  },
]
