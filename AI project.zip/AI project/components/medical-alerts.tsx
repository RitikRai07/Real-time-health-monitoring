"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Heart, Thermometer, Droplet, Brain, Pill, Building2, Phone, Clock, ArrowRight, MapPin } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"

export function MedicalAlerts() {
  const [activeTab, setActiveTab] = useState("alerts")
  const { toast } = useToast()

  const handleMedicationDispense = (medication: string, member: string) => {
    toast({
      title: "Medication Dispensed",
      description: `${medication} has been dispensed for ${member}`,
    })
  }

  const handleContactHospital = (hospital: string) => {
    toast({
      title: "Hospital Contacted",
      description: `Emergency services at ${hospital} have been notified`,
    })
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="alerts" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-card border border-border p-1">
          <TabsTrigger
            value="alerts"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Medical Alerts
          </TabsTrigger>
          <TabsTrigger
            value="medications"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Medications
          </TabsTrigger>
          <TabsTrigger
            value="hospitals"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Nearby Hospitals
          </TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-4 mt-4">
          {medicalAlerts.map((alert, index) => (
            <Card
              key={index}
              className={`border-l-4 ${
                alert.severity === "critical"
                  ? "border-l-red-500"
                  : alert.severity === "warning"
                    ? "border-l-amber-500"
                    : "border-l-blue-500"
              }`}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    {alert.type === "heart" && <Heart className="h-5 w-5 text-red-500" />}
                    {alert.type === "temperature" && <Thermometer className="h-5 w-5 text-amber-500" />}
                    {alert.type === "hydration" && <Droplet className="h-5 w-5 text-blue-500" />}
                    {alert.type === "stress" && <Brain className="h-5 w-5 text-purple-500" />}
                    <CardTitle className="text-base">{alert.title}</CardTitle>
                  </div>
                  <Badge
                    className={
                      alert.severity === "critical"
                        ? "bg-red-500/20 text-red-500 border-red-500/20"
                        : alert.severity === "warning"
                          ? "bg-amber-500/20 text-amber-500 border-amber-500/20"
                          : "bg-blue-500/20 text-blue-500 border-blue-500/20"
                    }
                  >
                    {alert.severity}
                  </Badge>
                </div>
                <CardDescription>{alert.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-4">
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback>
                          {alert.member.split(" ")[0][0]}
                          {alert.member.split(" ")[1][0]}
                        </AvatarFallback>
                      </Avatar>
                      <span>{alert.member}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{alert.time}</span>
                    </div>
                  </div>

                  {alert.vitalSigns && (
                    <div className="grid grid-cols-2 gap-4 mt-2">
                      {alert.vitalSigns.map((vital, idx) => (
                        <div key={idx} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">{vital.name}</span>
                            <span className="font-medium">
                              {vital.value} {vital.unit}
                            </span>
                          </div>
                          <Progress
                            value={vital.percentage}
                            className="h-1.5"
                            indicatorClassName={
                              vital.status === "normal"
                                ? "bg-emerald-500"
                                : vital.status === "warning"
                                  ? "bg-amber-500"
                                  : "bg-red-500"
                            }
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex flex-col gap-2 mt-2">
                    <div className="text-sm font-medium">Recommended Actions:</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {alert.recommendedMedications.map((med, idx) => (
                        <Button
                          key={idx}
                          variant="outline"
                          size="sm"
                          className="justify-start"
                          onClick={() => handleMedicationDispense(med, alert.member)}
                        >
                          <Pill className="h-4 w-4 mr-2 text-primary" />
                          {med}
                        </Button>
                      ))}
                      {alert.severity === "critical" && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleContactHospital("Central Medical Center")}
                        >
                          <Phone className="h-4 w-4 mr-2" />
                          Contact Emergency
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="medications" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {medications.map((med, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Pill className="h-5 w-5 text-primary" />
                      {med.name}
                    </CardTitle>
                    <Badge className="bg-primary/20 text-primary border-primary/20">{med.type}</Badge>
                  </div>
                  <CardDescription>{med.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Dosage:</span>
                      <span>{med.dosage}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Administration:</span>
                      <span>{med.administration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Stock Level:</span>
                      <span>{med.stockLevel} units</span>
                    </div>
                    <Progress
                      value={(med.stockLevel / med.maxStock) * 100}
                      className="h-1.5 mt-1"
                      indicatorClassName={
                        med.stockLevel > med.maxStock * 0.5
                          ? "bg-emerald-500"
                          : med.stockLevel > med.maxStock * 0.2
                            ? "bg-amber-500"
                            : "bg-red-500"
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="hospitals" className="space-y-4 mt-4">
          {nearbyHospitals.map((hospital, index) => (
            <Card key={index}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-primary" />
                    {hospital.name}
                  </CardTitle>
                  <Badge
                    className={
                      hospital.status === "Open"
                        ? "bg-emerald-500/20 text-emerald-500 border-emerald-500/20"
                        : "bg-amber-500/20 text-amber-500 border-amber-500/20"
                    }
                  >
                    {hospital.status}
                  </Badge>
                </div>
                <CardDescription className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {hospital.distance} km away • {hospital.address}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Emergency:</span>
                      <span>{hospital.emergency ? "Available" : "Unavailable"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Trauma Center:</span>
                      <span>Level {hospital.traumaLevel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Beds Available:</span>
                      <span>{hospital.bedsAvailable}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Response Time:</span>
                      <span>{hospital.responseTime} min</span>
                    </div>
                  </div>

                  <div className="flex justify-between gap-2 mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        toast({
                          title: "Hospital Details",
                          description: `Viewing detailed information for ${hospital.name}`,
                        })
                      }
                    >
                      View Details
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleContactHospital(hospital.name)}>
                      Contact
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Sample data
const medicalAlerts = [
  {
    type: "temperature",
    title: "High Body Temperature",
    description: "Body temperature exceeding safe threshold",
    severity: "warning",
    member: "Sarah Miller",
    time: "10 minutes ago",
    vitalSigns: [
      { name: "Temperature", value: 38.2, unit: "°C", percentage: 80, status: "warning" },
      { name: "Heart Rate", value: 95, unit: "bpm", percentage: 65, status: "normal" },
      { name: "Blood Pressure", value: "125/85", unit: "mmHg", percentage: 60, status: "normal" },
      { name: "Respiratory Rate", value: 18, unit: "bpm", percentage: 55, status: "normal" },
    ],
    recommendedMedications: ["Acetaminophen 500mg", "Ibuprofen 400mg"],
  },
  {
    type: "hydration",
    title: "Severe Dehydration",
    description: "Critically low hydration levels detected",
    severity: "critical",
    member: "Michael Keller",
    time: "23 minutes ago",
    vitalSigns: [
      { name: "Hydration", value: 68, unit: "%", percentage: 68, status: "critical" },
      { name: "Heart Rate", value: 110, unit: "bpm", percentage: 85, status: "warning" },
      { name: "Blood Pressure", value: "110/70", unit: "mmHg", percentage: 45, status: "warning" },
      { name: "Temperature", value: 37.8, unit: "°C", percentage: 70, status: "warning" },
    ],
    recommendedMedications: ["Oral Rehydration Solution", "Electrolyte Supplement"],
  },
  {
    type: "heart",
    title: "Elevated Heart Rate",
    description: "Heart rate above normal range during rest period",
    severity: "warning",
    member: "John Davis",
    time: "45 minutes ago",
    vitalSigns: [
      { name: "Heart Rate", value: 105, unit: "bpm", percentage: 80, status: "warning" },
      { name: "Blood Pressure", value: "135/90", unit: "mmHg", percentage: 75, status: "warning" },
      { name: "Oxygen Saturation", value: 96, unit: "%", percentage: 96, status: "normal" },
      { name: "Respiratory Rate", value: 20, unit: "bpm", percentage: 65, status: "normal" },
    ],
    recommendedMedications: ["Propranolol 10mg", "Magnesium Supplement"],
  },
  {
    type: "stress",
    title: "High Stress Level",
    description: "Elevated stress indicators detected during mission",
    severity: "warning",
    member: "Alex Thompson",
    time: "1 hour ago",
    vitalSigns: [
      { name: "Stress Index", value: 78, unit: "%", percentage: 78, status: "warning" },
      { name: "Heart Rate", value: 88, unit: "bpm", percentage: 65, status: "normal" },
      { name: "Blood Pressure", value: "130/85", unit: "mmHg", percentage: 70, status: "normal" },
      { name: "Cortisol Level", value: 22, unit: "μg/dL", percentage: 75, status: "warning" },
    ],
    recommendedMedications: ["Anxiolytic 5mg", "L-Theanine 200mg"],
  },
]

const medications = [
  {
    name: "Acetaminophen",
    type: "Analgesic",
    description: "Pain reliever and fever reducer",
    dosage: "500mg tablets",
    administration: "Oral, every 4-6 hours",
    stockLevel: 45,
    maxStock: 50,
  },
  {
    name: "Ibuprofen",
    type: "NSAID",
    description: "Anti-inflammatory and pain reliever",
    dosage: "400mg tablets",
    administration: "Oral, every 6-8 hours",
    stockLevel: 32,
    maxStock: 50,
  },
  {
    name: "Oral Rehydration Solution",
    type: "Electrolyte",
    description: "Replenishes fluids and electrolytes",
    dosage: "Powder sachets",
    administration: "Dissolve in water, as needed",
    stockLevel: 28,
    maxStock: 40,
  },
  {
    name: "Propranolol",
    type: "Beta Blocker",
    description: "Reduces heart rate and blood pressure",
    dosage: "10mg tablets",
    administration: "Oral, as directed",
    stockLevel: 15,
    maxStock: 30,
  },
  {
    name: "Anxiolytic",
    type: "Anti-anxiety",
    description: "Reduces stress and anxiety",
    dosage: "5mg tablets",
    administration: "Oral, as needed",
    stockLevel: 8,
    maxStock: 20,
  },
  {
    name: "Electrolyte Supplement",
    type: "Supplement",
    description: "Replenishes essential electrolytes",
    dosage: "Tablets or powder",
    administration: "Oral, with water",
    stockLevel: 22,
    maxStock: 30,
  },
]

const nearbyHospitals = [
  {
    name: "Central Medical Center",
    status: "Open",
    distance: 3.2,
    address: "1250 Medical Park Dr, Sector 7",
    emergency: true,
    traumaLevel: 1,
    bedsAvailable: 12,
    responseTime: 8,
  },
  {
    name: "Northern Regional Hospital",
    status: "Open",
    distance: 5.7,
    address: "450 Healthcare Blvd, Northern District",
    emergency: true,
    traumaLevel: 2,
    bedsAvailable: 8,
    responseTime: 12,
  },
  {
    name: "Eastern Field Medical Unit",
    status: "Limited Hours",
    distance: 2.1,
    address: "Mobile Unit, Eastern Sector",
    emergency: true,
    traumaLevel: 3,
    bedsAvailable: 4,
    responseTime: 5,
  },
]
