"use client"

import { useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Shield,
  Heart,
  AlertTriangle,
  Users,
  Settings,
  MapPin,
  Wind,
  Radio,
  Layers,
  Zap,
  FileText,
  HelpCircle,
  X,
  Pill,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

interface CustomSidebarProps {
  isOpen: boolean
  onClose: () => void
  notificationCount?: number
}

export function CustomSidebar({ isOpen, onClose, notificationCount = 0 }: CustomSidebarProps) {
  const pathname = usePathname()

  const isActive = (path: string) => {
    if (path === "/dashboard" && pathname === "/dashboard") {
      return true
    }
    if (path !== "/dashboard" && pathname?.startsWith(path)) {
      return true
    }
    return false
  }

  // Close sidebar on route change on mobile
  useEffect(() => {
    if (isOpen && window.innerWidth < 768) {
      onClose()
    }
  }, [pathname, isOpen, onClose])

  return (
    <div
      className={`fixed inset-y-0 left-0 z-50 w-64 bg-zinc-900/90 backdrop-blur-sm border-r border-zinc-800/70 transform transition-transform duration-300 ease-in-out ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      } md:relative md:translate-x-0`}
    >
      <div className="flex h-full flex-col">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-zinc-800/70">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">HealthGuardian</span>
          </div>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Sidebar Content */}
        <div className="flex-1 overflow-auto py-4 px-3 custom-scrollbar">
          <nav className="space-y-6">
            <div className="space-y-1">
              <Link
                href="/dashboard"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Shield className="h-5 w-5" />
                <span>Overview</span>
              </Link>
              <Link
                href="/dashboard/team"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/team") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Users className="h-5 w-5" />
                <span>Team</span>
              </Link>
              <Link
                href="/dashboard/map"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/map") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <MapPin className="h-5 w-5" />
                <span>Map</span>
              </Link>
              <Link
                href="/dashboard/health"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/health") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Heart className="h-5 w-5" />
                <span>Health</span>
              </Link>
              <Link
                href="/dashboard/medical"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/medical") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Pill className="h-5 w-5" />
                <span>Medical</span>
              </Link>
              <Link
                href="/dashboard/alerts"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors relative ${
                  isActive("/dashboard/alerts") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <AlertTriangle className="h-5 w-5" />
                <span>Alerts</span>
                {notificationCount > 0 && <Badge className="ml-auto bg-red-500 text-white">{notificationCount}</Badge>}
              </Link>
            </div>

            <Separator />

            <div className="space-y-1">
              <Link
                href="/dashboard/environment"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/environment")
                    ? "bg-primary/10 text-primary"
                    : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Wind className="h-5 w-5" />
                <span>Environment</span>
              </Link>
              <Link
                href="/dashboard/comms"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/comms") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Radio className="h-5 w-5" />
                <span>Comms</span>
              </Link>
              <Link
                href="/dashboard/missions"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/missions") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Layers className="h-5 w-5" />
                <span>Missions</span>
              </Link>
              <Link
                href="/dashboard/equipment"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/equipment") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <Zap className="h-5 w-5" />
                <span>Equipment</span>
              </Link>
              <Link
                href="/dashboard/reports"
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive("/dashboard/reports") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
                }`}
              >
                <FileText className="h-5 w-5" />
                <span>Reports</span>
              </Link>
            </div>
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-zinc-800/70">
          <div className="space-y-1">
            <Link
              href="/dashboard/help"
              className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive("/dashboard/help") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
              }`}
            >
              <HelpCircle className="h-5 w-5" />
              <span>Help</span>
            </Link>
            <Link
              href="/dashboard/settings"
              className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive("/dashboard/settings") ? "bg-primary/10 text-primary" : "hover:bg-muted hover:bg-primary/5"
              }`}
            >
              <Settings className="h-5 w-5" />
              <span>Settings</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
