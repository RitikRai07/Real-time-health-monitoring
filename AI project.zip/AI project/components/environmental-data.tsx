"use client"

import { useState } from "react"
import { Thermometer, Droplet, Wind, CloudRain, Compass, AlertTriangle, Zap } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartGrid,
  ChartLine,
  ChartXAxis,
  ChartYAxis,
  ChartArea,
} from "@/components/ui/chart"

export function EnvironmentalData() {
  const [activeTab, setActiveTab] = useState("current")

  // Mock data for environmental conditions
  const environmentalData = {
    temperature: { value: 32, unit: "°C", status: "warning", max: 50, min: 0 },
    humidity: { value: 78, unit: "%", status: "warning", max: 100, min: 0 },
    windSpeed: { value: 15, unit: "km/h", status: "normal", max: 50, min: 0 },
    airQuality: { value: 85, unit: "AQI", status: "good", max: 100, min: 0 },
    pressure: { value: 1013, unit: "hPa", status: "normal", max: 1050, min: 950 },
    radiation: { value: 0.12, unit: "μSv/h", status: "normal", max: 1, min: 0 },
    toxicGases: { value: 0, unit: "ppm", status: "normal", max: 10, min: 0 },
  }

  // Mock data for historical chart
  const historicalData = [
    { time: "08:00", temperature: 28, humidity: 65, windSpeed: 10, airQuality: 90 },
    { time: "09:00", temperature: 29, humidity: 68, windSpeed: 12, airQuality: 88 },
    { time: "10:00", temperature: 30, humidity: 70, windSpeed: 13, airQuality: 87 },
    { time: "11:00", temperature: 31, humidity: 72, windSpeed: 14, airQuality: 86 },
    { time: "12:00", temperature: 32, humidity: 75, windSpeed: 15, airQuality: 85 },
    { time: "13:00", temperature: 33, humidity: 78, windSpeed: 16, airQuality: 83 },
    { time: "14:00", temperature: 34, humidity: 80, windSpeed: 17, airQuality: 80 },
    { time: "15:00", temperature: 33, humidity: 79, windSpeed: 16, airQuality: 82 },
    { time: "16:00", temperature: 32, humidity: 77, windSpeed: 15, airQuality: 84 },
    { time: "17:00", temperature: 31, humidity: 75, windSpeed: 14, airQuality: 85 },
  ]

  // Environmental hazards
  const hazards = [
    {
      id: 1,
      type: "heat",
      icon: Thermometer,
      title: "Heat Advisory",
      description: "High temperature may cause heat exhaustion",
      severity: "warning",
    },
    {
      id: 2,
      type: "humidity",
      icon: Droplet,
      title: "High Humidity",
      description: "Increased risk of dehydration and heat stress",
      severity: "warning",
    },
    {
      id: 3,
      type: "storm",
      icon: CloudRain,
      title: "Approaching Storm",
      description: "Thunderstorm expected in 2-3 hours",
      severity: "warning",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "good":
        return "emerald"
      case "normal":
        return "emerald"
      case "warning":
        return "amber"
      case "danger":
        return "red"
      default:
        return "emerald"
    }
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-zinc-800 border border-zinc-700 p-1">
          <TabsTrigger value="current" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Current Conditions
          </TabsTrigger>
          <TabsTrigger value="historical" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Historical Data
          </TabsTrigger>
          <TabsTrigger value="hazards" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Hazard Alerts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="current">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Thermometer className="h-5 w-5 text-amber-500" />
                  Temperature
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.temperature.value}
                  {environmentalData.temperature.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.temperature.status)}-500/20 text-${getStatusColor(environmentalData.temperature.status)}-500`}
                    >
                      {environmentalData.temperature.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.temperature.value}
                    max={environmentalData.temperature.max}
                    min={environmentalData.temperature.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.temperature.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Droplet className="h-5 w-5 text-blue-500" />
                  Humidity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.humidity.value}
                  {environmentalData.humidity.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.humidity.status)}-500/20 text-${getStatusColor(environmentalData.humidity.status)}-500`}
                    >
                      {environmentalData.humidity.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.humidity.value}
                    max={environmentalData.humidity.max}
                    min={environmentalData.humidity.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.humidity.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wind className="h-5 w-5 text-emerald-500" />
                  Wind Speed
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.windSpeed.value}
                  {environmentalData.windSpeed.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.windSpeed.status)}-500/20 text-${getStatusColor(environmentalData.windSpeed.status)}-500`}
                    >
                      {environmentalData.windSpeed.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.windSpeed.value}
                    max={environmentalData.windSpeed.max}
                    min={environmentalData.windSpeed.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.windSpeed.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wind className="h-5 w-5 text-emerald-500" />
                  Air Quality
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.airQuality.value}
                  {environmentalData.airQuality.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.airQuality.status)}-500/20 text-${getStatusColor(environmentalData.airQuality.status)}-500`}
                    >
                      {environmentalData.airQuality.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.airQuality.value}
                    max={environmentalData.airQuality.max}
                    min={environmentalData.airQuality.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.airQuality.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Compass className="h-5 w-5 text-blue-500" />
                  Barometric Pressure
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.pressure.value}
                  {environmentalData.pressure.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.pressure.status)}-500/20 text-${getStatusColor(environmentalData.pressure.status)}-500`}
                    >
                      {environmentalData.pressure.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.pressure.value}
                    max={environmentalData.pressure.max}
                    min={environmentalData.pressure.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.pressure.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-800 border-zinc-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className="h-5 w-5 text-emerald-500" />
                  Radiation Level
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  {environmentalData.radiation.value}
                  {environmentalData.radiation.unit}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Status</span>
                    <Badge
                      variant="outline"
                      className={`border-${getStatusColor(environmentalData.radiation.status)}-500/20 text-${getStatusColor(environmentalData.radiation.status)}-500`}
                    >
                      {environmentalData.radiation.status}
                    </Badge>
                  </div>
                  <Progress
                    value={environmentalData.radiation.value}
                    max={environmentalData.radiation.max}
                    min={environmentalData.radiation.min}
                    className="h-2 bg-zinc-700"
                    indicatorClassName={`bg-${getStatusColor(environmentalData.radiation.status)}-500`}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="historical">
          <Card className="bg-zinc-800 border-zinc-700">
            <CardHeader>
              <CardTitle>Environmental Trends</CardTitle>
              <CardDescription>Historical data over the past 10 hours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer>
                  <Chart data={historicalData}>
                    <ChartGrid horizontal vertical />
                    <ChartXAxis dataKey="time" />
                    <ChartYAxis />

                    <ChartLine dataKey="temperature" stroke="#f97316" strokeWidth={2} dot={false} name="Temperature" />
                    <ChartArea dataKey="temperature" fill="#f97316" fillOpacity={0.1} stroke="transparent" />

                    <ChartLine dataKey="humidity" stroke="#3b82f6" strokeWidth={2} dot={false} name="Humidity" />
                    <ChartArea dataKey="humidity" fill="#3b82f6" fillOpacity={0.1} stroke="transparent" />

                    <ChartLine dataKey="windSpeed" stroke="#10b981" strokeWidth={2} dot={false} name="Wind Speed" />
                    <ChartArea dataKey="windSpeed" fill="#10b981" fillOpacity={0.1} stroke="transparent" />

                    <ChartLine dataKey="airQuality" stroke="#8b5cf6" strokeWidth={2} dot={false} name="Air Quality" />
                    <ChartArea dataKey="airQuality" fill="#8b5cf6" fillOpacity={0.1} stroke="transparent" />

                    <ChartTooltip
                      content={
                        <ChartTooltipContent
                          className="bg-zinc-900 border border-zinc-800"
                          labelClassName="text-zinc-400"
                        />
                      }
                    />
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hazards">
          <Card className="bg-zinc-800 border-zinc-700">
            <CardHeader>
              <CardTitle>Environmental Hazards</CardTitle>
              <CardDescription>Current alerts and warnings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {hazards.map((hazard) => (
                  <div
                    key={hazard.id}
                    className={`flex gap-4 p-4 rounded-md border ${
                      hazard.severity === "critical"
                        ? "bg-red-500/10 border-red-500/20"
                        : "bg-amber-500/10 border-amber-500/20"
                    }`}
                  >
                    <div
                      className={`mt-0.5 p-2 rounded-full bg-${hazard.severity === "critical" ? "red" : "amber"}-500/20`}
                    >
                      <hazard.icon className={`h-5 w-5 text-${hazard.severity === "critical" ? "red" : "amber"}-500`} />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium flex items-center gap-2">
                          {hazard.title}
                          {hazard.severity === "critical" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                        </h4>
                        <Badge
                          variant="outline"
                          className={`${
                            hazard.severity === "critical"
                              ? "border-red-500/20 text-red-500"
                              : "border-amber-500/20 text-amber-500"
                          }`}
                        >
                          {hazard.severity}
                        </Badge>
                      </div>

                      <p className="text-sm text-zinc-400">{hazard.description}</p>
                    </div>
                  </div>
                ))}

                {hazards.length === 0 && (
                  <div className="text-center py-8 text-zinc-500">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-20" />
                    <p>No active environmental hazards detected</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
