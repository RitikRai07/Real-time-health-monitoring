"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Heart, MapPin, Radio, Thermometer, Droplet, Clock, AlertTriangle, CheckCircle2 } from "lucide-react"

export function LiveFeed() {
  const [events, setEvents] = useState<FeedEvent[]>(initialEvents)

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // 30% chance to add a new event
      if (Math.random() < 0.3) {
        const newEvent = generateRandomEvent(events.length + 1)
        setEvents((prev) => [newEvent, ...prev.slice(0, 19)]) // Keep only the 20 most recent events
      }
    }, 10000) // Check every 10 seconds

    return () => clearInterval(interval)
  }, [events])

  return (
    <div className="h-[400px] overflow-auto pr-2">
      <div className="space-y-4">
        {events.map((event) => (
          <FeedEventItem key={event.id} event={event} />
        ))}
      </div>
    </div>
  )
}

interface FeedEvent {
  id: number
  type: "health" | "location" | "communication" | "system" | "mission"
  title: string
  description: string
  timestamp: string
  member?: {
    name: string
    avatar?: string
    initials: string
  }
  status?: "success" | "warning" | "error" | "info"
}

function FeedEventItem({ event }: { event: FeedEvent }) {
  const getIcon = () => {
    switch (event.type) {
      case "health":
        if (event.title.includes("Temperature")) return Thermometer
        if (event.title.includes("Hydration")) return Droplet
        return Heart
      case "location":
        return MapPin
      case "communication":
        return Radio
      case "system":
      case "mission":
      default:
        return Clock
    }
  }

  const Icon = getIcon()

  const getStatusColor = () => {
    switch (event.status) {
      case "success":
        return "bg-emerald-500/20 text-emerald-500"
      case "warning":
        return "bg-amber-500/20 text-amber-500"
      case "error":
        return "bg-red-500/20 text-red-500"
      case "info":
      default:
        return "bg-blue-500/20 text-blue-500"
    }
  }

  const getStatusIcon = () => {
    switch (event.status) {
      case "success":
        return CheckCircle2
      case "warning":
      case "error":
        return AlertTriangle
      case "info":
      default:
        return Clock
    }
  }

  const StatusIcon = getStatusIcon()

  return (
    <div className="flex gap-4 p-3 rounded-md bg-zinc-800/50 border border-zinc-800 hover:border-zinc-700 transition-colors">
      <div className={`mt-0.5 p-2 rounded-full ${getStatusColor()}`}>
        <Icon className="h-4 w-4" />
      </div>

      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div>
            <h4 className="font-medium text-sm">{event.title}</h4>
            <p className="text-xs text-zinc-400 mt-0.5">{event.description}</p>
          </div>

          {event.member && (
            <Avatar className="h-8 w-8">
              {event.member.avatar ? <AvatarImage src={event.member.avatar} alt={event.member.name} /> : null}
              <AvatarFallback>{event.member.initials}</AvatarFallback>
            </Avatar>
          )}
        </div>

        <div className="flex justify-between items-center mt-2">
          <span className="text-xs text-zinc-500">{event.timestamp}</span>

          <Badge variant="outline" className={`${getStatusColor()} border-opacity-20`}>
            <StatusIcon className="h-3 w-3 mr-1" />
            <span>{event.status || "info"}</span>
          </Badge>
        </div>
      </div>
    </div>
  )
}

const initialEvents: FeedEvent[] = [
  {
    id: 1,
    type: "mission",
    title: "Mission Started",
    description: "Operation Sentinel has been initiated",
    timestamp: "08:00 AM",
    status: "success",
  },
  {
    id: 2,
    type: "location",
    title: "Checkpoint Reached",
    description: "Alpha Team has reached Checkpoint 1",
    timestamp: "08:15 AM",
    member: {
      name: "John D.",
      initials: "JD",
    },
    status: "success",
  },
  {
    id: 3,
    type: "health",
    title: "Hydration Alert",
    description: "Bravo-1 hydration level at 68%",
    timestamp: "08:37 AM",
    member: {
      name: "Michael K.",
      initials: "MK",
    },
    status: "warning",
  },
  {
    id: 4,
    type: "communication",
    title: "Communication Check",
    description: "All teams reporting clear communications",
    timestamp: "09:00 AM",
    status: "success",
  },
  {
    id: 5,
    type: "location",
    title: "Geo-fence Alert",
    description: "Charlie-3 approaching mission boundary",
    timestamp: "09:18 AM",
    member: {
      name: "Alex T.",
      initials: "AT",
    },
    status: "warning",
  },
  {
    id: 6,
    type: "health",
    title: "Temperature Alert",
    description: "Alpha-2 body temperature at 38.2°C",
    timestamp: "09:45 AM",
    member: {
      name: "Sarah M.",
      initials: "SM",
    },
    status: "warning",
  },
  {
    id: 7,
    type: "system",
    title: "Battery Status",
    description: "All devices reporting normal battery levels",
    timestamp: "10:00 AM",
    status: "info",
  },
]

function generateRandomEvent(id: number): FeedEvent {
  const types = ["health", "location", "communication", "system", "mission"] as const
  const statuses = ["success", "warning", "error", "info"] as const
  const members = [
    { name: "John D.", initials: "JD" },
    { name: "Sarah M.", initials: "SM" },
    { name: "Michael K.", initials: "MK" },
    { name: "Emily R.", initials: "ER" },
    { name: "Alex T.", initials: "AT" },
  ]

  const type = types[Math.floor(Math.random() * types.length)]
  const status = statuses[Math.floor(Math.random() * statuses.length)]
  const includeMember = Math.random() > 0.3
  const member = includeMember ? members[Math.floor(Math.random() * members.length)] : undefined

  const now = new Date()
  const hours = now.getHours().toString().padStart(2, "0")
  const minutes = now.getMinutes().toString().padStart(2, "0")
  const timestamp = `${hours}:${minutes}`

  // Generate title and description based on type
  let title = ""
  let description = ""

  switch (type) {
    case "health":
      const healthMetrics = ["Heart Rate", "Temperature", "Hydration", "Stress Level"]
      const metric = healthMetrics[Math.floor(Math.random() * healthMetrics.length)]
      title = `${metric} Update`

      if (status === "warning" || status === "error") {
        title = `${metric} Alert`
        description = `${member?.name || "Team member"} ${metric.toLowerCase()} ${status === "error" ? "critically " : ""}outside normal range`
      } else {
        description = `${member?.name || "Team member"} ${metric.toLowerCase()} within normal parameters`
      }
      break

    case "location":
      const locationEvents = ["Checkpoint Reached", "Position Update", "Geo-fence Status", "Movement Pattern"]
      title = locationEvents[Math.floor(Math.random() * locationEvents.length)]

      if (title === "Checkpoint Reached") {
        const checkpoint = Math.floor(Math.random() * 5) + 1
        description = `${member?.name || "Team member"} has reached Checkpoint ${checkpoint}`
      } else if (title === "Geo-fence Status" && (status === "warning" || status === "error")) {
        description = `${member?.name || "Team member"} ${status === "error" ? "has breached" : "is approaching"} mission boundary`
      } else {
        description = `${member?.name || "Team member"} location updated successfully`
      }
      break

    case "communication":
      title = "Communication Status"
      if (status === "warning" || status === "error") {
        description = `${status === "error" ? "Lost" : "Degraded"} communication with ${member?.name || "team member"}`
      } else {
        description = "All communication channels operating normally"
      }
      break

    case "system":
      const systemComponents = ["Battery", "Sensors", "GPS", "Communication Module"]
      const component = systemComponents[Math.floor(Math.random() * systemComponents.length)]
      title = `${component} Status`

      if (status === "warning" || status === "error") {
        description = `${component} ${status === "error" ? "failure" : "issue"} detected ${member ? `for ${member.name}` : "in system"}`
      } else {
        description = `${component} operating within normal parameters`
      }
      break

    case "mission":
      const missionEvents = ["Mission Update", "Objective Completed", "New Instructions", "Schedule Change"]
      title = missionEvents[Math.floor(Math.random() * missionEvents.length)]

      if (title === "Objective Completed") {
        const objective = ["Alpha", "Bravo", "Charlie", "Delta"][Math.floor(Math.random() * 4)]
        description = `Objective ${objective} has been successfully completed`
      } else if (title === "New Instructions") {
        description = "New mission instructions have been issued to all teams"
      } else {
        description = "Mission progressing according to plan"
      }
      break
  }

  return {
    id,
    type,
    title,
    description,
    timestamp,
    member,
    status,
  }
}
