import type * as React from "react"

const Chart = ({ children, ...props }: React.ComponentProps<"svg">) => {
  return (
    <svg viewBox="0 0 100 100" {...props}>
      {children}
    </svg>
  )
}

const ChartContainer = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>
}

const ChartGrid = ({ horizontal, vertical }: { horizontal?: boolean; vertical?: boolean }) => {
  return (
    <>
      {horizontal && <line x1="0" y1="25" x2="100" y2="25" stroke="gray" strokeDasharray="4 2" />}
      {vertical && <line x1="50" y1="0" x2="50" y2="100" stroke="gray" strokeDasharray="4 2" />}
    </>
  )
}

const ChartLine = ({ dataKey, stroke, strokeWidth, activeDot, dot, type, yAxisId, opacity }: any) => {
  return <path d="M0,80 L20,20 L40,50 L60,30 L80,60 L100,40" stroke={stroke} strokeWidth={strokeWidth} fill="none" />
}

const ChartXAxis = ({ dataKey }: { dataKey: string }) => {
  return null
}

const ChartYAxis = () => {
  return null
}

const ChartArea = ({ dataKey, fill, fillOpacity, stroke, yAxisId, opacity }: any) => {
  return <rect width="100" height="100" fill={fill} opacity={fillOpacity} />
}

const ChartTooltip = ({ content }: { content: React.ReactNode }) => {
  return <>{content}</>
}

const ChartTooltipContent = ({ className, labelClassName }: { className?: string; labelClassName?: string }) => {
  return <div className={className}>Tooltip Content</div>
}

const ChartLegend = ({ children }: { children: React.ReactNode }) => {
  return <div>{children}</div>
}

const ChartLegendItem = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <div className={className}>{children}</div>
}

const ChartLegendItemLabel = ({ children }: { children: React.ReactNode }) => {
  return <span>{children}</span>
}

const ChartLegendItemValue = ({ children }: { children: React.ReactNode }) => {
  return <span>{children}</span>
}

const ChartLegendItemColor = ({ color }: { color: string }) => {
  return <span style={{ color }}>{color}</span>
}

export {
  Chart,
  ChartContainer,
  ChartGrid,
  ChartLine,
  ChartXAxis,
  ChartYAxis,
  ChartArea,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
  ChartLegendItemLabel,
  ChartLegendItemValue,
  ChartLegendItemColor,
}
