"use client"

import { Heart, Thermometer, Droplet, Brain } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface TeamVitalsProps {
  showDetails?: boolean
}

export function TeamVitals({ showDetails = false }: TeamVitalsProps) {
  // Mock data for team members
  const teamMembers = [
    {
      id: 1,
      name: "John D.",
      role: "Alpha-1",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "healthy",
      vitals: {
        heartRate: { value: 72, unit: "bpm", status: "normal" },
        temperature: { value: 36.8, unit: "°C", status: "normal" },
        hydration: { value: 92, unit: "%", status: "normal" },
        stress: { value: 25, unit: "%", status: "normal" },
      },
    },
    {
      id: 2,
      name: "Sarah M.",
      role: "Alpha-2",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "warning",
      vitals: {
        heartRate: { value: 85, unit: "bpm", status: "normal" },
        temperature: { value: 38.2, unit: "°C", status: "warning" },
        hydration: { value: 85, unit: "%", status: "normal" },
        stress: { value: 40, unit: "%", status: "normal" },
      },
    },
    {
      id: 3,
      name: "Michael K.",
      role: "Bravo-1",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "warning",
      vitals: {
        heartRate: { value: 78, unit: "bpm", status: "normal" },
        temperature: { value: 37.1, unit: "°C", status: "normal" },
        hydration: { value: 68, unit: "%", status: "warning" },
        stress: { value: 35, unit: "%", status: "normal" },
      },
    },
    {
      id: 4,
      name: "Emily R.",
      role: "Bravo-2",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "healthy",
      vitals: {
        heartRate: { value: 70, unit: "bpm", status: "normal" },
        temperature: { value: 36.9, unit: "°C", status: "normal" },
        hydration: { value: 90, unit: "%", status: "normal" },
        stress: { value: 20, unit: "%", status: "normal" },
      },
    },
    {
      id: 5,
      name: "David L.",
      role: "Charlie-1",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "healthy",
      vitals: {
        heartRate: { value: 75, unit: "bpm", status: "normal" },
        temperature: { value: 37.0, unit: "°C", status: "normal" },
        hydration: { value: 88, unit: "%", status: "normal" },
        stress: { value: 30, unit: "%", status: "normal" },
      },
    },
    {
      id: 6,
      name: "Alex T.",
      role: "Charlie-3",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "warning",
      vitals: {
        heartRate: { value: 82, unit: "bpm", status: "normal" },
        temperature: { value: 37.3, unit: "°C", status: "normal" },
        hydration: { value: 80, unit: "%", status: "normal" },
        stress: { value: 55, unit: "%", status: "warning" },
      },
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal":
        return "emerald"
      case "warning":
        return "amber"
      case "critical":
        return "red"
      default:
        return "emerald"
    }
  }

  return (
    <div className="space-y-4">
      {teamMembers.map((member) => (
        <div
          key={member.id}
          className={`p-4 rounded-md border ${
            member.status === "healthy"
              ? "border-emerald-500/20"
              : member.status === "warning"
                ? "border-amber-500/20"
                : "border-red-500/20"
          }`}
        >
          <div className="flex items-center gap-4 mb-4">
            <Avatar className="h-10 w-10 border-2 border-zinc-800">
              <AvatarImage src={member.avatar} alt={member.name} />
              <AvatarFallback>
                {member.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">{member.name}</h4>
                <Badge
                  variant="outline"
                  className={`${
                    member.status === "healthy"
                      ? "border-emerald-500/20 text-emerald-500"
                      : member.status === "warning"
                        ? "border-amber-500/20 text-amber-500"
                        : "border-red-500/20 text-red-500"
                  }`}
                >
                  {member.status}
                </Badge>
              </div>
              <p className="text-sm text-zinc-400">{member.role}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5">
                  <Heart className={`h-4 w-4 text-${getStatusColor(member.vitals.heartRate.status)}-500`} />
                  Heart Rate
                </span>
                <span className="font-medium">
                  {member.vitals.heartRate.value} {member.vitals.heartRate.unit}
                </span>
              </div>
              <Progress
                value={member.vitals.heartRate.value}
                max={120}
                min={60}
                className="h-1.5 bg-zinc-800"
                indicatorClassName={`bg-${getStatusColor(member.vitals.heartRate.status)}-500`}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5">
                  <Thermometer className={`h-4 w-4 text-${getStatusColor(member.vitals.temperature.status)}-500`} />
                  Temperature
                </span>
                <span className="font-medium">
                  {member.vitals.temperature.value} {member.vitals.temperature.unit}
                </span>
              </div>
              <Progress
                value={member.vitals.temperature.value}
                max={39}
                min={36}
                className="h-1.5 bg-zinc-800"
                indicatorClassName={`bg-${getStatusColor(member.vitals.temperature.status)}-500`}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5">
                  <Droplet className={`h-4 w-4 text-${getStatusColor(member.vitals.hydration.status)}-500`} />
                  Hydration
                </span>
                <span className="font-medium">
                  {member.vitals.hydration.value} {member.vitals.hydration.unit}
                </span>
              </div>
              <Progress
                value={member.vitals.hydration.value}
                max={100}
                className="h-1.5 bg-zinc-800"
                indicatorClassName={`bg-${getStatusColor(member.vitals.hydration.status)}-500`}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5">
                  <Brain className={`h-4 w-4 text-${getStatusColor(member.vitals.stress.status)}-500`} />
                  Stress
                </span>
                <span className="font-medium">
                  {member.vitals.stress.value} {member.vitals.stress.unit}
                </span>
              </div>
              <Progress
                value={member.vitals.stress.value}
                max={100}
                className="h-1.5 bg-zinc-800"
                indicatorClassName={`bg-${getStatusColor(member.vitals.stress.status)}-500`}
              />
            </div>
          </div>

          {showDetails && (
            <div className="mt-4 pt-4 border-t border-zinc-800 flex justify-end gap-2">
              <Button variant="outline" size="sm" className="border-zinc-800">
                View History
              </Button>
              <Button variant="outline" size="sm" className="border-zinc-800">
                Contact
              </Button>
              <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
                Check Status
              </Button>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
