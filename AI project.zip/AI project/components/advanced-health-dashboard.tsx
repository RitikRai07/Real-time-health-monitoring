"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Heart,
  Thermometer,
  Droplet,
  Brain,
  Activity,
  Zap,
  TreesIcon as Lungs,
  Pill,
  BarChart2,
  Dumbbell,
  Footprints,
  Bone,
  Smile,
  Moon,
  Utensils,
  Flame,
  AlertTriangle,
  Info,
  Play,
  Pause,
  RefreshCw,
  CheckCircle2,
  MapPin,
  Building2,
} from "lucide-react"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
  ChartLegendItemLabel,
  ChartLegendItemValue,
  ChartLegendItemColor,
  ChartGrid,
  ChartLine,
  ChartXAxis,
  ChartYAxis,
  ChartArea,
} from "@/components/ui/chart"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"

export function AdvancedHealthDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const { toast } = useToast()

  const handleRefresh = () => {
    toast({
      title: "Data Refreshed",
      description: "Your health metrics have been updated with the latest data.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Comprehensive Health Monitoring</h2>
        <div className="flex gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="border-border">
                <Play className="h-4 w-4 mr-2" />
                How to Use
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>How to Use HealthGuardian</DialogTitle>
                <DialogDescription>
                  Watch this quick tutorial to learn how to get the most out of your health monitoring dashboard.
                </DialogDescription>
              </DialogHeader>
              <div className="relative aspect-video rounded-md overflow-hidden border border-border">
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  {!isVideoPlaying ? (
                    <Button
                      className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90"
                      onClick={() => setIsVideoPlaying(true)}
                    >
                      <Play className="h-6 w-6" />
                    </Button>
                  ) : (
                    <Button
                      className="h-16 w-16 rounded-full bg-primary/50 hover:bg-primary/70"
                      onClick={() => setIsVideoPlaying(false)}
                    >
                      <Pause className="h-6 w-6" />
                    </Button>
                  )}
                </div>
                {isVideoPlaying && (
                  <video
                    className="w-full h-full"
                    controls
                    autoPlay
                    onPause={() => setIsVideoPlaying(false)}
                    onPlay={() => setIsVideoPlaying(true)}
                  >
                    <source src="/videos/tutorial.mp4" type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                )}
                {!isVideoPlaying && (
                  <img
                    src="/images/tutorial-thumbnail.jpg"
                    alt="Tutorial Video Thumbnail"
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsVideoPlaying(false)}>
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Button variant="outline" size="sm" className="border-border" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Data
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-card border border-border p-1 flex flex-wrap">
          <TabsTrigger
            value="overview"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Overview
          </TabsTrigger>
          <TabsTrigger
            value="vitals"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Extended Vitals
          </TabsTrigger>
          <TabsTrigger
            value="fitness"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Fitness Tracking
          </TabsTrigger>
          <TabsTrigger
            value="mental"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Mental Health
          </TabsTrigger>
          <TabsTrigger
            value="ai"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            AI Insights
          </TabsTrigger>
          <TabsTrigger
            value="hospitals"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Nearby Hospitals
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Health Score
                </CardTitle>
                <CardDescription>Overall health assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-6">
                  <div className="relative w-40 h-40">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        className="text-muted stroke-current"
                        strokeWidth="10"
                        cx="50"
                        cy="50"
                        r="40"
                        fill="transparent"
                      ></circle>
                      <circle
                        className="text-primary stroke-current"
                        strokeWidth="10"
                        strokeLinecap="round"
                        cx="50"
                        cy="50"
                        r="40"
                        fill="transparent"
                        strokeDasharray="251.2"
                        strokeDashoffset="50.24"
                      ></circle>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                      <span className="text-4xl font-bold">82</span>
                      <span className="text-sm text-muted-foreground">Excellent</span>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-4 w-full">
                    <div className="flex flex-col items-center">
                      <span className="text-sm text-muted-foreground">Last Week</span>
                      <span className="text-lg font-medium">78</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="text-sm text-muted-foreground">Change</span>
                      <span className="text-lg font-medium text-emerald-500">+4</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  Vital Signs
                </CardTitle>
                <CardDescription>Current health status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Heart className="h-4 w-4 text-red-500" /> Heart Rate
                      </span>
                      <span className="text-sm font-medium">72 bpm</span>
                    </div>
                    <Progress value={72} max={200} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Lungs className="h-4 w-4 text-blue-500" /> Blood Oxygen
                      </span>
                      <span className="text-sm font-medium">98%</span>
                    </div>
                    <Progress value={98} max={100} className="h-2 bg-muted" indicatorClassName="bg-blue-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Thermometer className="h-4 w-4 text-amber-500" /> Temperature
                      </span>
                      <span className="text-sm font-medium">36.8°C</span>
                    </div>
                    <Progress
                      value={36.8}
                      min={35}
                      max={40}
                      className="h-2 bg-muted"
                      indicatorClassName="bg-amber-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Droplet className="h-4 w-4 text-cyan-500" /> Hydration
                      </span>
                      <span className="text-sm font-medium">85%</span>
                    </div>
                    <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-cyan-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Brain className="h-5 w-5 text-primary" />
                  Mental Wellness
                </CardTitle>
                <CardDescription>Stress and sleep metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Brain className="h-4 w-4 text-purple-500" /> Stress Level
                      </span>
                      <span className="text-sm font-medium">32%</span>
                    </div>
                    <Progress value={32} max={100} className="h-2 bg-muted" indicatorClassName="bg-purple-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Moon className="h-4 w-4 text-indigo-500" /> Sleep Quality
                      </span>
                      <span className="text-sm font-medium">Good</span>
                    </div>
                    <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-indigo-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Zap className="h-4 w-4 text-yellow-500" /> Energy Level
                      </span>
                      <span className="text-sm font-medium">High</span>
                    </div>
                    <Progress value={80} max={100} className="h-2 bg-muted" indicatorClassName="bg-yellow-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground flex items-center gap-2">
                        <Smile className="h-4 w-4 text-green-500" /> Mood
                      </span>
                      <span className="text-sm font-medium">Positive</span>
                    </div>
                    <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Health Trends
              </CardTitle>
              <CardDescription>Your health metrics over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer>
                  <ChartLegend>
                    <ChartLegendItem>
                      <ChartLegendItemColor color="#ef4444" />
                      <ChartLegendItemLabel>Heart Rate</ChartLegendItemLabel>
                      <ChartLegendItemValue>72 bpm</ChartLegendItemValue>
                    </ChartLegendItem>
                    <ChartLegendItem>
                      <ChartLegendItemColor color="#3b82f6" />
                      <ChartLegendItemLabel>Blood Oxygen</ChartLegendItemLabel>
                      <ChartLegendItemValue>98%</ChartLegendItemValue>
                    </ChartLegendItem>
                    <ChartLegendItem>
                      <ChartLegendItemColor color="#a855f7" />
                      <ChartLegendItemLabel>Stress Level</ChartLegendItemLabel>
                      <ChartLegendItemValue>32%</ChartLegendItemValue>
                    </ChartLegendItem>
                    <ChartLegendItem>
                      <ChartLegendItemColor color="#10b981" />
                      <ChartLegendItemLabel>Hydration</ChartLegendItemLabel>
                      <ChartLegendItemValue>85%</ChartLegendItemValue>
                    </ChartLegendItem>
                  </ChartLegend>

                  <Chart data={healthTrendData}>
                    <ChartGrid horizontal vertical />
                    <ChartXAxis dataKey="time" />
                    <ChartYAxis />

                    <ChartLine
                      dataKey="heartRate"
                      stroke="#ef4444"
                      strokeWidth={2}
                      activeDot={{ r: 6, fill: "#ef4444" }}
                      dot={false}
                      type="monotone"
                      yAxisId={0}
                    />
                    <ChartArea dataKey="heartRate" fill="#ef4444" fillOpacity={0.1} stroke="transparent" yAxisId={0} />

                    <ChartLine
                      dataKey="bloodOxygen"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      activeDot={{ r: 6, fill: "#3b82f6" }}
                      dot={false}
                      type="monotone"
                      yAxisId={0}
                    />
                    <ChartArea
                      dataKey="bloodOxygen"
                      fill="#3b82f6"
                      fillOpacity={0.1}
                      stroke="transparent"
                      yAxisId={0}
                    />

                    <ChartLine
                      dataKey="stressLevel"
                      stroke="#a855f7"
                      strokeWidth={2}
                      activeDot={{ r: 6, fill: "#a855f7" }}
                      dot={false}
                      type="monotone"
                      yAxisId={0}
                    />
                    <ChartArea
                      dataKey="stressLevel"
                      fill="#a855f7"
                      fillOpacity={0.1}
                      stroke="transparent"
                      yAxisId={0}
                    />

                    <ChartLine
                      dataKey="hydration"
                      stroke="#10b981"
                      strokeWidth={2}
                      activeDot={{ r: 6, fill: "#10b981" }}
                      dot={false}
                      type="monotone"
                      yAxisId={0}
                    />
                    <ChartArea dataKey="hydration" fill="#10b981" fillOpacity={0.1} stroke="transparent" yAxisId={0} />

                    <ChartTooltip
                      content={
                        <ChartTooltipContent
                          className="bg-card border border-border"
                          labelClassName="text-muted-foreground"
                        />
                      }
                    />
                  </Chart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  Activity Summary
                </CardTitle>
                <CardDescription>Your physical activity today</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <Footprints className="h-6 w-6 text-primary mb-2" />
                      <span className="text-2xl font-bold">8,742</span>
                      <span className="text-xs text-muted-foreground">Steps</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <Flame className="h-6 w-6 text-orange-500 mb-2" />
                      <span className="text-2xl font-bold">1,842</span>
                      <span className="text-xs text-muted-foreground">Calories</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <Zap className="h-6 w-6 text-yellow-500 mb-2" />
                      <span className="text-2xl font-bold">42</span>
                      <span className="text-xs text-muted-foreground">Active Min</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Daily Goal Progress</span>
                      <span className="text-sm font-medium">87%</span>
                    </div>
                    <Progress value={87} max={100} className="h-2 bg-muted" indicatorClassName="bg-primary" />
                  </div>

                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Weekly Average</span>
                    <span>9,124 steps</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Utensils className="h-5 w-5 text-primary" />
                  Nutrition & Hydration
                </CardTitle>
                <CardDescription>Today's intake summary</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Calories</span>
                        <span className="text-sm font-medium">1,842 / 2,200</span>
                      </div>
                      <Progress value={84} max={100} className="h-2 bg-muted" indicatorClassName="bg-orange-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Protein</span>
                        <span className="text-sm font-medium">82g / 120g</span>
                      </div>
                      <Progress value={68} max={100} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Carbs</span>
                        <span className="text-sm font-medium">210g / 250g</span>
                      </div>
                      <Progress value={84} max={100} className="h-2 bg-muted" indicatorClassName="bg-yellow-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Fat</span>
                        <span className="text-sm font-medium">65g / 70g</span>
                      </div>
                      <Progress value={93} max={100} className="h-2 bg-muted" indicatorClassName="bg-blue-500" />
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="relative w-20 h-20">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-cyan-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="62.8"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <Droplet className="h-6 w-6 text-cyan-500" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Hydration</h4>
                      <p className="text-sm text-muted-foreground">1.8L / 2.5L consumed</p>
                      <Progress value={72} max={100} className="h-2 bg-muted mt-2" indicatorClassName="bg-cyan-500" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="vitals" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Cardiovascular Health
                </CardTitle>
                <CardDescription>Detailed heart metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Resting Heart Rate</span>
                      <span className="text-2xl font-bold">68</span>
                      <span className="text-xs text-muted-foreground">bpm</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Blood Pressure</span>
                      <span className="text-2xl font-bold">118/78</span>
                      <span className="text-xs text-muted-foreground">mmHg</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Heart Rate Variability</span>
                      <span className="text-sm font-medium">42ms</span>
                    </div>
                    <Progress value={60} max={100} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">ECG Status</span>
                      <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">Normal</Badge>
                    </div>
                    <div className="h-16 bg-background rounded-md p-2">
                      <svg viewBox="0 0 400 100" className="w-full h-full">
                        <path
                          d="M0,50 Q10,50 20,50 T40,50 T60,20 T80,80 T100,50 T120,50 T140,50 T160,20 T180,80 T200,50 T220,50 T240,50 T260,20 T280,80 T300,50 T320,50 T340,50 T360,20 T380,80 T400,50"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          className="text-red-500"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lungs className="h-5 w-5 text-blue-500" />
                  Respiratory Health
                </CardTitle>
                <CardDescription>Oxygen and breathing metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Blood Oxygen</span>
                      <span className="text-2xl font-bold">98%</span>
                      <span className="text-xs text-emerald-500">Excellent</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Respiratory Rate</span>
                      <span className="text-2xl font-bold">16</span>
                      <span className="text-xs text-muted-foreground">breaths/min</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Oxygen Saturation Trend</span>
                      <span className="text-sm font-medium">Stable</span>
                    </div>
                    <div className="h-16 bg-background rounded-md p-2">
                      <svg viewBox="0 0 400 100" className="w-full h-full">
                        <path
                          d="M0,20 C20,20 40,20 60,20 S100,20 120,20 S160,20 180,20 S220,30 240,20 S280,10 300,20 S340,20 360,20 S400,20 400,20"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          className="text-blue-500"
                        />
                      </svg>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Lung Capacity</span>
                      <span className="text-sm font-medium">4.2L</span>
                    </div>
                    <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-blue-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Pill className="h-5 w-5 text-purple-500" />
                  Metabolic Health
                </CardTitle>
                <CardDescription>Blood glucose and cholesterol</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Blood Glucose</span>
                      <span className="text-2xl font-bold">92</span>
                      <span className="text-xs text-muted-foreground">mg/dL</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Total Cholesterol</span>
                      <span className="text-2xl font-bold">175</span>
                      <span className="text-xs text-muted-foreground">mg/dL</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">HDL Cholesterol</span>
                        <span className="text-sm font-medium">62 mg/dL</span>
                      </div>
                      <Progress value={82} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">LDL Cholesterol</span>
                        <span className="text-sm font-medium">98 mg/dL</span>
                      </div>
                      <Progress value={65} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Triglycerides</span>
                        <span className="text-sm font-medium">75 mg/dL</span>
                      </div>
                      <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-purple-500" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Droplet className="h-5 w-5 text-cyan-500" />
                  Hydration Analysis
                </CardTitle>
                <CardDescription>Detailed hydration metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-cyan-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="62.8"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-2xl font-bold">75%</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Current Hydration Level</h4>
                      <p className="text-sm text-muted-foreground">1.8L / 2.5L daily goal</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-amber-500/20 text-amber-500 border-amber-500/20">
                          Slightly Dehydrated
                        </Badge>
                        <Button variant="outline" size="sm" className="h-7 text-xs border-border">
                          <Info className="h-3 w-3 mr-1" /> Details
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Hydration Trend (7 days)</span>
                    </div>
                    <div className="h-24 bg-background rounded-md p-2">
                      <svg viewBox="0 0 400 100" className="w-full h-full">
                        <path
                          d="M0,80 C20,70 40,60 60,65 S100,80 120,75 S160,60 180,55 S220,40 240,45 S280,60 300,65 S340,70 360,75 S400,70 400,65"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          className="text-cyan-500"
                        />
                        <path
                          d="M0,80 L400,80"
                          stroke="currentColor"
                          strokeWidth="1"
                          strokeDasharray="4 4"
                          className="text-muted-foreground"
                        />
                        <text x="410" y="83" className="text-xs fill-current text-muted-foreground">
                          Target
                        </text>
                      </svg>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-2 bg-background rounded-md">
                      <span className="text-xs text-muted-foreground">Electrolyte Balance</span>
                      <div className="font-medium mt-1">Normal</div>
                    </div>
                    <div className="p-2 bg-background rounded-md">
                      <span className="text-xs text-muted-foreground">Sweat Rate</span>
                      <div className="font-medium mt-1">Moderate</div>
                    </div>
                    <div className="p-2 bg-background rounded-md">
                      <span className="text-xs text-muted-foreground">Fluid Retention</span>
                      <div className="font-medium mt-1">Good</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="fitness" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  Muscle Performance
                </CardTitle>
                <CardDescription>Muscle activation and fatigue tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="relative h-64 bg-background rounded-md p-4">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <img src="/images/muscle-map.png" alt="Muscle Activation Map" className="h-full object-contain" />
                    </div>
                    <div className="absolute top-2 right-2">
                      <div className="flex flex-col gap-1 text-xs">
                        <div className="flex items-center gap-1">
                          <div className="w-3 h-3 rounded-full bg-red-500"></div>
                          <span>High Activation</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                          <span>Medium Activation</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                          <span>Low Activation</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Muscle Group Analysis</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Quadriceps</span>
                        <span className="text-sm font-medium">High Activation</span>
                      </div>
                      <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-red-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Hamstrings</span>
                        <span className="text-sm font-medium">Medium Activation</span>
                      </div>
                      <Progress value={60} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Core</span>
                        <span className="text-sm font-medium">Medium Activation</span>
                      </div>
                      <Progress value={55} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Upper Body</span>
                        <span className="text-sm font-medium">Low Activation</span>
                      </div>
                      <Progress value={30} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Footprints className="h-5 w-5 text-primary" />
                  Running Performance
                </CardTitle>
                <CardDescription>Advanced running metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="flex flex-col items-center justify-center p-3 bg-background rounded-lg">
                      <span className="text-xs text-muted-foreground mb-1">Cadence</span>
                      <span className="text-xl font-bold">172</span>
                      <span className="text-xs text-muted-foreground">steps/min</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-3 bg-background rounded-lg">
                      <span className="text-xs text-muted-foreground mb-1">Stride Length</span>
                      <span className="text-xl font-bold">1.2</span>
                      <span className="text-xs text-muted-foreground">meters</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-3 bg-background rounded-lg">
                      <span className="text-xs text-muted-foreground mb-1">Ground Contact</span>
                      <span className="text-xl font-bold">240</span>
                      <span className="text-xs text-muted-foreground">ms</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Running Form Analysis</h4>
                    <div className="h-32 bg-background rounded-md p-2">
                      <div className="flex h-full items-end justify-around">
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[60%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Mon</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[80%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Tue</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[40%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Wed</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[90%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Thu</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[75%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Fri</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[30%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Sat</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="h-16 w-6 bg-primary/20 rounded-t-md relative">
                            <div className="absolute bottom-0 w-full h-[65%] bg-primary rounded-t-md"></div>
                          </div>
                          <span className="text-xs mt-1">Sun</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Injury Risk Assessment</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Impact Force</span>
                        <Badge className="bg-amber-500/20 text-amber-500 border-amber-500/20">Moderate Risk</Badge>
                      </div>
                      <Progress value={65} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                      <p className="text-xs text-muted-foreground">
                        Consider softer running surfaces to reduce impact.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Bone className="h-5 w-5 text-primary" />
                  Joint Health
                </CardTitle>
                <CardDescription>Joint movement and posture analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Joint Mobility</span>
                      <span className="text-2xl font-bold">Good</span>
                      <span className="text-xs text-emerald-500">Above Average</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-background rounded-lg">
                      <span className="text-sm text-muted-foreground mb-1">Posture Score</span>
                      <span className="text-2xl font-bold">82%</span>
                      <span className="text-xs text-emerald-500">Good</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Joint Health Analysis</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Knee Joints</span>
                        <span className="text-sm font-medium">Healthy</span>
                      </div>
                      <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Ankle Mobility</span>
                        <span className="text-sm font-medium">Good</span>
                      </div>
                      <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Hip Alignment</span>
                        <span className="text-sm font-medium">Needs Attention</span>
                      </div>
                      <Progress value={60} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Spine Alignment</span>
                        <span className="text-sm font-medium">Good</span>
                      </div>
                      <Progress value={80} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                  </div>

                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-md">
                    <div className="flex gap-2">
                      <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-amber-500">Recommendation</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          Consider hip mobility exercises to improve alignment and reduce potential strain during
                          high-intensity activities.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Recovery Status
                </CardTitle>
                <CardDescription>Muscle recovery and readiness</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-emerald-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="50.24"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-2xl font-bold">80%</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Recovery Status</h4>
                      <p className="text-sm text-muted-foreground">Your body is well-recovered</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">
                          Ready for Training
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Recovery Metrics</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Muscle Fatigue</span>
                        <span className="text-sm font-medium">Low</span>
                      </div>
                      <Progress value={20} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Resting Heart Rate</span>
                        <span className="text-sm font-medium">Normal</span>
                      </div>
                      <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">HRV Status</span>
                        <span className="text-sm font-medium">Good</span>
                      </div>
                      <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-md">
                    <div className="flex gap-2">
                      <Info className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-emerald-500">Today's Recommendation</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          Your body is well-recovered. Today is optimal for a high-intensity or strength training
                          session.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="mental" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-500" />
                  Stress Management
                </CardTitle>
                <CardDescription>Stress levels and cortisol tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-purple-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="175.84"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-2xl font-bold">30%</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Current Stress Level</h4>
                      <p className="text-sm text-muted-foreground">Your stress is well-managed</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">Low Stress</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Stress Trend (7 days)</h4>
                    <div className="h-32 bg-background rounded-md p-2">
                      <svg viewBox="0 0 400 100" className="w-full h-full">
                        <path
                          d="M0,60 C20,65 40,70 60,65 S100,40 120,45 S160,60 180,55 S220,40 240,35 S280,30 300,25 S340,30 360,30 S400,30 400,30"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          className="text-purple-500"
                        />
                      </svg>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Stress Factors</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Cortisol Level</span>
                        <span className="text-sm font-medium">Normal</span>
                      </div>
                      <Progress value={40} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Heart Rate Variability</span>
                        <span className="text-sm font-medium">Good</span>
                      </div>
                      <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Breathing Rate</span>
                        <span className="text-sm font-medium">Calm</span>
                      </div>
                      <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Moon className="h-5 w-5 text-indigo-500" />
                  Sleep Analysis
                </CardTitle>
                <CardDescription>Detailed sleep quality metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-indigo-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="62.8"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-2xl font-bold">75%</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Sleep Quality</h4>
                      <p className="text-sm text-muted-foreground">7h 15m total sleep time</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">Good Quality</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Sleep Stages</h4>
                    <div className="h-12 bg-background rounded-md overflow-hidden flex">
                      <div className="h-full bg-indigo-900 w-[15%]" title="Deep Sleep: 1h 5m"></div>
                      <div className="h-full bg-indigo-700 w-[25%]" title="REM Sleep: 1h 50m"></div>
                      <div className="h-full bg-indigo-500 w-[45%]" title="Light Sleep: 3h 15m"></div>
                      <div className="h-full bg-indigo-300 w-[15%]" title="Awake: 1h 5m"></div>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Deep: 1h 5m</span>
                      <span>REM: 1h 50m</span>
                      <span>Light: 3h 15m</span>
                      <span>Awake: 1h 5m</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Sleep Metrics</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Sleep Efficiency</span>
                        <span className="text-sm font-medium">85%</span>
                      </div>
                      <Progress value={85} max={100} className="h-2 bg-muted" indicatorClassName="bg-indigo-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Breathing Disturbances</span>
                        <span className="text-sm font-medium">Minimal</span>
                      </div>
                      <Progress value={15} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Resting Heart Rate</span>
                        <span className="text-sm font-medium">58 bpm</span>
                      </div>
                      <Progress value={80} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                  </div>

                  <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-md">
                    <div className="flex gap-2">
                      <Info className="h-5 w-5 text-indigo-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-indigo-500">Sleep Insight</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          Your deep sleep has improved by 15% compared to last week. Continue maintaining a consistent
                          sleep schedule.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Smile className="h-5 w-5 text-yellow-500" />
                  Mood & Emotional Wellbeing
                </CardTitle>
                <CardDescription>Track your emotional patterns and mental wellness</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Current Mood</h4>
                      <div className="flex flex-col items-center p-4 bg-background rounded-lg">
                        <Smile className="h-12 w-12 text-yellow-500 mb-2" />
                        <span className="text-xl font-bold">Positive</span>
                        <span className="text-xs text-muted-foreground mt-1">Tracked 2 hours ago</span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Mood Trend (7 days)</h4>
                      <div className="h-32 bg-background rounded-md p-2">
                        <svg viewBox="0 0 400 100" className="w-full h-full">
                          <path
                            d="M0,50 C20,60 40,70 60,65 S100,40 120,45 S160,60 180,55 S220,30 240,25 S280,30 300,35 S340,30 360,25 S400,20 400,20"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            className="text-yellow-500"
                          />
                        </svg>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Emotional Balance</h4>
                      <div className="flex flex-col gap-2">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Positive Emotions</span>
                            <span className="text-sm font-medium">75%</span>
                          </div>
                          <Progress value={75} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Negative Emotions</span>
                            <span className="text-sm font-medium">25%</span>
                          </div>
                          <Progress value={25} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Mindfulness & Meditation</h4>
                      <div className="p-4 bg-background rounded-lg">
                        <div className="flex justify-between items-center mb-4">
                          <span className="font-medium">Weekly Practice</span>
                          <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">On Track</Badge>
                        </div>
                        <div className="grid grid-cols-7 gap-1">
                          {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
                            <div key={i} className="flex flex-col items-center">
                              <span className="text-xs text-muted-foreground mb-1">{day}</span>
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                  i < 5 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {i < 5 ? <CheckCircle2 className="h-4 w-4" /> : ""}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 text-sm text-muted-foreground">
                          <span>5 of 7 days completed • 45 minutes total</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Recommended Activities</h4>
                      <div className="space-y-2">
                        <div className="p-3 bg-background rounded-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-primary/10 rounded-full">
                              <Brain className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h5 className="font-medium text-sm">Guided Meditation</h5>
                              <p className="text-xs text-muted-foreground">10 min • Stress Reduction</p>
                            </div>
                          </div>
                          <Button size="sm" className="h-8">
                            Start
                          </Button>
                        </div>
                        <div className="p-3 bg-background rounded-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-primary/10 rounded-full">
                              <Droplet className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h5 className="font-medium text-sm">Deep Breathing</h5>
                              <p className="text-xs text-muted-foreground">5 min • Anxiety Relief</p>
                            </div>
                          </div>
                          <Button size="sm" className="h-8">
                            Start
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart2 className="h-5 w-5 text-primary" />
                  Health Risk Assessment
                </CardTitle>
                <CardDescription>AI-powered health risk prediction</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="relative w-20 h-20">
                      <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                        ></circle>
                        <circle
                          className="text-emerald-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          strokeDasharray="251.2"
                          strokeDashoffset="200.96"
                        ></circle>
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                        <span className="text-lg font-bold">Low</span>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">Overall Health Risk</h4>
                      <p className="text-xs text-muted-foreground">Based on your health data and lifestyle</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">Risk Factors</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Cardiovascular</span>
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">Low Risk</Badge>
                      </div>
                      <Progress value={20} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Metabolic</span>
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">Low Risk</Badge>
                      </div>
                      <Progress value={15} max={100} className="h-2 bg-muted" indicatorClassName="bg-emerald-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Stress-Related</span>
                        <Badge className="bg-amber-500/20 text-amber-500 border-amber-500/20">Moderate Risk</Badge>
                      </div>
                      <Progress value={40} max={100} className="h-2 bg-muted" indicatorClassName="bg-amber-500" />
                    </div>
                  </div>

                  <div className="p-3 bg-primary/10 border border-primary/20 rounded-md">
                    <div className="flex gap-2">
                      <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-medium text-primary">AI Insight</h4>
                        <p className="text-xs text-muted-foreground mt-1">
                          Your overall health risk is low. Consider stress management techniques to address the moderate
                          stress-related risk factor.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Activity className="h-5 w-5 text-primary" />
                  Personalized Recommendations
                </CardTitle>
                <CardDescription>AI-tailored health suggestions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Heart className="h-4 w-4 text-primary" />
                      </div>
                      <h5 className="font-medium text-sm">Cardiovascular Health</h5>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Your resting heart rate is optimal. Continue with your current cardio routine of 30 minutes, 3-4
                      times per week.
                    </p>
                  </div>

                  <div className="p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Brain className="h-4 w-4 text-primary" />
                      </div>
                      <h5 className="font-medium text-sm">Stress Management</h5>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Your stress levels have increased by 15% this week. Try adding 10 minutes of meditation to your
                      morning routine.
                    </p>
                  </div>

                  <div className="p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Droplet className="h-4 w-4 text-primary" />
                      </div>
                      <h5 className="font-medium text-sm">Hydration</h5>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Your hydration levels are below target. Aim to increase water intake by 500ml, especially before
                      and after workouts.
                    </p>
                  </div>

                  <div className="p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Moon className="h-4 w-4 text-primary" />
                      </div>
                      <h5 className="font-medium text-sm">Sleep Optimization</h5>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Your deep sleep has improved. Continue maintaining a consistent sleep schedule and avoid screen
                      time 1 hour before bed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-primary" />
                  Adaptive Workout Plan
                </CardTitle>
                <CardDescription>AI-optimized fitness routine</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-sm font-medium">Today's Recommendation</h4>
                    <Badge className="bg-primary/20 text-primary border-primary/20">Strength Training</Badge>
                  </div>

                  <div className="p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <Dumbbell className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h5 className="font-medium text-sm">Upper Body Focus</h5>
                        <p className="text-xs text-muted-foreground">45 minutes • Moderate Intensity</p>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-muted-foreground">
                      <p>
                        Based on your recovery status and previous workouts, today is optimal for upper body training.
                      </p>
                    </div>
                    <Button size="sm" className="w-full mt-3">
                      View Workout
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Weekly Plan</h4>
                    <div className="grid grid-cols-7 gap-1">
                      {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => (
                        <div key={i} className="flex flex-col items-center">
                          <span className="text-xs text-muted-foreground mb-1">{day}</span>
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${
                              i === 2
                                ? "bg-primary text-primary-foreground"
                                : i < 2
                                  ? "bg-emerald-500/20 text-emerald-500"
                                  : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {i === 0
                              ? "S"
                              : i === 1
                                ? "C"
                                : i === 2
                                  ? "U"
                                  : i === 3
                                    ? "R"
                                    : i === 4
                                      ? "L"
                                      : i === 5
                                        ? "H"
                                        : "R"}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2 text-xs">
                      <span className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="text-muted-foreground">Completed</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-primary"></div>
                        <span className="text-muted-foreground">Today</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <div className="w-2 h-2 rounded-full bg-muted"></div>
                        <span className="text-muted-foreground">Upcoming</span>
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart2 className="h-5 w-5 text-primary" />
                Health Trends & Predictions
              </CardTitle>
              <CardDescription>AI analysis of your long-term health patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Health Score Prediction</h4>
                  <div className="h-64 bg-background rounded-md p-4">
                    <svg viewBox="0 0 400 200" className="w-full h-full">
                      <path
                        d="M0,150 C20,140 40,130 60,125 S100,120 120,115 S160,105 180,100 S220,90 240,85 S280,75 300,70 S340,65 360,60 S400,55 400,50"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="text-primary"
                      />
                      <path
                        d="M0,150 L400,150"
                        stroke="currentColor"
                        strokeWidth="1"
                        strokeDasharray="4 4"
                        className="text-muted-foreground"
                      />
                      <text x="5" y="20" className="text-xs fill-current">
                        Health Score
                      </text>
                      <text x="350" y="170" className="text-xs fill-current">
                        Time
                      </text>
                      <text x="5" y="155" className="text-xs fill-current">
                        Now
                      </text>
                      <text x="380" y="155" className="text-xs fill-current">
                        3mo
                      </text>
                    </svg>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Based on your current habits and health data, our AI predicts your health score will improve by 15%
                    over the next 3 months if you maintain your current routine.
                  </p>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-medium">Key Insights & Recommendations</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        <h5 className="font-medium text-sm">Sleep Pattern Improvement</h5>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Your consistent sleep schedule has improved your recovery rate by 22%. Continue maintaining
                        regular sleep hours.
                      </p>
                    </div>

                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                        <h5 className="font-medium text-sm">Stress Management</h5>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Periodic stress spikes detected during workdays. Consider implementing 5-minute breathing
                        exercises during work breaks.
                      </p>
                    </div>

                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        <h5 className="font-medium text-sm">Cardiovascular Health</h5>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Your resting heart rate has decreased by 5 bpm over the past month, indicating improved
                        cardiovascular fitness.
                      </p>
                    </div>

                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                        <h5 className="font-medium text-sm">Hydration Pattern</h5>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Hydration levels consistently drop in the afternoon. Set reminders to drink water every 2 hours
                        between 2-6 PM.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hospitals" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card className="bg-card border-border h-full">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    Nearby Medical Facilities
                  </CardTitle>
                  <CardDescription>Hospitals and clinics in your area</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative h-[400px] bg-background rounded-md overflow-hidden">
                    <img
                      src="/images/hospital-map.jpg"
                      alt="Map showing nearby hospitals"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm p-3 rounded-md border border-border">
                      <h4 className="text-sm font-medium mb-2">Your Location</h4>
                      <p className="text-xs text-muted-foreground">123 Main Street, Cityville</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card className="bg-card border-border h-full">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-primary" />
                    Recommended Facilities
                  </CardTitle>
                  <CardDescription>Based on your health profile</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="relative">
                          <Building2 className="h-10 w-10 text-primary" />
                          <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center">
                            1
                          </Badge>
                        </div>
                        <div>
                          <h5 className="font-medium">City General Hospital</h5>
                          <p className="text-xs text-muted-foreground">1.2 miles away • Open 24/7</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2">
                        <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">
                          Emergency Care
                        </Badge>
                        <Badge className="bg-blue-500/20 text-blue-500 border-blue-500/20">Cardiology</Badge>
                      </div>
                      <div className="flex justify-between mt-3">
                        <Button size="sm" variant="outline" className="h-8 text-xs border-border">
                          View Details
                        </Button>
                        <Button size="sm" className="h-8 text-xs">
                          Get Directions
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="relative">
                          <Building2 className="h-10 w-10 text-primary" />
                          <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center">
                            2
                          </Badge>
                        </div>
                        <div>
                          <h5 className="font-medium">Wellness Medical Center</h5>
                          <p className="text-xs text-muted-foreground">2.5 miles away • Open until 8PM</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2">
                        <Badge className="bg-purple-500/20 text-purple-500 border-purple-500/20">Sports Medicine</Badge>
                        <Badge className="bg-amber-500/20 text-amber-500 border-amber-500/20">Orthopedics</Badge>
                      </div>
                      <div className="flex justify-between mt-3">
                        <Button size="sm" variant="outline" className="h-8 text-xs border-border">
                          View Details
                        </Button>
                        <Button size="sm" className="h-8 text-xs">
                          Get Directions
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 bg-background rounded-lg">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="relative">
                          <Building2 className="h-10 w-10 text-primary" />
                          <Badge className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center">
                            3
                          </Badge>
                        </div>
                        <div>
                          <h5 className="font-medium">Riverside Clinic</h5>
                          <p className="text-xs text-muted-foreground">3.8 miles away • Open until 6PM</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-2">
                        <Badge className="bg-cyan-500/20 text-cyan-500 border-cyan-500/20">Family Medicine</Badge>
                        <Badge className="bg-indigo-500/20 text-indigo-500 border-indigo-500/20">Mental Health</Badge>
                      </div>
                      <div className="flex justify-between mt-3">
                        <Button size="sm" variant="outline" className="h-8 text-xs border-border">
                          View Details
                        </Button>
                        <Button size="sm" className="h-8 text-xs">
                          Get Directions
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                Emergency Services
              </CardTitle>
              <CardDescription>Critical care facilities near you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-background rounded-lg border border-border">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-red-500/10 rounded-full">
                      <AlertTriangle className="h-6 w-6 text-red-500" />
                    </div>
                    <div>
                      <h5 className="font-medium">City General ER</h5>
                      <p className="text-xs text-muted-foreground">1.2 miles • 8 min drive</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Wait Time</span>
                      <span>15-20 min</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Trauma Level</span>
                      <span>Level I</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Open</span>
                      <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">24/7</Badge>
                    </div>
                  </div>
                  <Button className="w-full">Get Directions</Button>
                </div>

                <div className="p-4 bg-background rounded-lg border border-border">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-red-500/10 rounded-full">
                      <AlertTriangle className="h-6 w-6 text-red-500" />
                    </div>
                    <div>
                      <h5 className="font-medium">Memorial Hospital ER</h5>
                      <p className="text-xs text-muted-foreground">3.5 miles • 12 min drive</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Wait Time</span>
                      <span>5-10 min</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Trauma Level</span>
                      <span>Level II</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Open</span>
                      <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/20">24/7</Badge>
                    </div>
                  </div>
                  <Button className="w-full">Get Directions</Button>
                </div>

                <div className="p-4 bg-background rounded-lg border border-border">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-red-500/10 rounded-full">
                      <AlertTriangle className="h-6 w-6 text-red-500" />
                    </div>
                    <div>
                      <h5 className="font-medium">Urgent Care Center</h5>
                      <p className="text-xs text-muted-foreground">0.8 miles • 5 min drive</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Wait Time</span>
                      <span>30-45 min</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Trauma Level</span>
                      <span>Non-Trauma</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Open</span>
                      <Badge className="bg-amber-500/20 text-amber-500 border-amber-500/20">Until 10PM</Badge>
                    </div>
                  </div>
                  <Button className="w-full">Get Directions</Button>
                </div>
              </div>

              <div className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                <div className="flex gap-3">
                  <AlertTriangle className="h-6 w-6 text-red-500 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-red-500">Emergency Information</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      In case of a medical emergency, dial 911 immediately. For non-life-threatening situations, use the
                      facilities listed above or contact your primary care physician.
                    </p>
                    <div className="flex gap-4 mt-3">
                      <Button variant="destructive">Call 911</Button>
                      <Button variant="outline" className="border-red-500/20 text-red-500 hover:bg-red-500/10">
                        Emergency Contacts
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

// Sample data for health trends
const healthTrendData = [
  { time: "08:00", heartRate: 72, bloodOxygen: 98, stressLevel: 30, hydration: 90 },
  { time: "10:00", heartRate: 75, bloodOxygen: 97, stressLevel: 35, hydration: 85 },
  { time: "12:00", heartRate: 80, bloodOxygen: 98, stressLevel: 40, hydration: 80 },
  { time: "14:00", heartRate: 78, bloodOxygen: 97, stressLevel: 45, hydration: 75 },
  { time: "16:00", heartRate: 76, bloodOxygen: 98, stressLevel: 35, hydration: 70 },
  { time: "18:00", heartRate: 74, bloodOxygen: 98, stressLevel: 30, hydration: 75 },
  { time: "20:00", heartRate: 70, bloodOxygen: 99, stressLevel: 25, hydration: 80 },
  { time: "22:00", heartRate: 68, bloodOxygen: 98, stressLevel: 20, hydration: 85 },
]
