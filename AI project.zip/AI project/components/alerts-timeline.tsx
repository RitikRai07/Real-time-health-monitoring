"use client"

import { AlertTriangle, Thermometer, Droplet, MapPin, Heart, Brain, Wind, Radio } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface AlertsTimelineProps {
  extended?: boolean
}

export function AlertsTimeline({ extended = false }: AlertsTimelineProps) {
  // Mock data for alerts
  const alerts = [
    {
      id: 1,
      type: "temperature",
      icon: Thermometer,
      color: "amber",
      title: "High Body Temperature",
      description: "Temperature reached 38.2°C",
      member: "Alpha-2",
      time: "10:15 AM",
      timeAgo: "10 mins ago",
      severity: "warning",
    },
    {
      id: 2,
      type: "hydration",
      icon: Droplet,
      color: "amber",
      title: "Low Hydration",
      description: "Hydration level at 68%",
      member: "Bravo-1",
      time: "09:52 AM",
      timeAgo: "23 mins ago",
      severity: "warning",
    },
    {
      id: 3,
      type: "geofence",
      icon: MapPin,
      color: "amber",
      title: "Geo-fence Breach",
      description: "Member moved outside designated area",
      member: "Charlie-3",
      time: "09:33 AM",
      timeAgo: "42 mins ago",
      severity: "warning",
    },
    {
      id: 4,
      type: "heartRate",
      icon: Heart,
      color: "amber",
      title: "Elevated Heart Rate",
      description: "Heart rate at 110 BPM",
      member: "Alpha-1",
      time: "09:15 AM",
      timeAgo: "1 hour ago",
      severity: "warning",
    },
    {
      id: 5,
      type: "stress",
      icon: Brain,
      color: "amber",
      title: "High Stress Level",
      description: "Stress indicators above threshold",
      member: "Bravo-2",
      time: "08:45 AM",
      timeAgo: "1.5 hours ago",
      severity: "warning",
    },
    {
      id: 6,
      type: "environment",
      icon: Wind,
      color: "red",
      title: "Hazardous Air Quality",
      description: "Toxic gas detected in sector B",
      member: "All",
      time: "08:30 AM",
      timeAgo: "1.75 hours ago",
      severity: "critical",
    },
    {
      id: 7,
      type: "communication",
      icon: Radio,
      color: "amber",
      title: "Communication Disruption",
      description: "Signal interference detected",
      member: "Charlie Team",
      time: "08:15 AM",
      timeAgo: "2 hours ago",
      severity: "warning",
    },
    {
      id: 8,
      type: "heartRate",
      icon: Heart,
      color: "red",
      title: "Critical Heart Rate",
      description: "Heart rate at 135 BPM",
      member: "Delta-1",
      time: "07:45 AM",
      timeAgo: "2.5 hours ago",
      severity: "critical",
    },
  ]

  // Limit the number of alerts if not extended
  const displayAlerts = extended ? alerts : alerts.slice(0, 5)

  return (
    <div className="space-y-4">
      {displayAlerts.map((alert) => (
        <div
          key={alert.id}
          className={`flex gap-4 p-3 rounded-md border ${
            alert.severity === "critical" ? "bg-red-500/10 border-red-500/20" : "bg-amber-500/10 border-amber-500/20"
          }`}
        >
          <div className={`mt-0.5 p-2 rounded-full bg-${alert.color}-500/20`}>
            <alert.icon className={`h-5 w-5 text-${alert.color}-500`} />
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-medium flex items-center gap-2">
                {alert.title}
                {alert.severity === "critical" && <AlertTriangle className="h-4 w-4 text-red-500" />}
              </h4>
              <Badge
                variant="outline"
                className={`${
                  alert.severity === "critical"
                    ? "border-red-500/20 text-red-500"
                    : "border-amber-500/20 text-amber-500"
                }`}
              >
                {alert.severity}
              </Badge>
            </div>

            <p className="text-sm text-zinc-400 mb-2">{alert.description}</p>

            <div className="flex justify-between text-xs">
              <span className="text-zinc-500">
                Team member: <span className="text-zinc-300">{alert.member}</span>
              </span>
              <span className="text-zinc-500">{alert.timeAgo}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
