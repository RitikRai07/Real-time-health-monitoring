"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Battery, Wifi, Thermometer, AlertTriangle, CheckCircle2, RefreshCw, Download } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function EquipmentStatus() {
  const [activeTab, setActiveTab] = useState("overview")
  const { toast } = useToast()

  const handleRefresh = () => {
    toast({
      title: "Equipment Status Updated",
      description: "All equipment statuses have been refreshed.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Equipment Status</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="border-zinc-800" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-zinc-800"
            onClick={() => {
              toast({
                title: "Report Downloaded",
                description: "Equipment status report has been downloaded.",
              })
            }}
          >
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Overview
          </TabsTrigger>
          <TabsTrigger value="biometric" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Biometric Sensors
          </TabsTrigger>
          <TabsTrigger
            value="communication"
            className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black"
          >
            Communication
          </TabsTrigger>
          <TabsTrigger value="power" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-black">
            Power Systems
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                  Operational Status
                </CardTitle>
                <CardDescription>Overall equipment health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Operational</span>
                    <span className="text-sm font-medium">42</span>
                  </div>
                  <Progress value={84} className="h-2 bg-zinc-800" indicatorClassName="bg-emerald-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Needs Maintenance</span>
                    <span className="text-sm font-medium">6</span>
                  </div>
                  <Progress value={12} className="h-2 bg-zinc-800" indicatorClassName="bg-amber-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Out of Service</span>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <Progress value={4} className="h-2 bg-zinc-800" indicatorClassName="bg-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Battery className="h-5 w-5 text-emerald-500" />
                  Battery Status
                </CardTitle>
                <CardDescription>Power levels across all devices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Full (75-100%)</span>
                    <span className="text-sm font-medium">32</span>
                  </div>
                  <Progress value={64} className="h-2 bg-zinc-800" indicatorClassName="bg-emerald-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Medium (25-75%)</span>
                    <span className="text-sm font-medium">15</span>
                  </div>
                  <Progress value={30} className="h-2 bg-zinc-800" indicatorClassName="bg-amber-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Low (0-25%)</span>
                    <span className="text-sm font-medium">3</span>
                  </div>
                  <Progress value={6} className="h-2 bg-zinc-800" indicatorClassName="bg-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wifi className="h-5 w-5 text-emerald-500" />
                  Connectivity
                </CardTitle>
                <CardDescription>Network status of all devices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Strong Signal</span>
                    <span className="text-sm font-medium">38</span>
                  </div>
                  <Progress value={76} className="h-2 bg-zinc-800" indicatorClassName="bg-emerald-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">Weak Signal</span>
                    <span className="text-sm font-medium">10</span>
                  </div>
                  <Progress value={20} className="h-2 bg-zinc-800" indicatorClassName="bg-amber-500" />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-zinc-400">No Signal</span>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <Progress value={4} className="h-2 bg-zinc-800" indicatorClassName="bg-red-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>Equipment Issues</CardTitle>
              <CardDescription>Recent alerts and maintenance needs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {equipmentIssues.map((issue, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-4 p-3 rounded-md bg-zinc-800/50 border border-zinc-800"
                  >
                    <div
                      className={`p-2 rounded-full ${
                        issue.severity === "critical"
                          ? "bg-red-500/20 text-red-500"
                          : issue.severity === "warning"
                            ? "bg-amber-500/20 text-amber-500"
                            : "bg-blue-500/20 text-blue-500"
                      }`}
                    >
                      <AlertTriangle className="h-4 w-4" />
                    </div>

                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h4 className="font-medium text-sm">{issue.title}</h4>
                        <Badge
                          variant="outline"
                          className={`${
                            issue.severity === "critical"
                              ? "border-red-500/20 text-red-500"
                              : issue.severity === "warning"
                                ? "border-amber-500/20 text-amber-500"
                                : "border-blue-500/20 text-blue-500"
                          }`}
                        >
                          {issue.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-zinc-400 mt-1">{issue.description}</p>

                      <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-xs">
                              {issue.device.split("-")[0][0]}
                              {issue.device.split("-")[1]}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs">{issue.device}</span>
                        </div>

                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-xs border-zinc-700"
                          onClick={() => {
                            toast({
                              title: "Maintenance Scheduled",
                              description: `Maintenance scheduled for ${issue.device}`,
                            })
                          }}
                        >
                          Schedule Maintenance
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="biometric" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {biometricSensors.map((sensor, index) => (
              <Card key={index} className="bg-zinc-900 border-zinc-800">
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Thermometer className="h-5 w-5 text-emerald-500" />
                      {sensor.name}
                    </CardTitle>
                    <Badge
                      className={`${
                        sensor.status === "operational"
                          ? "bg-emerald-500/20 text-emerald-500"
                          : sensor.status === "maintenance"
                            ? "bg-amber-500/20 text-amber-500"
                            : "bg-red-500/20 text-red-500"
                      }`}
                    >
                      {sensor.status}
                    </Badge>
                  </div>
                  <CardDescription>
                    ID: {sensor.id} • Last Calibrated: {sensor.lastCalibrated}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-zinc-400">Accuracy</span>
                      <span className="text-sm font-medium">{sensor.accuracy}%</span>
                    </div>
                    <Progress
                      value={sensor.accuracy}
                      className="h-2 bg-zinc-800"
                      indicatorClassName={`${
                        sensor.accuracy > 90 ? "bg-emerald-500" : sensor.accuracy > 70 ? "bg-amber-500" : "bg-red-500"
                      }`}
                    />

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-zinc-400">Battery</span>
                      <span className="text-sm font-medium">{sensor.battery}%</span>
                    </div>
                    <Progress
                      value={sensor.battery}
                      className="h-2 bg-zinc-800"
                      indicatorClassName={`${
                        sensor.battery > 50 ? "bg-emerald-500" : sensor.battery > 20 ? "bg-amber-500" : "bg-red-500"
                      }`}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="communication" className="space-y-6 mt-6">
          <p>Communication systems content</p>
        </TabsContent>

        <TabsContent value="power" className="space-y-6 mt-6">
          <p>Power systems content</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}

const equipmentIssues = [
  {
    title: "High Temperature Alert",
    description: "Device is overheating and may shut down",
    severity: "critical",
    device: "Sensor-001",
  },
  {
    title: "Network Connectivity Issue",
    description: "Experiencing intermittent connection drops",
    severity: "warning",
    device: "Router-002",
  },
  {
    title: "Low Battery Warning",
    description: "Battery level is critically low",
    severity: "warning",
    device: "Sensor-003",
  },
]

const biometricSensors = [
  {
    id: "BS-001",
    name: "Temperature Sensor",
    status: "operational",
    accuracy: 98,
    battery: 85,
    lastCalibrated: "2023-01-15",
  },
  {
    id: "BS-002",
    name: "Heart Rate Monitor",
    status: "maintenance",
    accuracy: 75,
    battery: 30,
    lastCalibrated: "2022-12-01",
  },
  {
    id: "BS-003",
    name: "Blood Pressure Sensor",
    status: "operational",
    accuracy: 92,
    battery: 60,
    lastCalibrated: "2023-02-20",
  },
]

type LogEntry = {
  id: string
  type: "alert" | "maintenance" | "system"
  title: string
  description: string
  timestamp: string
  member: string
  status: "open" | "closed" | "pending"
}

function createLogEntry(
  id: string,
  type: "alert" | "maintenance" | "system",
  title: string,
  description: string,
  timestamp: string,
  member: string,
  status: "open" | "closed" | "pending",
): LogEntry {
  return {
    id,
    type,
    title,
    description,
    timestamp,
    member,
    status,
  }
}
