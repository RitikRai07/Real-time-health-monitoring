"use client"

import React from "react"

import { useState } from "react"
import {
  AlertTriangle,
  Thermometer,
  Droplet,
  MapPin,
  Heart,
  Brain,
  Wind,
  Radio,
  Clock,
  CheckCircle2,
  X,
  Filter,
  ArrowUpDown,
  ChevronDown,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface EnhancedAlertsTimelineProps {
  extended?: boolean
}

export function EnhancedAlertsTimeline({ extended = false }: EnhancedAlertsTimelineProps) {
  const [activeTab, setActiveTab] = useState("all")
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest")
  const [selectedAlert, setSelectedAlert] = useState<AlertType | null>(null)
  const [filterSeverity, setFilterSeverity] = useState<string[]>(["critical", "warning", "info"])
  const [filterType, setFilterType] = useState<string[]>([
    "temperature",
    "hydration",
    "geofence",
    "heartRate",
    "stress",
    "environment",
    "communication",
  ])
  const { toast } = useToast()

  // Filter and sort alerts
  const filteredAlerts = alerts
    .filter((alert) => filterSeverity.includes(alert.severity))
    .filter((alert) => filterType.includes(alert.type))
    .sort((a, b) => {
      const timeA = new Date(a.timestamp).getTime()
      const timeB = new Date(b.timestamp).getTime()
      return sortOrder === "newest" ? timeB - timeA : timeA - timeB
    })

  const displayAlerts = extended ? filteredAlerts : filteredAlerts.slice(0, 5)

  const handleAlertAction = (alert: AlertType) => {
    toast({
      title: "Alert Action",
      description: `Taking action on: ${alert.title}`,
    })
  }

  const handleAlertDismiss = (alertId: number) => {
    toast({
      title: "Alert Dismissed",
      description: "The alert has been marked as resolved.",
    })
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "temperature":
        return Thermometer
      case "hydration":
        return Droplet
      case "geofence":
        return MapPin
      case "heartRate":
        return Heart
      case "stress":
        return Brain
      case "environment":
        return Wind
      case "communication":
        return Radio
      default:
        return AlertTriangle
    }
  }

  return (
    <div className="space-y-4">
      {extended && (
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList className="bg-card border border-border p-1">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                All
              </TabsTrigger>
              <TabsTrigger value="critical" className="data-[state=active]:bg-red-500 data-[state=active]:text-white">
                Critical
              </TabsTrigger>
              <TabsTrigger value="warning" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
                Warning
              </TabsTrigger>
              <TabsTrigger
                value="resolved"
                className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
              >
                Resolved
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="border-border">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-card border-border">
                <DropdownMenuLabel>Filter by Severity</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuCheckboxItem
                  checked={filterSeverity.includes("critical")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterSeverity((prev) => [...prev, "critical"])
                    } else {
                      setFilterSeverity((prev) => prev.filter((s) => s !== "critical"))
                    }
                  }}
                >
                  Critical
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filterSeverity.includes("warning")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterSeverity((prev) => [...prev, "warning"])
                    } else {
                      setFilterSeverity((prev) => prev.filter((s) => s !== "warning"))
                    }
                  }}
                >
                  Warning
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filterSeverity.includes("info")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterSeverity((prev) => [...prev, "info"])
                    } else {
                      setFilterSeverity((prev) => prev.filter((s) => s !== "info"))
                    }
                  }}
                >
                  Info
                </DropdownMenuCheckboxItem>

                <DropdownMenuSeparator />
                <DropdownMenuLabel>Filter by Type</DropdownMenuLabel>
                <DropdownMenuSeparator />

                <DropdownMenuCheckboxItem
                  checked={filterType.includes("temperature")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterType((prev) => [...prev, "temperature"])
                    } else {
                      setFilterType((prev) => prev.filter((t) => t !== "temperature"))
                    }
                  }}
                >
                  Temperature
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filterType.includes("hydration")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterType((prev) => [...prev, "hydration"])
                    } else {
                      setFilterType((prev) => prev.filter((t) => t !== "hydration"))
                    }
                  }}
                >
                  Hydration
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filterType.includes("heartRate")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterType((prev) => [...prev, "heartRate"])
                    } else {
                      setFilterType((prev) => prev.filter((t) => t !== "heartRate"))
                    }
                  }}
                >
                  Heart Rate
                </DropdownMenuCheckboxItem>
                <DropdownMenuCheckboxItem
                  checked={filterType.includes("geofence")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFilterType((prev) => [...prev, "geofence"])
                    } else {
                      setFilterType((prev) => prev.filter((t) => t !== "geofence"))
                    }
                  }}
                >
                  Geo-fence
                </DropdownMenuCheckboxItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              size="sm"
              className="border-border"
              onClick={() => setSortOrder(sortOrder === "newest" ? "oldest" : "newest")}
            >
              <ArrowUpDown className="h-4 w-4 mr-2" />
              {sortOrder === "newest" ? "Newest First" : "Oldest First"}
            </Button>
          </div>
        </div>
      )}

      {displayAlerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <CheckCircle2 className="h-12 w-12 mb-4 opacity-20" />
          <p className="text-lg font-medium">No alerts to display</p>
          <p className="text-sm">All systems are operating normally</p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`flex gap-4 p-4 rounded-md border transition-all hover:shadow-md ${
                alert.severity === "critical"
                  ? "bg-red-500/10 border-red-500/30"
                  : alert.severity === "warning"
                    ? "bg-amber-500/10 border-amber-500/30"
                    : "bg-blue-500/10 border-blue-500/30"
              }`}
            >
              <div
                className={`mt-0.5 p-2.5 rounded-full ${
                  alert.severity === "critical"
                    ? "bg-red-500/20"
                    : alert.severity === "warning"
                      ? "bg-amber-500/20"
                      : "bg-blue-500/20"
                }`}
              >
                {React.createElement(getAlertIcon(alert.type), {
                  className: `h-5 w-5 ${
                    alert.severity === "critical"
                      ? "text-red-500"
                      : alert.severity === "warning"
                        ? "text-amber-500"
                        : "text-blue-500"
                  }`,
                })}
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h4 className="font-medium flex items-center gap-2">
                    {alert.title}
                    {alert.severity === "critical" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                  </h4>
                  <Badge
                    variant="outline"
                    className={`${
                      alert.severity === "critical"
                        ? "border-red-500/30 text-red-500"
                        : alert.severity === "warning"
                          ? "border-amber-500/30 text-amber-500"
                          : "border-blue-500/30 text-blue-500"
                    }`}
                  >
                    {alert.severity}
                  </Badge>
                </div>

                <p className="text-sm text-zinc-400 mb-2">{alert.description}</p>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-500">
                    Team member: <span className="text-zinc-300">{alert.member}</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-500 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {alert.timeAgo}
                    </span>

                    {extended && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full hover:bg-background">
                            <ChevronDown className="h-3 w-3" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-card border-border">
                          <DialogHeader>
                            <DialogTitle>{alert.title}</DialogTitle>
                            <DialogDescription>{alert.description}</DialogDescription>
                          </DialogHeader>

                          <div className="space-y-4 py-4">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-10 w-10">
                                <AvatarFallback>
                                  {alert.member.split("-")[0][0]}
                                  {alert.member.split("-")[1]}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{alert.member}</p>
                                <p className="text-xs text-muted-foreground">{alert.timestamp}</p>
                              </div>
                            </div>

                            {alert.type === "temperature" && (
                              <div className="space-y-2">
                                <h4 className="text-sm font-medium">Temperature Trend</h4>
                                <div className="h-24 bg-background rounded-md p-2">
                                  <svg viewBox="0 0 400 100" className="w-full h-full">
                                    <path
                                      d="M0,50 C20,45 40,40 60,35 S100,25 120,20 S160,15 180,20 S220,30 240,40 S280,60 300,70 S340,80 360,85 S400,90 400,90"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                      className="text-amber-500"
                                    />
                                  </svg>
                                </div>
                                <div className="space-y-1">
                                  <div className="flex justify-between text-xs">
                                    <span className="text-muted-foreground">Current</span>
                                    <span className="font-medium">38.2°C</span>
                                  </div>
                                  <Progress value={82} max={100} className="h-1.5" indicatorClassName="bg-amber-500" />
                                </div>
                              </div>
                            )}

                            {alert.type === "hydration" && (
                              <div className="space-y-2">
                                <h4 className="text-sm font-medium">Hydration Level</h4>
                                <div className="h-24 bg-background rounded-md p-2">
                                  <svg viewBox="0 0 400 100" className="w-full h-full">
                                    <path
                                      d="M0,20 C20,25 40,30 60,35 S100,45 120,50 S160,60 180,65 S220,70 240,75 S280,80 300,85 S340,90 360,90 S400,90 400,90"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                      className="text-blue-500"
                                    />
                                  </svg>
                                </div>
                                <div className="space-y-1">
                                  <div className="flex justify-between text-xs">
                                    <span className="text-muted-foreground">Current</span>
                                    <span className="font-medium">68%</span>
                                  </div>
                                  <Progress value={68} max={100} className="h-1.5" indicatorClassName="bg-blue-500" />
                                </div>
                              </div>
                            )}
                          </div>

                          <DialogFooter>
                            <Button variant="outline" onClick={() => handleAlertDismiss(alert.id)}>
                              Dismiss
                            </Button>
                            <Button onClick={() => handleAlertAction(alert)}>Take Action</Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>
                </div>

                {extended && (
                  <div className="flex justify-end mt-3 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 text-xs border-border"
                      onClick={() => handleAlertDismiss(alert.id)}
                    >
                      <X className="h-3 w-3 mr-1" />
                      Dismiss
                    </Button>
                    <Button
                      size="sm"
                      className={`h-8 text-xs ${
                        alert.severity === "critical" ? "bg-red-500 hover:bg-red-600" : "bg-primary hover:bg-primary/90"
                      }`}
                      onClick={() => handleAlertAction(alert)}
                    >
                      Take Action
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {extended && displayAlerts.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button variant="outline" className="border-border">
            Load More Alerts
          </Button>
        </div>
      )}
    </div>
  )
}

interface AlertType {
  id: number
  type: string
  title: string
  description: string
  timestamp: string
  timeAgo: string
  member: string
  severity: "critical" | "warning" | "info"
  objectives?: {
    total: number
    completed: number
  }
  result?: "success" | "partial" | "failed"
}

// Mock data for alerts
const alerts: AlertType[] = [
  {
    id: 1,
    type: "temperature",
    title: "High Body Temperature",
    description: "Temperature reached 38.2°C",
    timestamp: "2023-07-15T10:15:00",
    timeAgo: "10 mins ago",
    member: "Alpha-2",
    severity: "warning",
  },
  {
    id: 2,
    type: "hydration",
    title: "Low Hydration",
    description: "Hydration level at 68%",
    timestamp: "2023-07-15T09:52:00",
    timeAgo: "23 mins ago",
    member: "Bravo-1",
    severity: "warning",
  },
  {
    id: 3,
    type: "geofence",
    title: "Geo-fence Breach",
    description: "Member moved outside designated area",
    timestamp: "2023-07-15T09:33:00",
    timeAgo: "42 mins ago",
    member: "Charlie-3",
    severity: "warning",
  },
  {
    id: 4,
    type: "heartRate",
    title: "Elevated Heart Rate",
    description: "Heart rate at 110 BPM",
    timestamp: "2023-07-15T09:15:00",
    timeAgo: "1 hour ago",
    member: "Alpha-1",
    severity: "warning",
  },
  {
    id: 5,
    type: "stress",
    title: "High Stress Level",
    description: "Stress indicators above threshold",
    timestamp: "2023-07-15T08:45:00",
    timeAgo: "1.5 hours ago",
    member: "Bravo-2",
    severity: "warning",
  },
  {
    id: 6,
    type: "environment",
    title: "Hazardous Air Quality",
    description: "Toxic gas detected in sector B",
    timestamp: "2023-07-15T08:30:00",
    timeAgo: "1.75 hours ago",
    member: "All",
    severity: "critical",
  },
  {
    id: 7,
    type: "communication",
    title: "Communication Disruption",
    description: "Signal interference detected",
    timestamp: "2023-07-15T08:15:00",
    timeAgo: "2 hours ago",
    member: "Charlie Team",
    severity: "warning",
  },
  {
    id: 8,
    type: "heartRate",
    title: "Critical Heart Rate",
    description: "Heart rate at 135 BPM",
    timestamp: "2023-07-15T07:45:00",
    timeAgo: "2.5 hours ago",
    member: "Delta-1",
    severity: "critical",
  },
]
