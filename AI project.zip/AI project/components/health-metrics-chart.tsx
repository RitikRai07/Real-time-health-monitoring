"use client"

import { useState } from "react"
import {
  Chart,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendItem,
  ChartLegendItemLabel,
  ChartLegendItemValue,
  ChartLegendItemColor,
  ChartGrid,
  ChartLine,
  ChartXAxis,
  ChartYAxis,
  ChartArea,
} from "@/components/ui/chart"
import { Heart, Thermometer, Droplet, Brain } from "lucide-react"

export function HealthMetricsChart() {
  const [activeMetric, setActiveMetric] = useState<string | null>(null)

  // Mock data for the chart
  const data = [
    { time: "08:00", heartRate: 72, temperature: 36.8, hydration: 95, stress: 20 },
    { time: "09:00", heartRate: 75, temperature: 36.9, hydration: 92, stress: 25 },
    { time: "10:00", heartRate: 78, temperature: 37.0, hydration: 90, stress: 30 },
    { time: "11:00", heartRate: 82, temperature: 37.2, hydration: 87, stress: 35 },
    { time: "12:00", heartRate: 85, temperature: 37.5, hydration: 84, stress: 45 },
    { time: "13:00", heartRate: 88, temperature: 37.8, hydration: 80, stress: 55 },
    { time: "14:00", heartRate: 90, temperature: 38.0, hydration: 75, stress: 60 },
    { time: "15:00", heartRate: 87, temperature: 37.9, hydration: 72, stress: 50 },
    { time: "16:00", heartRate: 84, temperature: 37.7, hydration: 70, stress: 45 },
    { time: "17:00", heartRate: 80, temperature: 37.5, hydration: 68, stress: 40 },
  ]

  const metrics = [
    { id: "heartRate", name: "Heart Rate", color: "#ef4444", icon: Heart, unit: "bpm", domain: [60, 100] },
    { id: "temperature", name: "Temperature", color: "#f97316", icon: Thermometer, unit: "°C", domain: [36, 39] },
    { id: "hydration", name: "Hydration", color: "#3b82f6", icon: Droplet, unit: "%", domain: [60, 100] },
    { id: "stress", name: "Stress", color: "#a855f7", icon: Brain, unit: "%", domain: [0, 100] },
  ]

  const handleMetricHover = (metricId: string | null) => {
    setActiveMetric(metricId)
  }

  return (
    <div className="w-full h-full">
      <div className="flex flex-wrap gap-3 mb-4">
        {metrics.map((metric) => (
          <button
            key={metric.id}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeMetric === metric.id || activeMetric === null
                ? `bg-${metric.color.replace("#", "")}/10 text-${metric.color.replace("#", "")}`
                : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
            }`}
            style={{
              backgroundColor: activeMetric === metric.id || activeMetric === null ? `${metric.color}20` : undefined,
              color: activeMetric === metric.id || activeMetric === null ? metric.color : undefined,
            }}
            onMouseEnter={() => handleMetricHover(metric.id)}
            onMouseLeave={() => handleMetricHover(null)}
          >
            <metric.icon className="h-3.5 w-3.5" />
            {metric.name}
          </button>
        ))}
      </div>

      <ChartContainer className="h-[calc(100%-40px)]">
        <ChartLegend>
          {metrics.map((metric) => (
            <ChartLegendItem key={metric.id} className={activeMetric && activeMetric !== metric.id ? "opacity-30" : ""}>
              <ChartLegendItemColor color={metric.color} />
              <ChartLegendItemLabel>{metric.name}</ChartLegendItemLabel>
              <ChartLegendItemValue>
                {data[data.length - 1][metric.id as keyof (typeof data)[0]]}
                {metric.unit}
              </ChartLegendItemValue>
            </ChartLegendItem>
          ))}
        </ChartLegend>

        <Chart data={data}>
          <ChartGrid horizontal vertical />
          <ChartXAxis dataKey="time" />
          <ChartYAxis />

          {metrics.map((metric) => (
            <ChartLine
              key={metric.id}
              dataKey={metric.id}
              stroke={metric.color}
              strokeWidth={2}
              activeDot={{ r: 6, fill: metric.color }}
              dot={false}
              type="monotone"
              yAxisId={0}
              opacity={activeMetric === null || activeMetric === metric.id ? 1 : 0.2}
            />
          ))}

          {metrics.map((metric) => (
            <ChartArea
              key={`${metric.id}-area`}
              dataKey={metric.id}
              fill={metric.color}
              fillOpacity={0.1}
              stroke="transparent"
              yAxisId={0}
              opacity={activeMetric === null || activeMetric === metric.id ? 1 : 0.1}
            />
          ))}

          <ChartTooltip
            content={
              <ChartTooltipContent className="bg-zinc-800 border border-zinc-700" labelClassName="text-zinc-400" />
            }
          />
        </Chart>
      </ChartContainer>
    </div>
  )
}
