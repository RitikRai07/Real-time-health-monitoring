"use client"

import { useState, useEffect } from "react"
import { MapPin, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface TeamMapProps {
  fullscreen?: boolean
}

export function TeamMap({ fullscreen = false }: TeamMapProps) {
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setMapLoaded(true)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="relative w-full h-full bg-zinc-800 rounded-md overflow-hidden">
      {/* Map background */}
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] bg-cover bg-center opacity-70"></div>

      {/* Map overlay with grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(30,41,59,0.1)_1px,transparent_1px),linear-gradient(to_bottom,rgba(30,41,59,0.1)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

      {/* Geo-fence area */}
      <div className="absolute left-[10%] top-[15%] w-[70%] h-[60%] border-2 border-emerald-500/50 rounded-md"></div>

      {/* Team members */}
      {mapLoaded && (
        <>
          {/* Alpha-1 */}
          <div className="absolute left-[25%] top-[30%] flex flex-col items-center">
            <div className="relative">
              <MapPin className="h-8 w-8 text-emerald-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-500"></div>
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Alpha-1</Badge>
          </div>

          {/* Alpha-2 */}
          <div className="absolute left-[35%] top-[45%] flex flex-col items-center">
            <div className="relative">
              <MapPin className="h-8 w-8 text-amber-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-amber-500"></div>
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Alpha-2</Badge>
          </div>

          {/* Bravo-1 */}
          <div className="absolute left-[55%] top-[25%] flex flex-col items-center">
            <div className="relative">
              <MapPin className="h-8 w-8 text-amber-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-amber-500"></div>
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Bravo-1</Badge>
          </div>

          {/* Bravo-2 */}
          <div className="absolute left-[65%] top-[40%] flex flex-col items-center">
            <div className="relative">
              <MapPin className="h-8 w-8 text-emerald-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-500"></div>
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Bravo-2</Badge>
          </div>

          {/* Charlie-1 */}
          <div className="absolute left-[45%] top-[60%] flex flex-col items-center">
            <div className="relative">
              <MapPin className="h-8 w-8 text-emerald-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-emerald-500"></div>
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Charlie-1</Badge>
          </div>

          {/* Charlie-3 - Outside geo-fence */}
          <div className="absolute left-[85%] top-[50%] flex flex-col items-center">
            <div className="relative animate-pulse">
              <MapPin className="h-8 w-8 text-amber-500" />
              <div className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-amber-500"></div>
              <AlertTriangle className="absolute -top-4 -right-4 h-5 w-5 text-amber-500" />
            </div>
            <Badge className="mt-1 bg-zinc-800/80 text-xs">Charlie-3</Badge>
          </div>
        </>
      )}

      {/* Map controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <div className="bg-zinc-900/80 p-2 rounded-md">
          <div className="text-xs text-zinc-400 mb-1">Legend</div>
          <div className="flex items-center gap-2 text-xs">
            <div className="h-3 w-3 rounded-full bg-emerald-500"></div>
            <span>Healthy</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="h-3 w-3 rounded-full bg-amber-500"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="h-3 w-3 rounded-full bg-red-500"></div>
            <span>Critical</span>
          </div>
        </div>
      </div>

      {!mapLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900/50">
          <div className="text-lg">Loading map...</div>
        </div>
      )}
    </div>
  )
}
