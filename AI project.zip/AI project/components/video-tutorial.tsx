"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX, Maximize2, SkipBack, SkipForward, FileVideo } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"

interface VideoTutorialProps {
  src: string
  poster?: string
  title: string
  description?: string
  fallbackImageSrc?: string
}

export function VideoTutorial({ src, poster, title, description, fallbackImageSrc }: VideoTutorialProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [volume, setVolume] = useState(1)
  const [showControls, setShowControls] = useState(false)
  const [videoError, setVideoError] = useState(false)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const setVideoData = () => {
      setDuration(video.duration)
    }

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
    }

    const handleError = (e: Event) => {
      console.error("Video failed to load:", src, e)
      setVideoError(true)
    }

    // Check if the video source exists
    fetch(src)
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Video file not found: ${src}`)
        }
      })
      .catch((error) => {
        console.error(error)
        setVideoError(true)
      })

    video.addEventListener("loadedmetadata", setVideoData)
    video.addEventListener("timeupdate", handleTimeUpdate)
    video.addEventListener("error", handleError)

    return () => {
      video.removeEventListener("loadedmetadata", setVideoData)
      video.removeEventListener("timeupdate", handleTimeUpdate)
      video.removeEventListener("error", handleError)
    }
  }, [src])

  const togglePlay = () => {
    const video = videoRef.current
    if (!video || videoError) return

    if (isPlaying) {
      video.pause()
    } else {
      video.play().catch((err) => {
        console.error("Failed to play video:", err)
        setVideoError(true)
      })
    }
    setIsPlaying(!isPlaying)
  }

  const toggleMute = () => {
    const video = videoRef.current
    if (!video || videoError) return

    video.muted = !isMuted
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (value: number[]) => {
    const video = videoRef.current
    if (!video || videoError) return

    const newVolume = value[0]
    video.volume = newVolume
    setVolume(newVolume)
    setIsMuted(newVolume === 0)
  }

  const handleSeek = (value: number[]) => {
    const video = videoRef.current
    if (!video || videoError) return

    video.currentTime = value[0]
    setCurrentTime(value[0])
  }

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`
  }

  const skipForward = () => {
    const video = videoRef.current
    if (!video || videoError) return

    video.currentTime = Math.min(video.duration, video.currentTime + 10)
  }

  const skipBackward = () => {
    const video = videoRef.current
    if (!video || videoError) return

    video.currentTime = Math.max(0, video.currentTime - 10)
  }

  const enterFullscreen = () => {
    const video = videoRef.current
    if (!video || videoError) return

    if (video.requestFullscreen) {
      video.requestFullscreen()
    }
  }

  // Render fallback UI if video fails to load
  if (videoError) {
    return (
      <Card className="overflow-hidden">
        <div className="bg-muted aspect-video flex flex-col items-center justify-center p-6 text-center relative">
          {fallbackImageSrc ? (
            <img
              src={fallbackImageSrc || "/placeholder.svg"}
              alt={title}
              className="absolute inset-0 w-full h-full object-cover opacity-20"
            />
          ) : null}
          <div className="relative z-10">
            <FileVideo className="h-16 w-16 text-muted-foreground mb-4 mx-auto" />
            <h3 className="text-lg font-semibold">{title}</h3>
            <p className="text-sm text-muted-foreground mt-2 max-w-md">
              {description || "Video tutorial is currently unavailable. Please check back later."}
            </p>
            <div className="flex gap-3 mt-4 justify-center">
              <Button variant="outline" onClick={() => window.open(src, "_blank")}>
                Try Direct Link
              </Button>
              <Button
                variant="default"
                onClick={() => {
                  setVideoError(false)
                  const video = videoRef.current
                  if (video) {
                    video.load()
                  }
                }}
              >
                Retry Loading
              </Button>
            </div>
          </div>
        </div>
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="overflow-hidden">
      <div
        className="relative group"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        <video
          ref={videoRef}
          src={src}
          poster={poster}
          className="w-full aspect-video object-cover"
          onClick={togglePlay}
        />

        <div
          className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity duration-300 ${
            isPlaying && !showControls ? "opacity-0" : "opacity-100"
          }`}
        >
          <Button
            variant="ghost"
            size="icon"
            className="h-16 w-16 rounded-full bg-white/20 hover:bg-white/30 text-white"
            onClick={togglePlay}
          >
            {isPlaying ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
          </Button>
        </div>

        <div
          className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 transition-opacity duration-300 ${
            isPlaying && !showControls ? "opacity-0 group-hover:opacity-100" : "opacity-100"
          }`}
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-white text-xs">{formatTime(currentTime)}</span>
              <Slider
                value={[currentTime]}
                max={duration || 100}
                step={0.1}
                onValueChange={handleSeek}
                className="flex-1"
              />
              <span className="text-white text-xs">{formatTime(duration)}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={togglePlay}>
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={skipBackward}>
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={skipForward}>
                  <SkipForward className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={toggleMute}>
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
                <div className="w-20 hidden sm:block">
                  <Slider value={[isMuted ? 0 : volume]} max={1} step={0.01} onValueChange={handleVolumeChange} />
                </div>
              </div>

              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={enterFullscreen}>
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <CardContent className="p-4">
        <h3 className="text-lg font-semibold">{title}</h3>
        {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
      </CardContent>
    </Card>
  )
}
