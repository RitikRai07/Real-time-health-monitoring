"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  Heart,
  MapPin,
  Radio,
  Thermometer,
  Droplet,
  CheckCircle2,
  Bell,
  Filter,
  X,
  Search,
  Settings,
  ArrowUpRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"

interface NotificationCenterProps {
  onClose: () => void
}

export function NotificationCenter({ onClose }: NotificationCenterProps) {
  const [activeTab, setActiveTab] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [notifications, setNotifications] = useState(allNotifications)
  const [showSettings, setShowSettings] = useState(false)
  const [notificationSettings, setNotificationSettings] = useState({
    healthAlerts: true,
    locationAlerts: true,
    systemAlerts: true,
    criticalOnly: false,
    soundEnabled: true,
    autoRefresh: true,
  })
  const { toast } = useToast()

  // Filter notifications based on search query and active tab
  useEffect(() => {
    let filtered = [...allNotifications]

    // Filter by tab
    if (activeTab !== "all") {
      filtered = filtered.filter((n) => n.category === activeTab)
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (n) =>
          n.title.toLowerCase().includes(query) ||
          n.description.toLowerCase().includes(query) ||
          (n.member && n.member.toLowerCase().includes(query)),
      )
    }

    // Filter by critical only setting
    if (notificationSettings.criticalOnly) {
      filtered = filtered.filter((n) => n.severity === "critical")
    }

    // Filter by notification type settings
    if (!notificationSettings.healthAlerts) {
      filtered = filtered.filter((n) => n.category !== "health")
    }
    if (!notificationSettings.locationAlerts) {
      filtered = filtered.filter((n) => n.category !== "location")
    }
    if (!notificationSettings.systemAlerts) {
      filtered = filtered.filter((n) => n.category !== "system")
    }

    setNotifications(filtered)
  }, [activeTab, searchQuery, notificationSettings])

  // Simulate real-time notifications
  useEffect(() => {
    if (!notificationSettings.autoRefresh) return

    const interval = setInterval(() => {
      // 20% chance to add a new notification
      if (Math.random() < 0.2) {
        const newNotification = generateRandomNotification(allNotifications.length + 1)

        // Add to all notifications
        allNotifications.unshift(newNotification)

        // Update filtered notifications
        setNotifications((prev) => {
          // Check if the new notification should be included based on filters
          let shouldInclude = true

          if (activeTab !== "all" && newNotification.category !== activeTab) {
            shouldInclude = false
          }

          if (notificationSettings.criticalOnly && newNotification.severity !== "critical") {
            shouldInclude = false
          }

          if (
            (newNotification.category === "health" && !notificationSettings.healthAlerts) ||
            (newNotification.category === "location" && !notificationSettings.locationAlerts) ||
            (newNotification.category === "system" && !notificationSettings.systemAlerts)
          ) {
            shouldInclude = false
          }

          if (shouldInclude) {
            return [newNotification, ...prev]
          }

          return prev
        })

        // Show toast for critical notifications
        if (newNotification.severity === "critical" && notificationSettings.soundEnabled) {
          toast({
            title: "Critical Alert",
            description: newNotification.title,
            variant: "destructive",
          })

          // Play sound for critical alerts
          const audio = new Audio("/alert.mp3")
          audio.play().catch((e) => console.error("Error playing sound:", e))
        }
      }
    }, 30000) // Check every 30 seconds

    return () => clearInterval(interval)
  }, [activeTab, notificationSettings, toast])

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
    allNotifications.forEach((n) => (n.read = true))

    toast({
      title: "Notifications Cleared",
      description: "All notifications have been marked as read",
    })
  }

  const clearAllNotifications = () => {
    setNotifications([])
    allNotifications.length = 0

    toast({
      title: "Notifications Cleared",
      description: "All notifications have been removed",
    })
  }

  return (
    <div className="max-h-[600px] flex flex-col bg-card border border-border rounded-lg shadow-xl">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          <h3 className="font-medium">Notifications</h3>
          <Badge className="ml-1">{notifications.filter((n) => !n.read).length}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowSettings(!showSettings)}>
            <Settings className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={markAllAsRead}>
            Mark all as read
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {showSettings ? (
        <div className="p-4 border-b border-border">
          <h4 className="font-medium mb-3">Notification Settings</h4>
          <div className="space-y-4">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <Label htmlFor="health-alerts" className="cursor-pointer">
                  Health Alerts
                </Label>
                <Switch
                  id="health-alerts"
                  checked={notificationSettings.healthAlerts}
                  onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, healthAlerts: checked }))}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="location-alerts" className="cursor-pointer">
                  Location Alerts
                </Label>
                <Switch
                  id="location-alerts"
                  checked={notificationSettings.locationAlerts}
                  onCheckedChange={(checked) =>
                    setNotificationSettings((prev) => ({ ...prev, locationAlerts: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="system-alerts" className="cursor-pointer">
                  System Alerts
                </Label>
                <Switch
                  id="system-alerts"
                  checked={notificationSettings.systemAlerts}
                  onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, systemAlerts: checked }))}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="critical-only" className="cursor-pointer">
                  Critical Alerts Only
                </Label>
                <Switch
                  id="critical-only"
                  checked={notificationSettings.criticalOnly}
                  onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, criticalOnly: checked }))}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="sound-enabled" className="cursor-pointer">
                  Sound Alerts
                </Label>
                <Switch
                  id="sound-enabled"
                  checked={notificationSettings.soundEnabled}
                  onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, soundEnabled: checked }))}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-refresh" className="cursor-pointer">
                  Auto Refresh
                </Label>
                <Switch
                  id="auto-refresh"
                  checked={notificationSettings.autoRefresh}
                  onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, autoRefresh: checked }))}
                />
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <Button variant="outline" size="sm" onClick={clearAllNotifications}>
                Clear All Notifications
              </Button>
              <Button variant="default" size="sm" onClick={() => setShowSettings(false)}>
                Save Settings
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search notifications..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div className="px-4 border-b border-border">
              <div className="flex items-center justify-between">
                <TabsList className="bg-transparent p-0 h-auto">
                  <TabsTrigger
                    value="all"
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-3 py-2"
                  >
                    All
                  </TabsTrigger>
                  <TabsTrigger
                    value="health"
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-3 py-2"
                  >
                    Health
                  </TabsTrigger>
                  <TabsTrigger
                    value="location"
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-3 py-2"
                  >
                    Location
                  </TabsTrigger>
                  <TabsTrigger
                    value="system"
                    className="data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-3 py-2"
                  >
                    System
                  </TabsTrigger>
                </TabsList>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Filter className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Filter By</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuCheckboxItem
                      checked={!notificationSettings.criticalOnly}
                      onCheckedChange={(checked) =>
                        setNotificationSettings((prev) => ({ ...prev, criticalOnly: !checked }))
                      }
                    >
                      Show All Severities
                    </DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem
                      checked={notificationSettings.criticalOnly}
                      onCheckedChange={(checked) =>
                        setNotificationSettings((prev) => ({ ...prev, criticalOnly: checked }))
                      }
                    >
                      Critical Only
                    </DropdownMenuCheckboxItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuCheckboxItem checked={true} onCheckedChange={() => {}}>
                      Show Unread First
                    </DropdownMenuCheckboxItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            <TabsContent value="all" className="flex-1 overflow-auto p-0 custom-scrollbar">
              {notifications.length > 0 ? (
                <div className="divide-y divide-border">
                  {notifications.map((notification, index) => (
                    <NotificationItem key={index} notification={notification} />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                  <Bell className="h-12 w-12 mb-4 opacity-20" />
                  <p>No notifications to display</p>
                  <p className="text-sm mt-1">Adjust your filters or check back later</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="health" className="flex-1 overflow-auto p-0 custom-scrollbar">
              {notifications.filter((n) => n.category === "health").length > 0 ? (
                <div className="divide-y divide-border">
                  {notifications
                    .filter((n) => n.category === "health")
                    .map((notification, index) => (
                      <NotificationItem key={index} notification={notification} />
                    ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                  <Heart className="h-12 w-12 mb-4 opacity-20" />
                  <p>No health notifications</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="location" className="flex-1 overflow-auto p-0 custom-scrollbar">
              {notifications.filter((n) => n.category === "location").length > 0 ? (
                <div className="divide-y divide-border">
                  {notifications
                    .filter((n) => n.category === "location")
                    .map((notification, index) => (
                      <NotificationItem key={index} notification={notification} />
                    ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                  <MapPin className="h-12 w-12 mb-4 opacity-20" />
                  <p>No location notifications</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="system" className="flex-1 overflow-auto p-0 custom-scrollbar">
              {notifications.filter((n) => n.category === "system").length > 0 ? (
                <div className="divide-y divide-border">
                  {notifications
                    .filter((n) => n.category === "system")
                    .map((notification, index) => (
                      <NotificationItem key={index} notification={notification} />
                    ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                  <Radio className="h-12 w-12 mb-4 opacity-20" />
                  <p>No system notifications</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}

interface Notification {
  id: number
  title: string
  description: string
  time: string
  category: "health" | "location" | "system"
  severity: "critical" | "warning" | "info"
  read: boolean
  member?: string
  memberInitials?: string
  actionable?: boolean
}

interface NotificationItemProps {
  notification: Notification
}

function NotificationItem({ notification }: NotificationItemProps) {
  const [isRead, setIsRead] = useState(notification.read)
  const { toast } = useToast()

  const getIcon = () => {
    switch (notification.category) {
      case "health":
        if (notification.title.includes("Temperature")) return Thermometer
        if (notification.title.includes("Hydration")) return Droplet
        return Heart
      case "location":
        return MapPin
      case "system":
        return Radio
      default:
        return AlertTriangle
    }
  }

  const Icon = getIcon()

  const getSeverityColor = () => {
    switch (notification.severity) {
      case "critical":
        return "bg-red-500/20 text-red-500"
      case "warning":
        return "bg-amber-500/20 text-amber-500"
      case "info":
        return "bg-blue-500/20 text-blue-500"
      default:
        return "bg-emerald-500/20 text-emerald-500"
    }
  }

  const handleMarkAsRead = () => {
    setIsRead(!isRead)
    notification.read = !isRead
  }

  const handleAction = () => {
    toast({
      title: "Action Taken",
      description: `Responding to: ${notification.title}`,
    })
  }

  return (
    <div className={`p-4 hover:bg-muted/20 transition-colors ${!isRead ? "bg-muted/10" : ""}`}>
      <div className="flex gap-3">
        <div className={`mt-0.5 p-2 rounded-full ${getSeverityColor()}`}>
          <Icon className="h-4 w-4" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h4 className="font-medium text-sm flex items-center gap-2">
                {notification.title}
                {!isRead && <span className="h-2 w-2 rounded-full bg-primary"></span>}
              </h4>
              <p className="text-xs text-muted-foreground mt-1">{notification.description}</p>
            </div>

            {notification.member && (
              <Avatar className="h-6 w-6 flex-shrink-0">
                <AvatarImage
                  src={`/placeholder.svg?height=24&width=24&text=${notification.memberInitials}`}
                  alt={notification.member}
                />
                <AvatarFallback className="text-xs">{notification.memberInitials}</AvatarFallback>
              </Avatar>
            )}
          </div>

          <div className="flex justify-between items-center mt-2">
            <span className="text-xs text-muted-foreground">{notification.time}</span>

            <div className="flex gap-2">
              <Badge
                variant="outline"
                className={`text-xs px-1.5 py-0 h-5 ${
                  notification.severity === "critical"
                    ? "border-red-500/20 text-red-500"
                    : notification.severity === "warning"
                      ? "border-amber-500/20 text-amber-500"
                      : "border-blue-500/20 text-blue-500"
                }`}
              >
                {notification.severity}
              </Badge>

              {notification.actionable && (
                <Button variant="outline" size="icon" className="h-5 w-5 rounded-full" onClick={handleAction}>
                  <ArrowUpRight className="h-3 w-3" />
                </Button>
              )}

              <Button variant="ghost" size="icon" className="h-5 w-5" onClick={handleMarkAsRead}>
                <CheckCircle2 className={`h-3 w-3 ${isRead ? "text-primary" : "text-muted-foreground"}`} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Sample data
const allNotifications: Notification[] = [
  {
    id: 1,
    title: "High Body Temperature",
    description: "Alpha-2 has elevated body temperature of 38.2°C",
    time: "10 minutes ago",
    category: "health",
    severity: "warning",
    read: false,
    member: "Sarah M.",
    memberInitials: "SM",
    actionable: true,
  },
  {
    id: 2,
    title: "Low Hydration Level",
    description: "Bravo-1 hydration level at 68%, below recommended threshold",
    time: "23 minutes ago",
    category: "health",
    severity: "warning",
    read: false,
    member: "Michael K.",
    memberInitials: "MK",
    actionable: true,
  },
  {
    id: 3,
    title: "Geo-fence Breach",
    description: "Charlie-3 has moved outside the designated operation area",
    time: "42 minutes ago",
    category: "location",
    severity: "warning",
    read: false,
    member: "Alex T.",
    memberInitials: "AT",
    actionable: true,
  },
  {
    id: 4,
    title: "Communication Channel Disruption",
    description: "LoRaWAN channel experiencing interference in sector B",
    time: "1 hour ago",
    category: "system",
    severity: "info",
    read: true,
    actionable: false,
  },
  {
    id: 5,
    title: "Elevated Heart Rate",
    description: "Alpha-1 heart rate at 110 BPM during rest period",
    time: "1.5 hours ago",
    category: "health",
    severity: "info",
    read: true,
    member: "John D.",
    memberInitials: "JD",
    actionable: false,
  },
  {
    id: 6,
    title: "Battery Level Low",
    description: "Bravo-2 device battery at 15%, requires charging",
    time: "2 hours ago",
    category: "system",
    severity: "info",
    read: true,
    member: "Emily R.",
    memberInitials: "ER",
    actionable: false,
  },
  {
    id: 7,
    title: "Team Separation Alert",
    description: "Charlie-3 is more than 500m away from the rest of the team",
    time: "2.5 hours ago",
    category: "location",
    severity: "warning",
    read: true,
    member: "Alex T.",
    memberInitials: "AT",
    actionable: false,
  },
]

// Function to generate random notifications for simulation
function generateRandomNotification(id: number): Notification {
  const categories = ["health", "location", "system"] as const
  const severities = ["critical", "warning", "info"] as const
  const members = [
    { name: "John D.", initials: "JD" },
    { name: "Sarah M.", initials: "SM" },
    { name: "Michael K.", initials: "MK" },
    { name: "Emily R.", initials: "ER" },
    { name: "Alex T.", initials: "AT" },
  ]

  const category = categories[Math.floor(Math.random() * categories.length)]
  const severity = severities[Math.floor(Math.random() * severities.length)]
  const includeMember = Math.random() > 0.3
  const member = includeMember ? members[Math.floor(Math.random() * members.length)] : undefined
  const actionable = Math.random() > 0.5

  // Generate title and description based on category
  let title = ""
  let description = ""

  switch (category) {
    case "health":
      const healthIssues = ["Heart Rate", "Temperature", "Hydration", "Stress Level", "Blood Pressure", "Oxygen Level"]
      const issue = healthIssues[Math.floor(Math.random() * healthIssues.length)]

      if (severity === "critical") {
        title = `Critical ${issue} Alert`
        description = `${member?.name || "Team member"} has dangerously ${issue === "Hydration" ? "low" : "high"} ${issue.toLowerCase()}`
      } else if (severity === "warning") {
        title = `Elevated ${issue}`
        description = `${member?.name || "Team member"} ${issue.toLowerCase()} is above normal range`
      } else {
        title = `${issue} Update`
        description = `${member?.name || "Team member"} ${issue.toLowerCase()} has returned to normal`
      }
      break

    case "location":
      const locationIssues = ["Geo-fence", "Position", "Movement", "Separation", "Zone"]
      const locIssue = locationIssues[Math.floor(Math.random() * locationIssues.length)]

      if (severity === "critical") {
        title = `Critical ${locIssue} Breach`
        description = `${member?.name || "Team member"} has entered a restricted area`
      } else if (severity === "warning") {
        title = `${locIssue} Warning`
        description = `${member?.name || "Team member"} is approaching mission boundary`
      } else {
        title = `${locIssue} Update`
        description = `${member?.name || "Team member"} position has been updated`
      }
      break

    case "system":
      const systemIssues = ["Battery", "Connection", "Signal", "Device", "Sensor"]
      const sysIssue = systemIssues[Math.floor(Math.random() * systemIssues.length)]

      if (severity === "critical") {
        title = `Critical ${sysIssue} Failure`
        description = `${sysIssue} has failed ${member ? `for ${member.name}` : "in the system"}`
      } else if (severity === "warning") {
        title = `${sysIssue} Warning`
        description = `${sysIssue} is experiencing issues ${member ? `for ${member.name}` : "in the system"}`
      } else {
        title = `${sysIssue} Update`
        description = `${sysIssue} status has been updated`
      }
      break
  }

  // Generate a random time
  const times = ["just now", "2 minutes ago", "5 minutes ago", "10 minutes ago", "15 minutes ago"]
  const time = times[Math.floor(Math.random() * times.length)]

  return {
    id,
    title,
    description,
    time,
    category,
    severity,
    read: false,
    member: member?.name,
    memberInitials: member?.initials,
    actionable,
  }
}
